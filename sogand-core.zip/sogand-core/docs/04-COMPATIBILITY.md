# Compatibility statement

| Component | Supported | Tested in this delivery |
|---|---|---|
| WordPress | 6.5 and newer | 7.1.3 |
| PHP | 7.4 – 8.3 (no PHP 8-only syntax) | PHP 8.3 (7.4 – 8.2 not run) |
| Elementor (Free) | 3.24 and newer (Flexbox containers) | 4.3.5 |
| Elementor Pro | optional | 4.3.1 |

* **Optimized markup** (`e_optimized_markup`): all Sogand CSS works with and without `.elementor-widget-container`; Sogand widgets use no inner wrapper.
* **Caching plugins**: saving Site Settings or Sogand Settings calls the “purge all” function of LiteSpeed Cache, WP Rocket, W3 Total Cache, WP Super Cache, SiteGround Optimizer and WP Fastest Cache when one of them is installed, so changes show at once (the calls were not tested against each of these plugins; with any other cache, purge it by hand after changing settings).
* **Pro without duplicates**: Theme Builder locations (header, footer, single, archive) take priority over the Site Settings → Sogand Templates slots wherever they have display conditions; the Sogand “Saved Template” widget is hidden from the panel when Pro is active (existing ones keep working); Sogand page transitions step aside when Pro page transitions are enabled; Sogand controls use an `sg_` prefix so they never collide with Pro’s Motion Effects / Sticky.
* **Element cache**: Sogand widgets declare dynamic content, so they are not served from Elementor’s element cache.
* **Accessibility**: skip link, focus styles, keyboard-operable menu panels, FAQ (`details/summary`), tabs, accordions, gallery; live regions for form results; reduced-motion respected (system setting, or forced in Site Settings).
* **Languages**: the website is forced to English (`en_US`) and left-to-right on the front end, even when WordPress is set to Persian (switch in Settings → Sogand Settings). The plugin and theme ship a complete Persian translation of their admin side (`sogand-core-fa_IR`, theme `fa_IR`), used for Sogand’s screens and Elementor panels whenever “Sogand admin language” is on or the user’s language is Persian. Visitor-facing strings use the separate text domain `sogand-site` and stay English, also in the editor.
* **Not supported**: the Sogand 7 Studio editor itself (replaced by Elementor), the Sogand 7 built-in page cache (use a caching plugin such as LiteSpeed Cache or WP Rocket).

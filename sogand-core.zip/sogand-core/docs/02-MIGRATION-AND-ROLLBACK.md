# Moving from Sogand 7 (Studio) to Sogand 8 (Elementor) — and back

**Take a full backup first** (files + database), e.g. with your host’s backup tool.

## What stays exactly as it is

* Portfolio works (`sg_work`), collections (`sg_collection`), their order, pictures, details and **URLs** (`/collections/<work>/`, `/collection/<name>/`) — same post type, taxonomy and slugs.
* Inquiries and subscribers (`sg_inquiry`), the CSV export.
* Contact & mail settings (option `sogand_settings`, same keys) — inbox, phone, Instagram, SMTP.
* Menus you already have. Sogand 7 used the Primary location only for a few *extra* header links next to its built-in pages; when you migrate, the build creates a full “Sogand Primary” menu (Home, Collections, Services with its five services, About, Journal if you have a posts page, Contact) **plus your Sogand 7 extra links**, and assigns it to Primary. The Sogand 7 menu itself is not edited; “Restore earlier pages” puts it back in the Primary location.
* Every Sogand 7 option (`sogand_studio`, history, revisions, `theme_mods_sogand`, …) — never edited or deleted.

## Steps

1. Install Elementor and **Sogand Core**. While the Sogand 7 theme is active the plugin stays dormant (only its setup screen and a notice), so nothing is registered twice.
2. Keep a copy of your Sogand 7 theme zip (you need it to roll back). Then Appearance → Themes → Add New → Upload Theme → `sogand-theme-8.0.1.zip`. Both versions use the folder name `sogand`, so WordPress asks whether to **replace the current theme with the uploaded one** — confirm. Your theme settings (`theme_mods_sogand`) stay, because the theme keeps the same name.
3. Sogand → Setup & layouts. The screen shows that Sogand 7 content was found and pre-selects the presets matching your Sogand 7 choices (home hero design, services header, about demo). Keep **“Carry over Sogand 7 wording”** ticked and press **Build the site**.
   * An inert copy of the Sogand 7 options is stored once in `sgc_v7_backup` (not autoloaded).
   * Texts you changed in the Studio or the Customizer replace the matching default sentences in the new pages.
   * Extra head/footer code from the Studio is copied to Sogand → Setup → Extra code, **switched off** until you check and enable it.
   * The screen lists what cannot be carried over automatically (single-element style tweaks, Studio custom CSS that targeted Sogand 7 classes, hidden/duplicated Studio widgets).
4. Review each page in Elementor and publish your changes.

## Rollback

* **Pages only**: Sogand → Setup → **Restore earlier pages**. Each of the five pages gets back its content, page template and Elementor data from the first snapshot (before Sogand 8 touched it); front-page settings and the previous Elementor Site Settings are restored. Templates, menus and works are left alone.
* **Back to Sogand 7 completely**: run “Restore earlier pages”, then upload your Sogand 7 theme zip again (Appearance → Themes → Add New → Upload Theme → replace the current theme). Sogand Core goes dormant automatically; you may also deactivate it. All Sogand 7 options were never changed, so the Studio shows the site as before.
* Database backup restore is always the last resort.

## Tested

This whole path was run on a test copy (WordPress 7.1.3, Elementor 4.3.5, PHP 8.3) with Sogand 7.0.1 holding Studio changes (home hero “Arch”, services header “i3”, about demo “a12”, a changed hero title and “Join the Journey” title, an extra header link): plugin installed under Sogand 7 (dormant, build button disabled and also refused on the server), theme replaced, build with carry-over (presets 06 / 23 / 12 pre-selected, both texts carried, all 10 URLs answering 200, Sogand 7 options byte-identical), restore (the five pages identical to their Sogand 7 state, front page settings and menu location back), Sogand 7 theme re-uploaded (site and Studio data as before), and a second migration (templates and pages reused, no duplicates). See the coverage report.

# Coverage report — Sogand 8.0.1 + Sogand Core 1.0.1

Everything below was run, not assumed. Test environment: WordPress 7.1.3, PHP 8.3, Elementor 4.3.5 (Free) and, separately, Elementor Pro 4.3.1, Chromium (automated browser), SQLite database. Where something was **not** tested it is listed under “Not tested”.

## Tested in a running WordPress

| Area | What was done | Result |
|---|---|---|
| Install | Plugin + theme activated on a fresh site, setup screen, “Build the site” from the browser | pass — pages, 7 shared templates, Site Settings and menu created; log shows every step |
| All 200 page presets | Each of the 40 Home, 40 About, 40 Services, 40 Contact and 40 Collections presets applied to its real page and loaded at 1440, 768 and 390 px. Checked: PHP error log, browser console errors, horizontal page overflow, broken images, buttons/fields cut off by their container, elements outside the screen. Full-page screenshots reviewed by eye on contact sheets | pass after fixes (see “Bugs found and fixed”). Final run: 0 PHP errors, 0 console errors, 0 broken images, 0 overflow, 0 clipped controls. The horizontal FAQ topic strip on small screens scrolls sideways on purpose |
| 40 Home heroes as section templates | Same designs as the Home presets (same generator); all imported into the library without errors | pass (rendered through the Home presets) |
| Whole template library | All 247 templates imported into Templates → Saved Templates | 247 / 247 imported, 0 errors, 0 PHP notices |
| Elementor editor | Opened in the editor and saved: Collections slider, Collections archive, Header, Footer, Work page, 404, Collection archive, a hero section, a Home, About, Services, Contact and Collections page template, and a built page. For each, a Sogand widget’s panel was opened | pass — loads, controls render, saves, no console errors |
| Site Settings | Sogand Effects / Page transitions / Layout tabs and the global colours / fonts open; a setting changed and saved; the front end picked it up | pass |
| Page transitions | All 20 curtains: click an internal link, curtain covers, next page opens, curtain lifts, no errors; mid-transition screenshots reviewed | 20 / 20 pass |
| Forms | Inquiry form: empty submit (client errors, no request), valid submit with mail failing (“saved on the website, email could not be sent”) and with mail accepted (“received”). Newsletter: invalid email, subscribe, duplicate (“already on the list”). Server: honeypot, forged token, too-fast token, extra recipient fields ignored, header injection in the name neutralised, rate limit (429 after 8 per hour) | pass |
| Keyboard | Skip link first; menu: ArrowDown opens a panel and focuses its first link, chevron button opens it, Tab walks the panel, Escape closes and returns focus; mobile menu: opens from the keyboard, focus stays inside (30 Tabs), Escape closes and returns focus to the burger | pass |
| Accessibility checks (own script — axe-core could not be downloaded here) | Work page, 404, collection archive: `lang`, one `h1`, no skipped heading levels, no duplicate ids, all images have `alt`, all links/buttons have a name, all fields have a label, landmarks present, every focus stop has a visible focus style | pass. The contrast part of the script is approximate (it skips text on gradients/images) |
| Reduced motion | Pages loaded with “reduce motion” on (all preset runs above) | pass — no hidden content, entrance effects show their end state |
| Elementor Pro 4.3.1 | Activated: every page renders one header and one footer; a Pro Theme Builder header with “Entire site” replaces the Sogand header (no duplicate); the Sogand “Saved Template” widget is hidden from the panel while Pro’s Template widget is there; editor opens and saves; no PHP errors | pass |
| Migration from Sogand 7.0.1 | Sogand 7 site with Studio changes → plugin installed (dormant, build disabled and refused on the server) → theme replaced → build with carry-over → restore → Sogand 7 re-uploaded → migrated again. Details in the migration guide | pass — matching presets pre-selected (Home 06, Services 23, About 12), changed texts carried, all 10 URLs 200, Sogand 7 options unchanged, restore returns the five pages to their exact Sogand 7 content, menu location and front page restored, second run creates no duplicates |
| Admin in right-to-left | Setup, Contact & Mail and the Work editor shown with a right-to-left admin | pass — layout mirrors correctly, no overflow; e-mail/URL/phone fields stay left-to-right |

## Update 1.0.1 — Persian admin, English site, page-transition settings (tested)

| Area | What was done | Result |
|---|---|---|
| Website always English | WordPress set to Persian (with right-to-left switched on as a Persian language pack does). Front end, Elementor preview, and the forms’ REST answers checked; then the switch turned off to prove the opposite | Switch on: `lang="en-US"`, left-to-right, no RTL stylesheets, form errors in English. Switch off: `dir="rtl" lang="fa-IR"` (the behaviour you saw before) |
| Persian Sogand admin | 1 089 admin strings translated (setup, settings, Works, menus, every widget, control, “Sogand …” section and Site Settings tab, template names and descriptions). Checked with WordPress in Persian and in English | Both: Sogand screens and panels in Persian. English WordPress: Sogand pages switch to right-to-left text; Elementor itself stays English (its own language follows your profile language) |
| Visitor text in the editor | Widget re-render while editing in Persian | Visitor-facing words stay English (separate text domain) |
| Saving in a Persian editor | Page and Site Settings saved from the right-to-left editor, CSS regenerated, front end compared with a screenshot taken before | Identical layout |
| Page-transition settings | Logo off, name off, empty name, curtain off — read back from the page | All four now respected (before, a switched-off switch fell back to “on”; the same bug affected the shine / magnetic / sparkle switches in Sogand Effects and is fixed too) |
| Logo motion between pages | Logo angle sampled every frame on the old and the new page and compared with the clock | Old page within ~1° on average, new page within ~3° — the logo carries on turning instead of snapping back to straight |
| 20 curtains, forms, 40 presets (8 per page type), editor | Re-run after the changes, with WordPress in Persian | all pass; no PHP or console errors |
| Glass / chip buttons in the editor | The editor painted them with the accent colour | fixed (transparent like on the site) |

Not tested: the cache-purge calls against each caching plugin; Elementor’s own Persian interface (needs its language files from WordPress.org, which this test machine could not download).

## Static checks (re-run on the final code)

| Check | Result |
|---|---|
| `php -l` on every PHP file | pass |
| Render smoke test of every Sogand widget with all settings combinations used (138 renders, notices treated as errors) | pass |
| Template validator: every setting is a real control, select values valid, **slider values inside the control’s range**, unique ids | 247 templates, 0 errors |
| JavaScript syntax, CSS parse in Chromium | pass |

## Bugs found by these tests and fixed

* Hero photo parallax moved the picture far up on phones (value outside the control’s range) — fixed; the validator now checks slider ranges, which also caught a shadow strength and two line heights.
* Slanted / diamond / octagon / hexagon picture shapes were cancelled by entrance reveals and by reduced motion — shapes now survive both.
* “Have a project in mind?” bar: the button was pushed outside the box — fixed.
* Header top bar: phone and e-mail could run past the edge; the small marker was a dash — fixed.
* About demo 27: the vertical name caused sideways scrolling on phones — fixed.
* Magazine hero: buttons ran off the left edge on phones — fixed; button rows can no longer be wider than their column.
* Spotlight hero dimmed its own headline — text now sits above the light effect.
* Work pictures were cropped (bracelet cut off) because of an Elementor image rule — whole piece now visible; long work names wrap to two lines instead of “…”.
* Plugin and Sogand 7 both defined `SOGAND_PRIMARY_EMAIL` (PHP warning while both were installed) — the plugin uses its own constant now.
* Migrating replaced the header menu with Sogand 7’s “extra links” menu (only “Journal”) — a full menu with those links is created now; restore puts the old one back.
* Re-importing templates piled up old copies — only the latest previous copy is kept.
* Build button was clickable while Sogand 7 was active (the server already refused) — now disabled.

## Not tested

* A real mail server (sending was tested with WordPress’s mail function failing and with a test hook that accepts mail; the result shown to the visitor follows what the server reports).
* Cloudflare Turnstile with real keys (no internet access to Cloudflare from the test machine).
* Screen readers (NVDA / VoiceOver) — only the automated and keyboard checks above.
* Real phones and Safari/Firefox — Chromium only, at phone/tablet/desktop widths.
* PHP 7.4 – 8.2 (code avoids PHP 8-only syntax; only 8.3 was run).
* Your live database — the migration was run on a test copy with Sogand 7.0.1; take a full backup before migrating.

## Template coverage

| Group | Count | Notes |
|---|---|---|
| Home | 40 | hero 1–40 + services grid (5 looks) + doors (4 looks) + marquee (3 looks); no “Join the Journey” / “Have a project in mind?” on Home (as in Sogand 7) |
| Home heroes as section templates | 40 | same designs as Sogand 7, in the same order |
| Services | 40 | 40 headers (20 without, 20 with a picture) + service details (4 looks) + process (all 21 layouts used) + journey + project CTA |
| About | 40 | 40 demos + FAQ (3 layouts) + journey + project CTA |
| Contact | 40 | 10 headers × 4 contact layouts, FAQ, project CTA |
| Collections | 40 | 10 headers × 4 section orders; slider and archive are referenced templates; journey and project CTA are page-local |
| Site parts | 7 | header, footer, work page, 404, collection archive, collections slider, collections archive grid |

## Known limitations

* The owner portrait is a placeholder (`img/sogand-portrait.webp`: gold mark on oxblood). Replace it in the Media Library with the real photo; every About demo uses it.
* Studio single-element style tweaks, Studio custom CSS and hidden/duplicated Studio widgets cannot be mapped automatically (listed on the setup screen).
* Wording migration replaces exact default sentences only; split titles (e.g. the Magazine hero) keep the new defaults.
* Admin strings are translatable (`languages/*.pot`); a Persian translation file is not included.

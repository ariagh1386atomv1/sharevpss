# Sogand 8 — Installation

Deliverables:

| File | What it is |
|---|---|
| `sogand-theme-8.0.1.zip` | Classic WordPress theme **Sogand** 8.0.1 (header/footer/templates, fallback layout) |
| `sogand-core-1.0.1.zip` | Companion plugin **Sogand Core** (portfolio, Elementor widgets, shared style & motion controls, Site Settings tabs, forms, template library, importer, migration) |
| `templates/` inside the plugin | 247 Elementor JSON templates + `manifest.json` |

Requirements: WordPress 6.5+, PHP 7.4+ (tested on PHP 8.3), **Elementor 3.24+** (tested with Elementor 4.3.5). Elementor Pro is optional (tested with 4.3.1).

## Fresh site

1. Install and activate **Elementor** (Plugins → Add New).
2. Plugins → Add New → Upload Plugin → `sogand-core-1.0.1.zip` → Activate.
3. Appearance → Themes → Add New → Upload Theme → `sogand-theme-8.0.1.zip` → Activate.
4. Settings → Permalinks → choose “Post name” → Save (keeps `/collections/<work>/` URLs).
5. **Sogand → Setup & layouts**: choose a layout for Home, Collections, Services, About and Contact (40 each), tick the options and press **Build the site**. The log lists every step.
6. Settings → **Sogand Settings**: the language switches (website always English, Sogand admin in Persian — both on by default), then check the inbox address, phone, Instagram, SMTP (and optional Cloudflare Turnstile keys). Use “Send test email”.

Nothing is installed or activated automatically; the theme only shows a notice when Elementor or Sogand Core is missing.

## What the build does

* Finds the five pages by role (earlier Sogand pages, then slug), or creates them; sets Home as the front page.
* Imports the shared templates once: Header, Footer, Work Page, 404, Collection Archive, Collections Slider, Collections Archive grid — and assigns header/footer/work/404/archive in **Site Settings → Sogand Templates**.
* Writes the Sogand colours (global colours), fonts (global fonts, local “Sogand Sans”), buttons and layout width into Elementor Site Settings (previous settings backed up once).
* Fills each selected page with its preset through Elementor’s own document API (so every element is validated against the real controls). The page’s previous content is kept as a snapshot.
* Creates “Sogand Primary” menu only when no menu is assigned to the Primary location (when migrating from Sogand 7, see the migration guide).
* Optional: adds all 240 layouts to Templates → Saved Templates; adds three sample works when the portfolio is empty.

Running it again is safe: pages and templates are found again, existing templates are reused (unless “Re-import” is ticked — the previous copy is kept as a draft, older previous copies go to the bin), menus are never changed.

# Editing guide

## Where things live

| What | Where |
|---|---|
| Page content | Edit the page with Elementor — every section is a normal container with Heading, Text Editor, Button, Image and Sogand widgets |
| Header / Footer | Templates → Saved Templates → “Sogand — Header/Footer” (or Elementor Pro Theme Builder). Chosen in Site Settings → **Sogand Templates** |
| Menu items | Appearance → Menus. Per top item: “Panel” = Dropdown / Collections / Services, plus an icon. Menu item *Description* = second line in the Services panel |
| Colours, fonts, buttons | Elementor → Site Settings → Global Colors / Global Fonts / Buttons |
| Glass, glow, shine, magnet, sparkles, motion speed, reduced motion, cursor light, progress bar, preloader | Site Settings → **Sogand Effects** (site defaults); each element can override in its Style/Advanced tab → “Sogand …” sections |
| Page transitions (20 curtains) | Site Settings → **Sogand Page Transitions** (switch off automatically when Elementor Pro page transitions are on) |
| Website language (always English, left-to-right), Sogand admin language (Persian), contact details, recipients, SMTP, Turnstile | Settings → **Sogand Settings** |
| Portfolio | Works (pictures, gallery, details, colour halo, featured) and Works → Collections (order) |

## Languages

* The **website** is always English and left-to-right (Settings → Sogand Settings → *Website language*), also when WordPress itself is set to Persian. Visitor-facing words that come from code (aria labels, “Show more”, form errors) are always English.
* **Sogand’s admin** — the setup screen, settings, menu fields, the Works editor, every Sogand widget, its controls, the “Sogand …” sections on every element and the Sogand Site Settings tabs — is Persian (*Sogand admin language*). For a fully right-to-left admin, also choose **فارسی** as your language in Users → Profile → Language (WordPress then downloads its own Persian files).
* Text you type into widgets is your content: write it in English for the site.

## Shared capabilities on any element

Containers (Style tab) and every widget (Advanced tab) have: **Sogand Glass**, **Glow / halo**, **Motion** (loop, pointer tilt/parallax/magnet, scroll parallax), **Scroll-progress border**, **Sticky inside parent**. Containers also have **Header behaviour** (fixed / smart / sticky, glass after scroll, collapse). Headings and Text Editor have **Text reveal**. Images have **fade per edge** (per device), masks, reveal, frame, reflection, shadow and transforms. Buttons have **shine**, **magnetic** and **click sparkles**. Empty values inherit the Site Settings defaults.

## Referenced blocks on the Collections page

The Collections slider and the archive grid are **Saved Templates** shown through the “Saved Template” widget: edit them once (Templates → Saved Templates) and every page that uses them updates. “Join the Journey” and “Have a project in mind?” are normal sections of the page, so changing or deleting them affects only that page.

## Tips

* Ornaments placed *behind* content can be clicked in the editor; ornaments in *front* are selected through the **Navigator**.
* The 40 Home heroes are also available as section templates (“Sogand Hero 01 — …”) once “add all layouts to Saved Templates” was run: insert any of them on any page from the Elementor library (My Templates).
* Forms never take the recipient from the page. Messages are stored under Inquiries; the success message says the message was *received by the website and handed to the mail server* — delivery to the inbox is reported per inquiry (“accepted” / “failed”).

<?php
/**
 * Plugin Name:       Sogand Core
 * Plugin URI:        https://sogandjewel.com/
 * Description:       Portfolio content, Elementor widgets, shared style and motion controls, page transitions, forms and the template library for the Sogand theme.
 * Version:           1.0.1
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Author:            Sogand Andalibazar
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       sogand-core
 * Domain Path:       /languages
 * Requires Plugins:  elementor
 * Elementor tested up to: 4.3.5
 * Elementor Pro tested up to: 4.3.1
 *
 * @package SogandCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SGC_VERSION', '1.0.1' );
define( 'SGC_FILE', __FILE__ );
define( 'SGC_DIR', plugin_dir_path( __FILE__ ) );
define( 'SGC_URL', plugin_dir_url( __FILE__ ) );
define( 'SGC_MIN_ELEMENTOR', '3.24.0' );
/* own constant name: Sogand 7 themes define SOGAND_PRIMARY_EMAIL themselves (a wp-config value is still honoured) */
if ( ! defined( 'SGC_PRIMARY_EMAIL' ) ) {
	define( 'SGC_PRIMARY_EMAIL', defined( 'SOGAND_PRIMARY_EMAIL' ) ? SOGAND_PRIMARY_EMAIL : 'info@sogandjewel.com' );
}

require_once SGC_DIR . 'includes/i18n.php';
require_once SGC_DIR . 'includes/helpers.php';
require_once SGC_DIR . 'includes/library.php';
require_once SGC_DIR . 'includes/importer.php';
require_once SGC_DIR . 'includes/migrate.php';
require_once SGC_DIR . 'includes/admin-setup.php';

/**
 * Sogand 7 (the single-page theme with the Studio) registers the same post types, REST
 * route and mail settings. While it is the active theme this plugin stays dormant apart
 * from its setup screen, so nothing is registered twice. Themes load after plugins, so
 * the check runs on after_setup_theme.
 */
function sgc_legacy_theme_active() {
	return function_exists( 'sogand_studio_state' ) || function_exists( 'sogand_seed' );
}

function sgc_load_runtime() {
	static $done = false;
	if ( $done || sgc_legacy_theme_active() ) {
		return;
	}
	$done = true;
	/* Content (post types, taxonomies, meta, forms) works with or without Elementor,
	   so portfolio entries and inquiries never disappear when Elementor is switched off. */
	require_once SGC_DIR . 'includes/content.php';
	require_once SGC_DIR . 'includes/forms.php';
	require_once SGC_DIR . 'includes/settings-page.php';
	require_once SGC_DIR . 'includes/menus.php';
}

add_action( 'after_setup_theme', function () {
	if ( sgc_legacy_theme_active() ) {
		add_action( 'admin_notices', 'sgc_notice_legacy_theme' );
		return;
	}
	sgc_load_runtime();
	if ( ! did_action( 'elementor/loaded' ) ) {
		add_action( 'admin_notices', 'sgc_notice_missing_elementor' );
		return;
	}
	if ( defined( 'ELEMENTOR_VERSION' ) && version_compare( ELEMENTOR_VERSION, SGC_MIN_ELEMENTOR, '<' ) ) {
		add_action( 'admin_notices', 'sgc_notice_old_elementor' );
		return;
	}
	/* Elementor's base classes (Widget_Base, Tab_Base …) are available from elementor/init on */
	add_action( 'elementor/init', function () {
		require_once SGC_DIR . 'includes/elementor/class-elementor.php';
		\Sogand\Core\Elementor\Integration::instance();
	} );
}, 1 );

function sgc_notice_legacy_theme() {
	if ( ! current_user_can( 'switch_themes' ) ) {
		return;
	}
	echo '<div class="notice notice-warning"><p>' . esc_html__( 'Sogand Core is waiting: the active theme is Sogand 7. Upload the Sogand 8 theme (Appearance → Themes → Add New → Upload Theme; it replaces Sogand 7), then open Sogand → Setup & layouts. Your Sogand 7 content is not changed by installing this plugin.', 'sogand-core' ) . '</p></div>';
}

function sgc_notice_missing_elementor() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	echo '<div class="notice notice-warning"><p>' . wp_kses_post(
		sprintf(
			/* translators: %s: Elementor */
			__( '<strong>Sogand Core</strong> needs %s to be installed and active. Portfolio entries and inquiries keep working; the Sogand widgets, controls and templates appear once Elementor is active.', 'sogand-core' ),
			'<strong>Elementor</strong>'
		)
	) . '</p></div>';
}

function sgc_notice_old_elementor() {
	if ( ! current_user_can( 'update_plugins' ) ) {
		return;
	}
	echo '<div class="notice notice-warning"><p>' . esc_html(
		sprintf(
			/* translators: 1: required version 2: installed version */
			__( 'Sogand Core requires Elementor %1$s or newer (installed: %2$s). Please update Elementor.', 'sogand-core' ),
			SGC_MIN_ELEMENTOR,
			ELEMENTOR_VERSION
		)
	) . '</p></div>';
}

register_activation_hook( __FILE__, function () {
	if ( ! sgc_legacy_theme_active() ) {
		sgc_load_runtime();
		sgc_register_content();
	}
	flush_rewrite_rules();
	update_option( 'sgc_needs_setup', '1', false );
} );

register_deactivation_hook( __FILE__, function () {
	flush_rewrite_rules();
} );

/* Work edit screen: halo colour picker, gallery picker, repeatable details. */
jQuery(function ($) {
	'use strict';
	var L = window.sgcWork || { title: 'Gallery', button: 'Use these images' };
	if ($.fn.wpColorPicker) {
		$('.sgc-color').wpColorPicker();
	}
	var frame;
	$('#sg_gallery_btn').on('click', function (e) {
		e.preventDefault();
		if (frame) { frame.open(); return; }
		frame = wp.media({ title: L.title, button: { text: L.button }, multiple: 'add', library: { type: 'image' } });
		frame.on('open', function () {
			var sel = frame.state().get('selection');
			sel.reset();
			($('#sg_gallery').val() || '').split(',').filter(Boolean).forEach(function (id) {
				var a = wp.media.attachment(id);
				a.fetch();
				sel.add(a);
			});
		});
		frame.on('select', function () {
			var ids = [];
			var $p = $('#sg_gallery_preview').empty();
			frame.state().get('selection').each(function (a) {
				ids.push(a.id);
				var s = a.get('sizes');
				var u = s && s.thumbnail ? s.thumbnail.url : a.get('url');
				$('<img>', { src: u, width: 70, height: 70, alt: '' }).appendTo($p);
			});
			$('#sg_gallery').val(ids.join(','));
		});
		frame.open();
	});
	$('#sg_gallery_clear').on('click', function () {
		$('#sg_gallery').val('');
		$('#sg_gallery_preview').empty();
	});
	var renum = function () {
		$('#sg_specs .sg-spec').each(function (i) {
			$(this).find('input').each(function () {
				this.name = this.name.replace(/sg_specs\[\d+\]/, 'sg_specs[' + i + ']');
			});
		});
	};
	$('#sg_spec_add').on('click', function () {
		$('#sg_specs').append($('#sg_spec_tpl').html());
		renum();
		$('#sg_specs .sg-spec:last input:first').trigger('focus');
	});
	$('#sg_specs').on('click', '.sg-spec-del', function () {
		$(this).closest('.sg-spec').remove();
		renum();
	}).on('click', '.sg-spec-up', function () {
		var r = $(this).closest('.sg-spec');
		r.prev('.sg-spec').before(r);
		renum();
	});
});

/* Sogand core runtime: shared helpers for every Sogand script.
   One scroll/resize loop, one IntersectionObserver, device + motion checks,
   and a helper to register Elementor handlers for widgets. */
(function (w) {
	'use strict';
	var sgc = w.sgc = w.sgc || {};
	var cfg = w.sgcConfig || {};

	sgc.reduced = function () {
		if (cfg.reduce === 'always' || (document.body && document.body.classList.contains('sg-calm'))) { return true; }
		return !!(w.matchMedia && w.matchMedia('(prefers-reduced-motion: reduce)').matches);
	};
	sgc.fine = function () {
		return !!(w.matchMedia && w.matchMedia('(hover: hover) and (pointer: fine)').matches);
	};
	sgc.editing = function () {
		return !!(w.elementorFrontend && w.elementorFrontend.isEditMode && w.elementorFrontend.isEditMode());
	};
	/* desktop | tablet | mobile (Elementor's breakpoints, extra breakpoints folded in) */
	sgc.device = function () {
		var d = 'desktop';
		try { d = w.elementorFrontend.getCurrentDeviceMode(); } catch (e) {
			var vw = w.innerWidth;
			d = vw <= 767 ? 'mobile' : (vw <= 1024 ? 'tablet' : 'desktop');
		}
		if (d === 'mobile_extra') { d = 'mobile'; }
		if (d === 'tablet_extra') { d = 'tablet'; }
		if (d === 'laptop' || d === 'widescreen') { d = 'desktop'; }
		return d;
	};

	/* ---- one rAF-throttled scroll/resize bus ---- */
	var subs = [];
	var ticking = false;
	var run = function () {
		ticking = false;
		var y = w.scrollY || w.pageYOffset || 0;
		for (var i = 0; i < subs.length; i++) {
			try { subs[i](y); } catch (e) { /* keep others running */ }
		}
	};
	var ping = function () {
		if (!ticking) { ticking = true; w.requestAnimationFrame(run); }
	};
	w.addEventListener('scroll', ping, { passive: true });
	w.addEventListener('resize', ping);
	sgc.onScroll = function (fn) {
		subs.push(fn);
		fn(w.scrollY || 0);
		return function () {
			var i = subs.indexOf(fn);
			if (i > -1) { subs.splice(i, 1); }
		};
	};

	/* ---- shared in-view observer ---- */
	var io = null;
	var cbs = typeof WeakMap === 'function' ? new WeakMap() : null;
	sgc.inView = function (el, cb, once) {
		if (!('IntersectionObserver' in w) || !cbs) { cb(true); return function () {}; }
		if (!io) {
			io = new IntersectionObserver(function (entries) {
				entries.forEach(function (e) {
					var f = cbs.get(e.target);
					if (!f) { return; }
					f.fn(e.isIntersecting, e);
					if (e.isIntersecting && f.once) { cbs.delete(e.target); io.unobserve(e.target); }
				});
			}, { rootMargin: '0px 0px -10% 0px', threshold: 0.06 });
		}
		cbs.set(el, { fn: cb, once: once !== false });
		io.observe(el);
		return function () { cbs.delete(el); if (io) { io.unobserve(el); } };
	};

	/* ---- visibility of the whole document (pause loops when hidden) ---- */
	sgc.hidden = function () { return document.visibilityState === 'hidden'; };

	/* ---- register a widget handler (works on the site and inside the editor) ---- */
	sgc.widget = function (name, Factory) {
		var attach = function () {
			if (!w.elementorFrontend || !w.elementorModules) { return; }
			var Base = w.elementorModules.frontend.handlers.Base;
			var Handler = Base.extend({
				onInit: function () {
					Base.prototype.onInit.apply(this, arguments);
					this.sg = Factory(this.$element[0], this);
				},
				onElementChange: function (prop) {
					if (this.sg && this.sg.change) { this.sg.change(prop); }
				},
				onDestroy: function () {
					if (this.sg && this.sg.destroy) { this.sg.destroy(); }
					Base.prototype.onDestroy.apply(this, arguments);
				}
			});
			w.elementorFrontend.hooks.addAction('frontend/element_ready/sogand-' + name + '.default', function ($el) {
				w.elementorFrontend.elementsHandler.addHandler(Handler, { $element: $el });
			});
		};
		if (w.elementorFrontend && w.elementorFrontend.hooks) { attach(); } else { w.addEventListener('elementor/frontend/init', attach); }
	};

	/* settings of a handler (data-settings on the site, the live model in the editor) */
	sgc.settings = function (handler) {
		try { return handler.getElementSettings() || {}; } catch (e) { return {}; }
	};

	sgc.num = function (v, fb) {
		if (v && typeof v === 'object' && 'size' in v) { v = v.size; }
		var n = parseFloat(v);
		return isNaN(n) ? fb : n;
	};

	sgc.post = function (path, data) {
		return fetch((cfg.rest || '/wp-json/sogand/v1/') + path, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify(data)
		}).then(function (r) {
			return r.json().catch(function () { return {}; }).then(function (j) {
				if (!r.ok) { throw new Error((j && j.message) || (cfg.i18n && cfg.i18n.error) || 'Error'); }
				return j;
			});
		});
	};
	sgc.i18n = cfg.i18n || {};

	/* ---- “back to top” buttons (Sogand Back to Top widget, or any element with data-sg-top) ---- */
	document.addEventListener('click', function (e) {
		var b = e.target && e.target.closest ? e.target.closest('[data-sg-top]') : null;
		if (!b) { return; }
		e.preventDefault();
		w.scrollTo({ top: 0, behavior: sgc.reduced() ? 'auto' : 'smooth' });
		var main = document.getElementById('content') || document.querySelector('main');
		if (main) {
			if (!main.hasAttribute('tabindex')) { main.setAttribute('tabindex', '-1'); }
			try { main.focus({ preventScroll: true }); } catch (err) { /* old browsers */ }
		}
	});
	var tops = null;
	sgc.onScroll(function (y) {
		if (tops === null) {
			if (document.readyState === 'loading') { return; }
			tops = Array.prototype.slice.call(document.querySelectorAll('.sg-totop[data-after]'));
		}
		if (!tops.length) { return; }
		var max = Math.max(1, document.documentElement.scrollHeight - w.innerHeight);
		for (var i = 0; i < tops.length; i++) {
			var t = tops[i];
			t.classList.toggle('is-shown', y > parseFloat(t.getAttribute('data-after') || '0'));
			t.style.setProperty('--sg-top-p', Math.min(1, y / max).toFixed(3));
		}
	});
	document.addEventListener('DOMContentLoaded', function () { tops = null; ping(); });
}(window));

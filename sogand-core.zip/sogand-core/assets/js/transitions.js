/* Sogand page-transition curtain around normal page loads.
   Covers on internal link clicks, then the next page opens it (sessionStorage flag set
   here, read by the inline head script). Fail-safes: a timer always lifts the curtain,
   bfcache restores reset it, and modified clicks / external / downloads are never covered. */
(function () {
	'use strict';
	var cfg = window.sgcCurtain || {};
	var root = document.documentElement;
	var el = null;
	var busy = false;
	var KEY = 'sg-ct';
	var reduced = function () {
		return document.body.classList.contains('sg-calm') || !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
	};
	var dur = Math.max(150, Math.min(3000, parseInt(cfg.dur, 10) || 420));
	/* logo spin / pulse phase taken from the clock: identical on this page and the next one */
	var syncMotion = function () {
		if (!el) { return; }
		Array.prototype.forEach.call(el.querySelectorAll('.ct-spin,.ct-mark'), function (n) {
			if (!n.getAnimations) { return; }
			n.getAnimations().forEach(function (a) {
				var d = a.effect && a.effect.getTiming ? Number(a.effect.getTiming().duration) : 0;
				if (d > 0) {
					/* anchor the animation to the wall clock (startTime lives on the page timeline,
					   which counts from timeOrigin), so it stays in phase however busy the page is */
					var now = performance.now(), origin = performance.timeOrigin || (Date.now() - now);
					a.startTime = now - ((origin + now) % d);
				}
			});
		});
	};
	var setPhase = function (p) {
		if (!el) { return; }
		var wasIdle = el.classList.contains('is-idle');
		el.classList.remove('is-idle', 'is-cover', 'is-reveal');
		el.classList.add('is-' + p);
		/* a fresh start of the logo motion (curtain was hidden) takes its angle from the clock */
		if (wasIdle && p !== 'idle') { syncMotion(); }
	};
	var reveal = function () {
		if (!el) { return; }
		setPhase('cover');
		/* let the browser register the covered state before animating */
		requestAnimationFrame(function () {
			root.classList.remove('sg-ct-arrive');
			requestAnimationFrame(function () {
				setPhase('reveal');
				setTimeout(function () { setPhase('idle'); busy = false; }, Math.round(dur * 1.15) + 180);
			});
		});
	};
	var lastPoint = null;
	window.addEventListener('pointerdown', function (e) {
		lastPoint = { x: e.clientX, y: e.clientY, t: Date.now() };
	}, { passive: true, capture: true });
	var setOrigin = function () {
		var fresh = lastPoint && Date.now() - lastPoint.t < 1500;
		root.style.setProperty('--ct-x', (fresh ? lastPoint.x / window.innerWidth * 100 : 50).toFixed(1) + '%');
		root.style.setProperty('--ct-y', (fresh ? lastPoint.y / window.innerHeight * 100 : 50).toFixed(1) + '%');
	};
	var skipUrl = /\/wp-(admin|login)|\/feed\/?$|[?&](elementor-preview|preview|customize_changeset_uuid)=|\.(pdf|zip|rar|7z|jpe?g|png|webp|avif|gif|svg|mp4|webm|mp3|wav|docx?|xlsx?|pptx?|csv|txt)(\?|$)/i;
	var leave = function (url) {
		if (busy) { return; }
		busy = true;
		setOrigin();
		setPhase('cover');
		try { sessionStorage.setItem(KEY, String(Date.now())); } catch (e) { /* private mode: the next page simply opens without the curtain */ }
		setTimeout(function () { window.location.href = url; }, dur + 60);
		/* if the browser stays here (blocked, download, very slow), lift the curtain again */
		setTimeout(function () {
			if (document.visibilityState === 'visible') {
				try { sessionStorage.removeItem(KEY); } catch (e) { /* ignore */ }
				reveal();
			}
		}, 6000);
	};
	var onClick = function (e) {
		if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) { return; }
		if (reduced() || !el) { return; }
		var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
		if (!a || a.hasAttribute('download') || (a.target && a.target !== '_self') || a.hasAttribute('data-no-curtain') || a.closest('[data-no-curtain]')) { return; }
		if (a.getAttribute('role') === 'button' || a.closest('.elementor-editor-active')) { return; }
		var raw = a.getAttribute('href') || '';
		if (!raw || raw.charAt(0) === '#' || /^(mailto|tel|sms|javascript|whatsapp|skype|viber|tg):/i.test(raw)) { return; }
		var u;
		try { u = new URL(a.href, window.location.href); } catch (err) { return; }
		if (u.origin !== window.location.origin || skipUrl.test(u.href)) { return; }
		/* same page + anchor → let the browser scroll */
		if (u.pathname === window.location.pathname && u.search === window.location.search) { return; }
		/* lightbox / Elementor actions */
		if (a.hasAttribute('data-elementor-open-lightbox') && a.getAttribute('data-elementor-open-lightbox') !== 'no') { return; }
		if (/^#elementor-action/.test(u.hash)) { return; }
		e.preventDefault();
		leave(u.href);
	};
	var init = function () {
		el = document.querySelector('.sg-curtain');
		if (!el) { root.classList.remove('sg-ct-arrive'); return; }
		document.addEventListener('click', onClick);
		if (root.classList.contains('sg-ct-arrive')) {
			var start = Date.now();
			var go = function () { setTimeout(reveal, Math.max(120, 380 - (Date.now() - start))); };
			if (document.readyState === 'complete') { go(); } else {
				window.addEventListener('load', go, { once: true });
				setTimeout(function () { if (root.classList.contains('sg-ct-arrive')) { reveal(); } }, 2500);
			}
		}
	};
	/* back / forward from the browser cache: never stay covered */
	window.addEventListener('pageshow', function (e) {
		if (e.persisted) { busy = false; root.classList.remove('sg-ct-arrive'); setPhase('idle'); }
	});
	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', init); } else { init(); }
}());

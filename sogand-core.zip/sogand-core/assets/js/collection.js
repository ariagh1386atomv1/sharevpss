/* Sogand Collection Slider + Collections Grid */
(function (w, d) {
	'use strict';
	var sgc = w.sgc;
	if (!sgc) { return; }

	/* ---------------- slider ---------------- */
	sgc.widget('collection-slider', function (root, handler) {
		var stage = root.querySelector('.sg-stage');
		if (!stage) { return null; }
		var s = sgc.settings(handler);
		var slides = Array.prototype.slice.call(stage.querySelectorAll('.sg-stage-slide'));
		var caps = Array.prototype.slice.call(stage.querySelectorAll('.sg-stage-caption'));
		var bars = Array.prototype.slice.call(stage.querySelectorAll('.sg-stage-bar'));
		var no = stage.querySelector('.sg-stage-no b');
		var n = slides.length, cur = 0, timer = 0, hover = false, visible = true;
		var auto = s.autoplay === 'yes' && n > 1 && !sgc.reduced();
		var ms = Math.max(1500, sgc.num(s.interval, 5) * 1000);
		stage.style.setProperty('--sg-cs-int', ms + 'ms');
		stage.classList.toggle('is-auto', auto);
		var go = function (i) {
			i = ((i % n) + n) % n;
			if (i === cur) { return; }
			var prev = cur;
			cur = i;
			slides.forEach(function (sl, k) {
				sl.classList.toggle('is-active', k === cur);
				sl.classList.toggle('is-leaving', k === prev);
				if (k === cur) { sl.removeAttribute('aria-hidden'); } else { sl.setAttribute('aria-hidden', 'true'); }
			});
			caps.forEach(function (c, k) { c.classList.toggle('is-active', k === cur); c.hidden = k !== cur; });
			bars.forEach(function (b, k) {
				b.classList.remove('is-active');
				b.classList.toggle('is-done', k < cur);
				if (k === cur) { void b.offsetWidth; b.classList.add('is-active'); b.setAttribute('aria-current', 'true'); } else { b.removeAttribute('aria-current'); }
			});
			if (no) { no.textContent = String(cur + 1).padStart(2, '0'); }
			restart();
		};
		var restart = function () {
			clearTimeout(timer);
			if (!auto) { return; }
			timer = setTimeout(function tick() {
				if ((hover && s.pause === 'yes') || sgc.hidden() || !visible) { timer = setTimeout(tick, 400); return; }
				go(cur + 1);
			}, ms);
		};
		bars.forEach(function (b, k) { b.addEventListener('click', function () { go(k); }); });
		var enter = function () { hover = true; stage.classList.add('is-paused'); };
		var leave = function () { hover = false; stage.classList.remove('is-paused'); };
		if (s.pause === 'yes') { stage.addEventListener('mouseenter', enter); stage.addEventListener('mouseleave', leave); }
		var offView = sgc.inView(stage, function (v) { visible = v; }, false);
		/* swipe */
		var sx = null;
		stage.addEventListener('pointerdown', function (e) { sx = e.clientX; });
		stage.addEventListener('pointerup', function (e) { if (sx !== null && Math.abs(e.clientX - sx) > 40 && n > 1) { go(cur + (e.clientX < sx ? 1 : -1)); } sx = null; });
		/* tilt */
		var tilt = stage.querySelector('.sg-stage-tilt');
		var k = sgc.num(s.tilt, 8);
		var raf = 0;
		var move = function (e) {
			var r = stage.getBoundingClientRect();
			var x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
			w.cancelAnimationFrame(raf);
			raf = w.requestAnimationFrame(function () { tilt.style.transform = 'rotateY(' + (x * k).toFixed(2) + 'deg) rotateX(' + (-y * k * 0.8).toFixed(2) + 'deg)'; });
		};
		var out = function () { w.cancelAnimationFrame(raf); tilt.style.transform = ''; };
		if (k > 0 && sgc.fine() && !sgc.reduced()) { stage.addEventListener('pointermove', move); stage.addEventListener('pointerleave', out); }
		restart();
		return {
			destroy: function () {
				clearTimeout(timer);
				offView();
				stage.removeEventListener('pointermove', move);
				stage.removeEventListener('pointerleave', out);
				stage.removeEventListener('mouseenter', enter);
				stage.removeEventListener('mouseleave', leave);
			}
		};
	});

	/* ---------------- grid ---------------- */
	sgc.widget('collection-grid', function (root) {
		var box = root.querySelector('.sg-cg');
		if (!box) { return null; }
		var per = parseInt(box.getAttribute('data-per'), 10) || 24;
		var useUrl = box.getAttribute('data-url') === '1' && !sgc.editing();
		var tabs = Array.prototype.slice.call(box.querySelectorAll('.sg-tab'));
		var pill = box.querySelector('.sg-tab-pill');
		var cells = Array.prototype.slice.call(box.querySelectorAll('.sg-cg-cell'));
		var more = box.querySelector('.sg-cg-more');
		var empty = box.querySelector('.sg-cg-empty');
		var cat = 'all', shown = per;
		var offs = [];
		var reveal = root.classList.contains('sg-cg-rv-yes') && !sgc.editing() && !sgc.reduced();
		var observe = function (cell, k) {
			if (!reveal) { cell.classList.add('is-in'); return; }
			cell.style.setProperty('--d', (k % 3) * 110 + 'ms');
			offs.push(sgc.inView(cell, function (v) { if (v) { cell.classList.add('is-in'); } }));
		};
		var placePill = function () {
			var a = box.querySelector('.sg-tab.is-active');
			if (!a || !pill) { return; }
			pill.style.width = a.offsetWidth + 'px';
			pill.style.top = a.offsetTop + 'px';
			pill.style.height = a.offsetHeight + 'px';
			pill.style.transform = 'translateX(' + a.offsetLeft + 'px)';
		};
		var apply = function () {
			var match = cells.filter(function (c) { return cat === 'all' || (' ' + c.getAttribute('data-cats') + ' ').indexOf(' ' + cat + ' ') > -1; });
			cells.forEach(function (c) { c.hidden = true; c.classList.remove('is-in'); });
			match.slice(0, shown).forEach(function (c, k) { c.hidden = false; observe(c, k); });
			if (more) { more.parentNode.hidden = match.length <= shown; }
			if (empty) { empty.hidden = match.length > 0; }
			tabs.forEach(function (t) {
				var on = t.getAttribute('data-cat') === cat;
				t.classList.toggle('is-active', on);
				t.setAttribute('aria-selected', on ? 'true' : 'false');
			});
			placePill();
		};
		tabs.forEach(function (t) {
			t.addEventListener('click', function () {
				cat = t.getAttribute('data-cat');
				shown = per;
				apply();
				if (useUrl) {
					var u = new URL(w.location.href);
					if (cat === 'all') { u.searchParams.delete('cat'); } else { u.searchParams.set('cat', cat); }
					w.history.replaceState(null, '', u.href);
				}
			});
			t.addEventListener('keydown', function (e) {
				if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') { return; }
				var i = tabs.indexOf(t) + (e.key === 'ArrowRight' ? 1 : -1);
				var nx = tabs[(i + tabs.length) % tabs.length];
				nx.focus(); nx.click();
			});
		});
		if (more) { more.addEventListener('click', function () { shown += per; apply(); }); }
		if (useUrl) {
			var q = new URL(w.location.href).searchParams.get('cat');
			if (q && tabs.some(function (t) { return t.getAttribute('data-cat') === q; })) { cat = q; }
		}
		apply();
		var onResize = function () { placePill(); };
		w.addEventListener('resize', onResize);
		if (d.fonts && d.fonts.ready) { d.fonts.ready.then(placePill); }
		return { destroy: function () { w.removeEventListener('resize', onResize); offs.forEach(function (f) { f(); }); } };
	});
}(window, document));

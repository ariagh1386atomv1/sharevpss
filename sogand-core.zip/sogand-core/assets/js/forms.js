/* Sogand forms: inquiry form, Join the Journey sign-up, FAQ search.
   Validation is repeated on the server; recipients are never sent from the page. */
(function (w, d) {
	'use strict';
	var sgc = w.sgc;
	if (!sgc) { return; }

	var validEmail = function (v) { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(v || '').trim()); };
	var msgsOf = function (el) { try { return JSON.parse(el.getAttribute('data-msgs') || '{}'); } catch (e) { return {}; } };
	var dataOf = function (form) {
		var out = {};
		Array.prototype.forEach.call(form.elements, function (f) {
			if (!f.name || f.disabled) { return; }
			if ((f.type === 'checkbox' || f.type === 'radio') && !f.checked) { return; }
			out[f.name] = f.value;
		});
		return out;
	};
	var resetTurnstile = function (form) {
		var ts = form.querySelector('.cf-turnstile');
		if (ts && w.turnstile && typeof w.turnstile.reset === 'function') { try { w.turnstile.reset(ts); } catch (e) { /* ignore */ } }
	};

	/* ---------------- inquiry form ---------------- */
	sgc.widget('contact-form', function (root) {
		var box = root.querySelector('[data-sg-form="contact"]');
		if (!box) { return null; }
		var form = box.querySelector('form');
		var note = box.querySelector('.sg-f-note');
		var done = box.querySelector('.sg-form-done');
		var btn = form.querySelector('[type="submit"]');
		var btnT = btn.querySelector('.sg-btn-t');
		var btnLabel = btnT ? btnT.textContent : '';
		var m = msgsOf(box);

		/* pre-fill from links like /contact/?service=bespoke-jewelry&piece=Blue%20Bow%20Set */
		if (!sgc.editing()) {
			try {
				var q = new URL(w.location.href).searchParams;
				var svc = form.querySelector('select[name="service"]');
				if (svc && q.get('service')) {
					var v = q.get('service');
					if (Array.prototype.some.call(svc.options, function (o) { return o.value === v; })) { svc.value = v; }
				}
				var piece = form.querySelector('[name="piece"]');
				if (piece && q.get('piece')) { piece.value = q.get('piece').slice(0, 200); }
			} catch (e) { /* old browsers */ }
		}

		var setErr = function (name, text) {
			var f = form.querySelector('[name="' + name + '"]');
			if (!f) { return; }
			var wrap = f.closest('.sg-f, .sg-f-check');
			var em = wrap ? wrap.querySelector('.sg-f-err') : null;
			if (wrap) { wrap.classList.toggle('has-err', !!text); }
			f.setAttribute('aria-invalid', text ? 'true' : 'false');
			if (em) {
				em.textContent = text || '';
				em.hidden = !text;
				if (text) { f.setAttribute('aria-describedby', em.id); } else { f.removeAttribute('aria-describedby'); }
			}
		};
		var say = function (state, text) {
			note.className = 'sg-f-note is-' + state;
			note.textContent = text || '';
		};
		var validate = function (data) {
			var errs = {};
			if (!data.name || data.name.trim().length < 2) { errs.name = m.name; }
			if (!validEmail(data.email)) { errs.email = m.email; }
			if (!data.message || data.message.trim().length < 10) { errs.message = m.message; }
			if (form.querySelector('[name="consent"]') && !data.consent) { errs.consent = m.consent; }
			['name', 'email', 'message', 'consent'].forEach(function (k) { setErr(k, errs[k]); });
			return errs;
		};
		var onInput = function (e) {
			var wrap = e.target.closest && e.target.closest('.has-err');
			if (wrap) { setErr(e.target.name, ''); }
		};
		var onSubmit = function (e) {
			e.preventDefault();
			if (sgc.editing()) { say('err', ''); return; }
			var data = dataOf(form);
			var errs = validate(data);
			var keys = Object.keys(errs);
			if (keys.length) {
				say('err', m.all);
				var first = form.querySelector('[name="' + keys[0] + '"]');
				if (first) { first.focus(); }
				return;
			}
			delete data.consent;
			data.source = w.location.href.split('#')[0];
			btn.disabled = true;
			form.setAttribute('aria-busy', 'true');
			if (btnT) { btnT.textContent = m.sending || sgc.i18n.sending || '…'; }
			say('busy', m.sending);
			sgc.post('inquiry', data).then(function (r) {
				form.reset();
				say('idle', '');
				done.querySelector('.sg-form-done-m').textContent = (r && r.mailed === false) ? m.saved : m.ok;
				form.hidden = true;
				done.hidden = false;
				done.focus();
			}).catch(function (err) {
				say('err', err.message || sgc.i18n.error);
				resetTurnstile(form);
			}).then(function () {
				btn.disabled = false;
				form.removeAttribute('aria-busy');
				if (btnT) { btnT.textContent = btnLabel; }
			});
		};
		var again = done ? done.querySelector('[data-sg-again]') : null;
		var onAgain = function () {
			done.hidden = true;
			form.hidden = false;
			resetTurnstile(form);
			var f = form.querySelector('[name="name"]');
			if (f) { f.focus(); }
		};
		form.addEventListener('submit', onSubmit);
		form.addEventListener('input', onInput);
		form.addEventListener('change', onInput);
		if (again) { again.addEventListener('click', onAgain); }
		return {
			destroy: function () {
				form.removeEventListener('submit', onSubmit);
				form.removeEventListener('input', onInput);
				form.removeEventListener('change', onInput);
				if (again) { again.removeEventListener('click', onAgain); }
			}
		};
	});

	/* ---------------- Join the Journey ---------------- */
	sgc.widget('newsletter', function (root) {
		var form = root.querySelector('[data-sg-form="newsletter"]');
		if (!form) { return null; }
		var m = msgsOf(form);
		var msg = form.querySelector('.sg-nl-msg');
		var input = form.querySelector('input[type="email"]');
		var btn = form.querySelector('[type="submit"]');
		var say = function (state, text) { msg.className = 'sg-nl-msg is-' + state; msg.textContent = text || ''; };
		var onSubmit = function (e) {
			e.preventDefault();
			if (sgc.editing()) { return; }
			var data = dataOf(form);
			if (!validEmail(data.email)) {
				input.setAttribute('aria-invalid', 'true');
				say('err', m.email);
				input.focus();
				return;
			}
			input.setAttribute('aria-invalid', 'false');
			btn.disabled = true;
			say('busy', sgc.i18n.sending || '…');
			sgc.post('inquiry', data).then(function (r) {
				form.reset();
				say('ok', r && r.already ? m.already : m.ok);
			}).catch(function (err) {
				say('err', err.message || sgc.i18n.error);
			}).then(function () { btn.disabled = false; });
		};
		form.addEventListener('submit', onSubmit);
		return { destroy: function () { form.removeEventListener('submit', onSubmit); } };
	});

	/* ---------------- FAQ: search + one-open-at-a-time fallback ---------------- */
	sgc.widget('faq', function (root) {
		var box = root.querySelector('.sg-faq');
		if (!box) { return null; }
		var items = Array.prototype.slice.call(box.querySelectorAll('.sg-faq-item'));
		var groups = Array.prototype.slice.call(box.querySelectorAll('.sg-faq-group'));
		var input = box.querySelector('.sg-faq-search input');
		var none = box.querySelector('.sg-faq-none');
		var single = box.getAttribute('data-single') === '1';
		var topics = Array.prototype.slice.call(box.querySelectorAll('.sg-faq-topic'));
		var showGroup = function (k) {
			groups.forEach(function (g, i) { if (i === k) { g.removeAttribute('data-off'); } else { g.setAttribute('data-off', '1'); } });
			topics.forEach(function (t, i) { t.classList.toggle('is-on', i === k); t.setAttribute('aria-pressed', i === k ? 'true' : 'false'); });
		};
		var onTopic = function (e) {
			var t = e.target.closest('.sg-faq-topic');
			if (!t) { return; }
			showGroup(parseInt(t.getAttribute('data-g'), 10) || 0);
		};
		var norm = function (t) { return String(t || '').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim(); };
		var index = items.map(function (it) { return norm(it.textContent); });
		var onToggle = function (e) {
			var it = e.target;
			if (!single || !it.open) { return; }
			items.forEach(function (o) { if (o !== it && o.open) { o.open = false; } });
		};
		var onSearch = function () {
			var q = norm(input.value);
			var words = q ? q.split(' ') : [];
			var shown = 0;
			items.forEach(function (it, i) {
				var hit = words.every(function (wd) { return index[i].indexOf(wd) > -1; });
				it.hidden = !hit;
				if (hit) { shown++; }
			});
			groups.forEach(function (g) {
				g.hidden = !g.querySelector('.sg-faq-item:not([hidden])');
			});
			if (none) { none.hidden = shown > 0; }
			/* while searching, every matching group is shown; the topic list waits */
			box.classList.toggle('is-searching', !!q);
		};
		box.addEventListener('toggle', onToggle, true);
		box.addEventListener('click', onTopic);
		if (input) { input.addEventListener('input', onSearch); }
		return {
			destroy: function () {
				box.removeEventListener('toggle', onToggle, true);
				box.removeEventListener('click', onTopic);
				if (input) { input.removeEventListener('input', onSearch); }
			}
		};
	});
}(window, document));

/* Sogand Motion: plays only while needed (visible / hovered), pauses when the tab is hidden,
   redraws the self-drawing illustrations at an interval, honours reduced motion. */
(function (w, d) {
	'use strict';
	var sgc = w.sgc;
	if (!sgc) { return; }
	sgc.widget('motion', function (root, handler) {
		var box = root.querySelector('.sg-motion');
		if (!box) { return null; }
		var s = sgc.settings(handler);
		var trigger = s.trigger || 'view';
		var loop = s.loop === 'yes';
		var replay = parseFloat(s.replay);
		var visible = false, hovered = false, timer = 0, offView = null;
		var calm = sgc.reduced() || root.classList.contains('sg-mo-static-yes');
		if (calm) {
			box.classList.add('is-drawn');
			return null;
		}
		var draw = function () {
			box.classList.remove('is-drawn');
			void box.offsetWidth;
			box.classList.add('is-drawn');
		};
		var update = function () {
			var play = !sgc.hidden() && (trigger === 'always' || (trigger === 'view' && visible) || (trigger === 'hover' && hovered));
			box.classList.toggle('is-playing', play);
			if (play && !box.classList.contains('is-drawn')) { box.classList.add('is-drawn'); }
			clearInterval(timer);
			if (play && loop && replay > 0 && box.querySelector('.ill')) {
				timer = setInterval(draw, Math.max(3, replay) * 1000);
			}
		};
		if (trigger === 'view') {
			offView = sgc.inView(box, function (v) { visible = v; update(); }, false);
		}
		var host = root.closest('.e-con') || root;
		var enter = function () { hovered = true; update(); };
		var leave = function () { hovered = false; update(); };
		if (trigger === 'hover') {
			host.addEventListener('mouseenter', enter);
			host.addEventListener('mouseleave', leave);
			host.addEventListener('focusin', enter);
			host.addEventListener('focusout', leave);
			box.classList.add('is-drawn');
		}
		var vis = function () { update(); };
		d.addEventListener('visibilitychange', vis);
		update();
		return {
			destroy: function () {
				clearInterval(timer);
				if (offView) { offView(); }
				d.removeEventListener('visibilitychange', vis);
				host.removeEventListener('mouseenter', enter);
				host.removeEventListener('mouseleave', leave);
				host.removeEventListener('focusin', enter);
				host.removeEventListener('focusout', leave);
			}
		};
	});
}(window, document));

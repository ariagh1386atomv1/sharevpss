/* Sogand Work Gallery: transitions, autoplay (pauses on hover / zoom / hidden tab / off-screen),
   thumbnails, arrows, keyboard, hover zoom, swipe. */
(function (w, d) {
	'use strict';
	var sgc = w.sgc;
	if (!sgc) { return; }
	sgc.widget('work-gallery', function (root, handler) {
		var gal = root.querySelector('.sg-gal');
		if (!gal) { return null; }
		var s = sgc.settings(handler);
		var main = gal.querySelector('.sg-gal-main');
		var imgs = Array.prototype.slice.call(gal.querySelectorAll('.sg-gal-img'));
		var thumbs = Array.prototype.slice.call(gal.querySelectorAll('.sg-gal-thumb'));
		var timerEl = gal.querySelector('.sg-gal-timer');
		var zoomEl = gal.querySelector('.sg-gal-zoom');
		var live = gal.querySelector('[data-sg-live]');
		var n = imgs.length, cur = 0, t = 0, hover = false, visible = true;
		var fx = s.fx || 'fade';
		var auto = s.auto === 'yes' && n > 1 && !sgc.reduced();
		var every = Math.max(1, sgc.num(s.interval, 4)) * 1000;
		gal.style.setProperty('--gint', every + 'ms');
		var show = function (k) {
			k = ((k % n) + n) % n;
			if (k === cur) { return; }
			var old = imgs[cur], nw = imgs[k];
			imgs.forEach(function (im) { im.classList.remove('is-old', 'gfx', 'gfx-' + fx, 'is-current'); });
			old.classList.add('is-old');
			old.hidden = false;
			nw.hidden = false;
			nw.classList.add('is-current', 'gfx', 'gfx-' + fx);
			var dur = parseFloat(getComputedStyle(gal).getPropertyValue('--gdur')) || 800;
			setTimeout(function () { if (!old.classList.contains('is-current')) { old.hidden = true; old.classList.remove('is-old'); } }, dur + 60);
			cur = k;
			thumbs.forEach(function (b, i) {
				b.classList.toggle('is-active', i === cur);
				if (i === cur) { b.setAttribute('aria-current', 'true'); } else { b.removeAttribute('aria-current'); }
			});
			if (zoomEl) { zoomEl.style.backgroundImage = 'url("' + (nw.getAttribute('data-full') || nw.src) + '")'; }
			if (live) { live.textContent = nw.alt; }
			restart();
		};
		var restart = function () {
			clearTimeout(t);
			if (!auto) { return; }
			if (timerEl) { timerEl.classList.remove('is-run'); void timerEl.offsetWidth; timerEl.classList.add('is-run'); }
			t = setTimeout(function tick() {
				if (hover || sgc.hidden() || !visible) { t = setTimeout(tick, 400); return; }
				show(cur + 1);
			}, every);
		};
		thumbs.forEach(function (b, i) { b.addEventListener('click', function () { show(i); }); });
		Array.prototype.forEach.call(gal.querySelectorAll('[data-step]'), function (b) {
			b.addEventListener('click', function () { show(cur + parseInt(b.getAttribute('data-step'), 10)); });
		});
		gal.addEventListener('keydown', function (e) {
			if (e.key === 'ArrowRight') { show(cur + 1); }
			if (e.key === 'ArrowLeft') { show(cur - 1); }
		});
		var canZoom = s.zoom === 'yes' && zoomEl && sgc.fine();
		if (zoomEl) { zoomEl.style.backgroundImage = 'url("' + (imgs[0].getAttribute('data-full') || imgs[0].src) + '")'; }
		main.addEventListener('mouseenter', function () { hover = true; gal.classList.add('is-paused'); if (canZoom) { main.classList.add('is-zoom'); } });
		main.addEventListener('mouseleave', function () { hover = false; gal.classList.remove('is-paused'); main.classList.remove('is-zoom'); });
		main.addEventListener('mousemove', function (e) {
			if (!canZoom) { return; }
			var r = main.getBoundingClientRect();
			main.style.setProperty('--zx', ((e.clientX - r.left) / r.width * 100).toFixed(1) + '%');
			main.style.setProperty('--zy', ((e.clientY - r.top) / r.height * 100).toFixed(1) + '%');
		});
		var sx = null;
		main.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; }, { passive: true });
		main.addEventListener('touchend', function (e) { if (sx !== null && n > 1) { var dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 40) { show(cur + (dx < 0 ? 1 : -1)); } } sx = null; });
		var offView = sgc.inView(gal, function (v) { visible = v; }, false);
		restart();
		return { destroy: function () { clearTimeout(t); offView(); } };
	});
}(window, document));

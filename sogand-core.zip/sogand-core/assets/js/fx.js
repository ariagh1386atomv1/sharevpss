/* Sogand shared capabilities on any Elementor element:
   pointer tilt / parallax / magnet, scroll parallax, scroll-progress border, sticky,
   header behaviour, text reveal, image reveal, button magnetic + sparkles + click shine.
   Settings come from Elementor (data-settings on the site, the live model in the editor). */
(function (w, d) {
	'use strict';
	var sgc = w.sgc;
	if (!sgc) { return; }

	/* ------------------------------------------------------------ sparkles */
	var Spark = (function () {
		var canvas, ctx, dpr = 1, parts = [], running = false;
		var rgb = function (c, fb) {
			var s = String(c || '').trim(), m = s.match(/^#([0-9a-f]{3,8})$/i);
			if (m) {
				var h = m[1];
				if (h.length < 6) { h = h.split('').map(function (x) { return x + x; }).join(''); }
				return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
			}
			m = s.match(/^rgba?\(([^)]+)\)$/i);
			if (m) {
				var p = m[1].split(/[\s,/]+/).slice(0, 3).map(function (x) { return Math.round(parseFloat(x)); });
				if (p.length === 3 && !p.some(isNaN)) { return p; }
			}
			return fb;
		};
		var mix = function (a, b, t) { return a.map(function (x, i) { return Math.round(x + (b[i] - x) * t); }); };
		var pal = function (c, fb) { var b = rgb(c, fb); return [mix(b, [255, 255, 255], 0.35), b, mix(b, [0, 0, 0], 0.18), mix(b, [255, 255, 255], 0.6)]; };
		var ensure = function () {
			if (canvas) { return; }
			canvas = d.createElement('canvas');
			canvas.className = 'sg-sparkle-canvas';
			canvas.setAttribute('aria-hidden', 'true');
			d.body.appendChild(canvas);
			ctx = canvas.getContext('2d');
			var size = function () {
				dpr = Math.min(w.devicePixelRatio || 1, 2);
				canvas.width = w.innerWidth * dpr;
				canvas.height = w.innerHeight * dpr;
			};
			size();
			w.addEventListener('resize', size);
		};
		var star = function (c, r) { c.beginPath(); c.moveTo(0, -r); c.quadraticCurveTo(r * 0.16, -r * 0.16, r, 0); c.quadraticCurveTo(r * 0.16, r * 0.16, 0, r); c.quadraticCurveTo(-r * 0.16, r * 0.16, -r, 0); c.quadraticCurveTo(-r * 0.16, -r * 0.16, 0, -r); c.fill(); };
		var dia = function (c, r) { c.beginPath(); c.moveTo(0, -r); c.lineTo(r * 0.62, 0); c.lineTo(0, r); c.lineTo(-r * 0.62, 0); c.closePath(); c.fill(); };
		var tick = function () {
			ctx.setTransform(1, 0, 0, 1, 0, 0);
			ctx.clearRect(0, 0, canvas.width, canvas.height);
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			ctx.globalCompositeOperation = 'lighter';
			var next = [];
			parts.forEach(function (p) {
				p.life -= 1;
				if (p.life <= 0 || p.y > w.innerHeight + 20) { return; }
				p.vx *= 0.985; p.vy = p.vy * 0.985 + p.g; p.x += p.vx; p.y += p.vy; p.rot += p.vr;
				var t = p.life / p.max, fl = 0.55 + 0.45 * Math.sin((p.max - p.life) * p.fs + p.ph);
				ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
				ctx.globalAlpha = Math.min(0.85, t * 1.4) * fl;
				ctx.fillStyle = 'rgb(' + p.col.join(',') + ')';
				if (p.shape === 0) { star(ctx, p.s * 1.5); } else if (p.shape === 1) { dia(ctx, p.s * 1.2); } else { ctx.beginPath(); ctx.arc(0, 0, p.s * 0.55, 0, Math.PI * 2); ctx.fill(); }
				ctx.restore();
				next.push(p);
			});
			parts = next;
			if (parts.length) { w.requestAnimationFrame(tick); } else { running = false; ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, canvas.width, canvas.height); }
		};
		return {
			burst: function (x, y, n) {
				var site = w.sgcSite && w.sgcSite.spark;
				if (sgc.reduced() || n <= 0) { return; }
				ensure();
				var G = pal(site ? site.c1 : '#e9cd8c', [233, 205, 140]), S = pal(site ? site.c2 : '#e6eaf0', [214, 219, 226]);
				for (var i = 0; i < n; i++) {
					var a = -Math.PI / 2 + (Math.random() - 0.5) * Math.PI * 0.9, sp = 1.6 + Math.random() * 3.4;
					var P = Math.random() < 0.55 ? G : S, max = 60 * (0.67 + Math.random() * 0.67);
					parts.push({ x: x + (Math.random() - 0.5) * 18, y: y + (Math.random() - 0.5) * 8, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 1.2, g: 0.11 + Math.random() * 0.08, s: 1.2 + Math.random() * 2.2, rot: Math.random() * Math.PI, vr: (Math.random() - 0.5) * 0.25, col: P[(Math.random() * P.length) | 0], shape: Math.random() < 0.4 ? 0 : (Math.random() < 0.6 ? 1 : 2), life: max, max: max, fs: 0.25 + Math.random() * 0.35, ph: Math.random() * 6 });
				}
				if (!running) { running = true; w.requestAnimationFrame(tick); }
			}
		};
	}());

	/* buttons: click shine + sparkles (one delegated listener for the whole page) */
	d.addEventListener('pointerdown', function (e) {
		var btn = e.target.closest && e.target.closest('.elementor-widget-button .elementor-button, .sg-btn');
		if (!btn || btn.disabled || sgc.editing()) { return; }
		var wrap = btn.closest('.elementor-element') || btn;
		var body = d.body.classList;
		var shine = (body.contains('sgk-shine-on') && !wrap.classList.contains('sg-shine-off')) || wrap.classList.contains('sg-shine-on');
		if (shine && !(wrap.classList.contains('sg-stouch-none') && e.pointerType === 'touch')) {
			btn.classList.remove('is-shining');
			void btn.offsetWidth;
			btn.classList.add('is-shining');
			setTimeout(function () { btn.classList.remove('is-shining'); }, 900);
		}
		var spark = (body.contains('sgk-spk-on') && !wrap.classList.contains('sg-spk-off')) || wrap.classList.contains('sg-spk-on');
		if (spark) {
			var n = (w.sgcSite && w.sgcSite.spark && w.sgcSite.spark.n) || 80;
			Spark.burst(e.clientX, e.clientY, Math.round(n * (btn.classList.contains('elementor-size-xs') || btn.classList.contains('elementor-size-sm') ? 0.55 : 1) / 3));
		}
	}, { passive: true });

	/* ------------------------------------------------------------ helpers */
	var areaOf = function (el, area) {
		if (area === 'parent') { return (el.parentElement && el.parentElement.closest('.elementor-element')) || el; }
		if (area === 'section') {
			var top = el, p = el.parentElement && el.parentElement.closest('.e-con, .elementor-section');
			while (p) { top = p; p = p.parentElement && p.parentElement.closest('.e-con, .elementor-section'); }
			return top;
		}
		return el;
	};

	/* ------------------------------------------------------------ features */
	var features = {
		pointer: function (el, s) {
			var mode = s.sg_ptr;
			if (!mode || !sgc.fine() || sgc.reduced()) { return null; }
			var k = sgc.num(s.sg_ptr_k, 12);
			var host = areaOf(el, s.sg_ptr_area || 'self');
			el.classList.add('sg-fxt');
			var glare = null;
			if (mode === 'tilt' && el.classList.contains('sg-glare-yes')) {
				glare = d.createElement('span');
				glare.className = 'sg-glare';
				glare.setAttribute('aria-hidden', 'true');
				el.appendChild(glare);
			}
			var raf = 0;
			var move = function (e) {
				var r = host.getBoundingClientRect();
				var x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
				w.cancelAnimationFrame(raf);
				raf = w.requestAnimationFrame(function () {
					if (mode === 'tilt') {
						el.style.setProperty('--sg-ptr-ry', (x * k).toFixed(2) + 'deg');
						el.style.setProperty('--sg-ptr-rx', (-y * k * 0.8).toFixed(2) + 'deg');
						if (glare) { el.style.setProperty('--sg-gx', ((x + 0.5) * 100).toFixed(1) + '%'); el.style.setProperty('--sg-gy', ((y + 0.5) * 100).toFixed(1) + '%'); }
					} else if (mode === 'parallax') {
						el.style.setProperty('--sg-ptr-x', (x * k * 2).toFixed(1) + 'px');
						el.style.setProperty('--sg-ptr-y', (y * k * 2).toFixed(1) + 'px');
					} else if (mode === 'magnet') {
						var er = el.getBoundingClientRect();
						el.style.setProperty('--sg-ptr-x', ((e.clientX - er.left - er.width / 2) * k / 60).toFixed(1) + 'px');
						el.style.setProperty('--sg-ptr-y', ((e.clientY - er.top - er.height / 2) * k / 60).toFixed(1) + 'px');
					}
				});
			};
			var leave = function () {
				w.cancelAnimationFrame(raf);
				['--sg-ptr-x', '--sg-ptr-y', '--sg-ptr-rx', '--sg-ptr-ry'].forEach(function (p) { el.style.removeProperty(p); });
			};
			host.addEventListener('pointermove', move);
			host.addEventListener('pointerleave', leave);
			return function () {
				host.removeEventListener('pointermove', move);
				host.removeEventListener('pointerleave', leave);
				leave();
				el.classList.remove('sg-fxt');
				if (glare) { glare.remove(); }
			};
		},

		parallax: function (el, s) {
			var k = Math.max(-1, Math.min(1, sgc.num(s.sg_scroll_par, 0)));
			if (!k || sgc.reduced()) { return null; }
			el.classList.add('sg-fxt', 'sg-par-live');
			var off = sgc.onScroll(function () {
				var r = el.getBoundingClientRect();
				var c = r.top + r.height / 2 - w.innerHeight / 2;
				el.style.setProperty('--sg-par-y', (c * k * -0.35).toFixed(1) + 'px');
			});
			return function () { off(); el.style.removeProperty('--sg-par-y'); el.classList.remove('sg-par-live'); if (!s.sg_ptr) { el.classList.remove('sg-fxt'); } };
		},

		progress: function (el, s) {
			if (s.sg_pb !== 'on') { return null; }
			var edges = Array.isArray(s.sg_pb_edges) && s.sg_pb_edges.length ? s.sg_pb_edges : ['bottom'];
			var order = ['top', 'right', 'bottom', 'left'].filter(function (e) { return edges.indexOf(e) > -1; });
			var layer = d.createElement('span');
			layer.className = 'sg-pb-layer';
			layer.setAttribute('aria-hidden', 'true');
			layer.setAttribute('data-dir', s.sg_pb_dir || 'start');
			layer.setAttribute('data-seq', s.sg_pb_seq || 'together');
			var bars = order.map(function (e) { var i = d.createElement('i'); i.setAttribute('data-e', e); layer.appendChild(i); return i; });
			if (getComputedStyle(el).position === 'static') { el.style.position = 'relative'; }
			el.appendChild(layer);
			var start = sgc.num(s.sg_pb_start, 0) / 100, end = sgc.num(s.sg_pb_end, 100) / 100;
			if (end <= start) { end = Math.min(1, start + 0.1); }
			var smooth = Math.min(0.95, Math.max(0, sgc.num(s.sg_pb_smooth, 0)));
			var hide = Array.isArray(s.sg_pb_hide) ? s.sg_pb_hide : [];
			var cur = 0;
			var raw = function () {
				if (s.sg_pb_source === 'element') {
					var r = el.getBoundingClientRect(), total = r.height + w.innerHeight;
					return Math.min(1, Math.max(0, (w.innerHeight - r.top) / total));
				}
				var h = d.documentElement.scrollHeight - w.innerHeight;
				return h > 0 ? Math.min(1, Math.max(0, (w.scrollY || 0) / h)) : 0;
			};
			var paint = function (p) {
				var seq = (s.sg_pb_seq || 'together') === 'sequential' && bars.length > 1;
				bars.forEach(function (b, i) {
					var v = seq ? Math.min(1, Math.max(0, p * bars.length - i)) : p;
					b.style.setProperty('--p', v.toFixed(4));
				});
			};
			var raf = 0;
			var step = function () {
				raf = 0;
				var target = Math.min(1, Math.max(0, (raw() - start) / (end - start)));
				cur = smooth ? cur + (target - cur) * (1 - smooth) : target;
				paint(cur);
				if (smooth && Math.abs(target - cur) > 0.001) { raf = w.requestAnimationFrame(step); }
			};
			var off = sgc.onScroll(function () {
				layer.style.display = hide.indexOf(sgc.device()) > -1 ? 'none' : '';
				if (!raf) { raf = w.requestAnimationFrame(step); }
			});
			return function () { off(); if (raf) { w.cancelAnimationFrame(raf); } layer.remove(); };
		},

		sticky: function (el, s) {
			if (s.sg_sticky !== 'yes') { return null; }
			var on = Array.isArray(s.sg_sticky_on) ? s.sg_sticky_on : ['desktop', 'tablet'];
			var patched = [];
			var apply = function () {
				var live = on.indexOf(sgc.device()) > -1;
				el.classList.toggle('sg-sticky-live', live);
				var parent = el.parentElement;
				var dir = parent ? getComputedStyle(parent).flexDirection : '';
				el.classList.toggle('sg-sticky-row', live && /^row/.test(dir || ''));
				/* position:sticky stops working under overflow:hidden — switch ancestors to overflow:clip (looks the same) */
				if (live && !patched.length) {
					var p = el.parentElement;
					while (p && p !== d.body) {
						var cs = getComputedStyle(p);
						if (cs.overflow === 'hidden' || cs.overflowY === 'hidden' || cs.overflowX === 'hidden') {
							patched.push([p, p.style.overflow]);
							p.style.overflow = 'clip';
						}
						p = p.parentElement;
					}
				}
			};
			apply();
			var t = 0;
			var onResize = function () { clearTimeout(t); t = setTimeout(apply, 120); };
			w.addEventListener('resize', onResize);
			return function () {
				w.removeEventListener('resize', onResize);
				el.classList.remove('sg-sticky-live', 'sg-sticky-row');
				patched.forEach(function (x) { x[0].style.overflow = x[1]; });
			};
		},

		header: function (el, s) {
			if (!s.sg_hdr) { return null; }
			var offset = parseInt(s.sg_hdr_offset, 10);
			if (isNaN(offset)) { offset = 30; }
			var last = 0;
			var root = d.documentElement;
			var setH = function () { root.style.setProperty('--sg-header-h', Math.round(el.getBoundingClientRect().height) + 'px'); };
			var ro = 'ResizeObserver' in w ? new ResizeObserver(setH) : null;
			if (ro) { ro.observe(el); } else { setH(); }
			var off = sgc.onScroll(function (y) {
				el.classList.toggle('is-scrolled', y > offset);
				if (s.sg_hdr === 'smart' && !sgc.editing()) {
					if (y > 320 && y > last + 2) { el.classList.add('is-hidden'); }
					if (y < last - 2 || y < 320) { el.classList.remove('is-hidden'); }
				}
				last = y;
			});
			/* the header progress line / mega menus report "open" state here */
			return function () { off(); if (ro) { ro.disconnect(); } el.classList.remove('is-scrolled', 'is-hidden'); };
		},

		reveal: function (el, s) {
			var mode = s.sg_tr;
			if (!mode || mode === 'shimmer' || sgc.editing()) { return null; }
			var target = el.querySelector('.elementor-heading-title') || el.querySelector('.elementor-text-editor') || el.querySelector('p') || el;
			if (!target || target.getAttribute('data-sg-split')) { return null; }
			if (sgc.reduced()) { return null; }
			var delay = parseInt(s.sg_tr_delay, 10) || 0, stagger = parseInt(s.sg_tr_stagger, 10) || 80;
			var label = target.textContent.replace(/\s+/g, ' ').trim();
			target.setAttribute('data-sg-split', '1');
			var original = target.innerHTML;
			var k = 0;
			if (mode === 'type') {
				var text = target.textContent;
				target.setAttribute('aria-label', label);
				target.innerHTML = '<span class="sg-tr-target" aria-hidden="true"></span><span class="sg-caret" aria-hidden="true"></span>';
				var out = target.firstChild, timer = 0;
				var play = function () {
					var i = 0;
					timer = setTimeout(function tick() {
						out.textContent = text.slice(0, ++i);
						if (i < text.length) { timer = setTimeout(tick, Math.max(12, stagger * 0.5)); }
					}, delay);
				};
				var offT = s.sg_tr_trigger === 'load' ? (play(), function () {}) : sgc.inView(el, function (v) { if (v) { play(); } });
				return function () { clearTimeout(timer); offT(); target.innerHTML = original; target.removeAttribute('data-sg-split'); target.removeAttribute('aria-label'); };
			}
			/* wrap words (or letters) of every text node, keeping inline markup such as <span class="sg-accent">, <em>, <br> */
			var letters = mode === 'letters';
			var walk = function (node) {
				Array.prototype.slice.call(node.childNodes).forEach(function (n) {
					if (n.nodeType === 3) {
						var parts = n.textContent.split(/(\s+)/);
						var frag = d.createDocumentFragment();
						parts.forEach(function (p) {
							if (!p) { return; }
							if (/^\s+$/.test(p)) { frag.appendChild(d.createTextNode(p)); return; }
							var wd = d.createElement('span');
							wd.className = 'sg-w';
							wd.setAttribute('aria-hidden', 'true');
							(letters ? p.split('') : [p]).forEach(function (ch) {
								var i = d.createElement('span');
								i.className = 'sg-i';
								i.style.setProperty('--d', (delay + k++ * stagger) + 'ms');
								i.textContent = ch;
								wd.appendChild(i);
							});
							frag.appendChild(wd);
						});
						n.parentNode.replaceChild(frag, n);
					} else if (n.nodeType === 1 && n.tagName !== 'BR') {
						walk(n);
					}
				});
			};
			walk(target);
			var sr = d.createElement('span');
			sr.className = 'elementor-screen-only';
			sr.textContent = label;
			target.appendChild(sr);
			var show = function () { el.classList.add('sg-tr-in'); };
			var offV = s.sg_tr_trigger === 'load' ? (w.requestAnimationFrame(function () { w.requestAnimationFrame(show); }), function () {}) : sgc.inView(el, function (v) { if (v) { show(); } });
			return function () { offV(); el.classList.remove('sg-tr-in'); target.innerHTML = original; target.removeAttribute('data-sg-split'); };
		},

		imgReveal: function (el) {
			if (!/(^|\s)sg-rv-/.test(el.className)) { return null; }
			if (sgc.editing() || sgc.reduced()) { el.classList.add('is-in'); return function () {}; }
			return sgc.inView(el, function (v) { if (v) { el.classList.add('is-in'); } });
		},

		magnet: function (el, s) {
			if (!el.classList.contains('elementor-widget-button') || !sgc.fine() || sgc.reduced()) { return null; }
			var body = d.body.classList;
			var on = el.classList.contains('sg-mag-on') || (body.contains('sgk-mag-on') && !el.classList.contains('sg-mag-off'));
			if (!on) { return null; }
			var k = sgc.num(s.sg_magnet_k, (w.sgcSite && w.sgcSite.magk) || 0.25);
			var btn = el.querySelector('.elementor-button');
			if (!btn) { return null; }
			btn.classList.add('sg-mag-live');
			var move = function (e) {
				var r = btn.getBoundingClientRect();
				btn.style.translate = ((e.clientX - r.left - r.width / 2) * k).toFixed(1) + 'px ' + ((e.clientY - r.top - r.height / 2) * k).toFixed(1) + 'px';
			};
			var leave = function () { btn.style.translate = ''; };
			btn.addEventListener('pointermove', move);
			btn.addEventListener('pointerleave', leave);
			return function () { btn.removeEventListener('pointermove', move); btn.removeEventListener('pointerleave', leave); leave(); btn.classList.remove('sg-mag-live'); };
		}
	};

	/* steps: tabs, accordion and auto stepper for the “process” layouts (plain list without JS / in the editor) */
	features.steps = function (el) {
		var mode = el.classList.contains('sg-proc-tabs') ? 'tabs' : el.classList.contains('sg-proc-accordion') ? 'acc' : el.classList.contains('sg-proc-stepper') ? 'step' : '';
		if (!mode || sgc.editing() || !el.classList.contains('e-con')) { return null; }
		var steps = Array.prototype.slice.call(el.querySelectorAll(':scope > .sg-step, :scope > .e-con-inner > .sg-step'));
		if (steps.length < 2) { return null; }
		var uid = 'sgs' + Math.random().toString(36).slice(2, 8);
		var cur = 0, timer = 0, bar = null, hover = false, offView = function () {};
		var titleOf = function (st, k) {
			var h = st.querySelector('.sg-step-t .elementor-heading-title');
			return h ? h.textContent.trim() : String(k + 1);
		};
		var open = function (k, focus) {
			cur = k;
			steps.forEach(function (st, i) {
				st.classList.toggle('is-open', i === k);
				var t = st.querySelector('[data-sg-step-btn]');
				if (t) { t.setAttribute('aria-expanded', i === k ? 'true' : 'false'); }
			});
			if (bar) {
				Array.prototype.forEach.call(bar.children, function (b, i) {
					b.setAttribute('aria-selected', i === k ? 'true' : 'false');
					b.tabIndex = i === k ? 0 : -1;
					if (i === k && focus) { b.focus(); }
				});
			}
		};
		el.classList.add('sg-steps-js');
		var cleanups = [];
		if (mode === 'tabs') {
			bar = d.createElement('div');
			bar.className = 'sg-tabs-bar';
			bar.setAttribute('role', 'tablist');
			steps.forEach(function (st, k) {
				var b = d.createElement('button');
				b.type = 'button';
				b.setAttribute('role', 'tab');
				b.id = uid + 't' + k;
				b.setAttribute('aria-controls', uid + 'p' + k);
				b.textContent = titleOf(st, k);
				b.addEventListener('click', function () { open(k); });
				b.addEventListener('keydown', function (e) {
					if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') { e.preventDefault(); open((k + (e.key === 'ArrowRight' ? 1 : -1) + steps.length) % steps.length, true); }
				});
				bar.appendChild(b);
				st.id = st.id || uid + 'p' + k;
				st.setAttribute('role', 'tabpanel');
				st.setAttribute('aria-labelledby', b.id);
			});
			steps[0].parentNode.insertBefore(bar, steps[0]);
			cleanups.push(function () { if (bar && bar.parentNode) { bar.parentNode.removeChild(bar); } steps.forEach(function (st) { st.removeAttribute('role'); st.removeAttribute('aria-labelledby'); }); });
		}
		if (mode === 'acc') {
			steps.forEach(function (st, k) {
				var t = st.querySelector('.sg-step-t .elementor-heading-title');
				if (!t) { return; }
				t.setAttribute('data-sg-step-btn', '1');
				t.setAttribute('role', 'button');
				t.tabIndex = 0;
				var go = function () { if (st.classList.contains('is-open')) { st.classList.remove('is-open'); t.setAttribute('aria-expanded', 'false'); } else { open(k); } };
				t.addEventListener('click', go);
				t.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } });
			});
		}
		if (mode === 'step') {
			if (sgc.reduced()) { el.classList.remove('sg-steps-js'); return null; }
			var visible = false;
			var tick = function () {
				clearTimeout(timer);
				timer = setTimeout(function () {
					if (visible && !hover && !sgc.hidden()) { open((cur + 1) % steps.length); }
					tick();
				}, 3200);
			};
			offView = sgc.inView(el, function (v) { visible = v; }, false);
			var en = function () { hover = true; }, lv = function () { hover = false; };
			el.addEventListener('mouseenter', en);
			el.addEventListener('mouseleave', lv);
			steps.forEach(function (st, k) { st.addEventListener('click', function () { open(k); }); });
			cleanups.push(function () { el.removeEventListener('mouseenter', en); el.removeEventListener('mouseleave', lv); });
			tick();
		}
		open(0);
		return function () {
			clearTimeout(timer);
			offView();
			cleanups.forEach(function (f) { f(); });
			el.classList.remove('sg-steps-js');
			steps.forEach(function (st) { st.classList.remove('is-open'); });
		};
	};

	var setup = function (el, s) {
		var offs = [];
		Object.keys(features).forEach(function (k) {
			try {
				var off = features[k](el, s);
				if (typeof off === 'function') { offs.push(off); }
			} catch (e) { if (w.console) { w.console.warn('Sogand FX', k, e); } }
		});
		return function () { offs.forEach(function (f) { try { f(); } catch (e) { /* ignore */ } }); };
	};

	var attach = function () {
		if (!w.elementorFrontend || !w.elementorModules) { return; }
		var Base = w.elementorModules.frontend.handlers.Base;
		var Fx = Base.extend({
			onInit: function () {
				Base.prototype.onInit.apply(this, arguments);
				this.sgOff = setup(this.$element[0], sgc.settings(this));
			},
			onElementChange: function (prop) {
				if (String(prop).indexOf('sg_') !== 0) { return; }
				var self = this;
				clearTimeout(this.sgT);
				this.sgT = setTimeout(function () {
					if (self.sgOff) { self.sgOff(); }
					self.sgOff = setup(self.$element[0], sgc.settings(self));
				}, 120);
			},
			onDestroy: function () {
				if (this.sgOff) { this.sgOff(); }
				Base.prototype.onDestroy.apply(this, arguments);
			}
		});
		w.elementorFrontend.hooks.addAction('frontend/element_ready/global', function ($el) {
			var el = $el[0];
			if (!el || el.getAttribute('data-sg-fx') === '1' && !sgc.editing()) { return; }
			el.setAttribute('data-sg-fx', '1');
			w.elementorFrontend.elementsHandler.addHandler(Fx, { $element: $el });
		});
	};
	if (w.elementorFrontend && w.elementorFrontend.hooks) { attach(); } else { w.addEventListener('elementor/frontend/init', attach); }

	/* ------------------------------------------------------------ site extras */
	var extras = function () {
		var light = d.querySelector('.sg-cursor-light');
		if (light && sgc.fine() && !sgc.reduced()) {
			var raf = 0;
			w.addEventListener('pointermove', function (e) {
				w.cancelAnimationFrame(raf);
				raf = w.requestAnimationFrame(function () {
					light.style.setProperty('--mx', e.clientX + 'px');
					light.style.setProperty('--my', e.clientY + 'px');
					light.classList.add('is-on');
				});
			}, { passive: true });
			d.addEventListener('pointerleave', function () { light.classList.remove('is-on'); });
		}
		/* ornament: scroll-down hint */
		d.addEventListener('click', function (e) {
			var b = e.target.closest && e.target.closest('[data-sg-scroll]');
			if (!b) { return; }
			var sec = b.closest('.elementor-element.e-parent') || b.closest('.e-con');
			var next = sec && sec.nextElementSibling;
			var top = next ? next.getBoundingClientRect().top + w.scrollY - (parseFloat(getComputedStyle(d.documentElement).getPropertyValue('--sg-header-h')) || 0) : w.innerHeight;
			w.scrollTo({ top: top, behavior: sgc.reduced() ? 'auto' : 'smooth' });
		});
		/* ornament: spotlight follows the pointer over its container */
		if (sgc.fine()) {
			Array.prototype.forEach.call(d.querySelectorAll('.o-spot'), function (spot) {
				var host = spot.closest('.e-con') || spot.parentElement;
				host.addEventListener('pointermove', function (e) {
					var r = spot.getBoundingClientRect();
					spot.style.setProperty('--px', (e.clientX - r.left) + 'px');
					spot.style.setProperty('--py', (e.clientY - r.top) + 'px');
				});
			});
		}
		var bar = d.querySelector('.sg-readbar i');
		if (bar) {
			sgc.onScroll(function (y) {
				var h = d.documentElement.scrollHeight - w.innerHeight;
				bar.style.setProperty('--p', h > 0 ? Math.min(1, y / h).toFixed(4) : 0);
			});
		}
	};
	if (d.readyState === 'loading') { d.addEventListener('DOMContentLoaded', extras); } else { extras(); }
}(window, document));

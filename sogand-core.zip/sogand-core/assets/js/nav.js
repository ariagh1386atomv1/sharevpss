/* Sogand Navigation: hover/focus panels with close delay, keyboard support,
   full-screen mobile menu with focus trap, Escape and focus return. */
(function (w, d) {
	'use strict';
	var sgc = w.sgc;
	if (!sgc) { return; }

	sgc.widget('nav', function (root) {
		var nav = root.querySelector('.sg-nav');
		if (!nav) { return null; }
		var delay = parseInt(nav.getAttribute('data-delay'), 10);
		if (isNaN(delay)) { delay = 180; }
		var header = root.closest('[class*="sg-hdr-"]') || root.closest('header');
		var items = Array.prototype.slice.call(nav.querySelectorAll('.sg-nav-item.has-panel'));
		var timer = 0;
		var offs = [];
		var on = function (el, ev, fn, opt) { el.addEventListener(ev, fn, opt); offs.push(function () { el.removeEventListener(ev, fn, opt); }); };

		var setHeaderState = function () {
			if (!header) { return; }
			var open = nav.querySelector('.sg-nav-item.is-open') || nav.classList.contains('is-open');
			header.classList.toggle('has-mega', !!nav.querySelector('.sg-nav-item.is-open'));
			header.classList.toggle('is-open', nav.classList.contains('is-open'));
			return open;
		};
		var close = function (item, focusToggle) {
			(item ? [item] : items).forEach(function (it) {
				if (!it.classList.contains('is-open')) { return; }
				it.classList.remove('is-open');
				var t = it.querySelector('.sg-nav-toggle');
				if (t) {
					t.setAttribute('aria-expanded', 'false');
					if (focusToggle) { t.focus(); }
				}
			});
			setHeaderState();
		};
		var open = function (item) {
			clearTimeout(timer);
			items.forEach(function (it) { if (it !== item) { close(it); } });
			item.classList.add('is-open');
			var t = item.querySelector('.sg-nav-toggle');
			if (t) { t.setAttribute('aria-expanded', 'true'); }
			/* keep a normal dropdown inside the screen */
			var shell = item.querySelector('.sg-mega-shell');
			if (shell && !item.classList.contains('is-mega')) {
				shell.classList.remove('sg-flip');
				var r = shell.getBoundingClientRect();
				if (r.right > w.innerWidth - 12) { shell.classList.add('sg-flip'); }
			}
			setHeaderState();
		};
		items.forEach(function (it) {
			var toggle = it.querySelector('.sg-nav-toggle');
			var link = it.querySelector('.sg-nav-link');
			on(it, 'mouseenter', function () { if (sgc.fine()) { open(it); } });
			on(it, 'mouseleave', function () { if (sgc.fine()) { clearTimeout(timer); timer = setTimeout(function () { close(it); }, delay); } });
			on(toggle, 'click', function (e) {
				e.preventDefault();
				if (it.classList.contains('is-open')) { close(it); } else { open(it); }
			});
			on(link, 'keydown', function (e) {
				if (e.key === 'ArrowDown') { e.preventDefault(); open(it); var f = it.querySelector('.sg-mega a'); if (f) { f.focus(); } }
			});
			on(it, 'focusout', function () {
				setTimeout(function () { if (!it.contains(d.activeElement)) { close(it); } }, 10);
			});
			/* touch: the first tap on a link with a panel opens the panel */
			on(link, 'click', function (e) {
				if (!sgc.fine() && !it.classList.contains('is-open') && w.matchMedia('(hover: none)').matches) {
					e.preventDefault();
					open(it);
				}
			});
		});
		on(d, 'keydown', function (e) {
			if (e.key !== 'Escape') { return; }
			var openItem = nav.querySelector('.sg-nav-item.is-open');
			if (openItem) { close(openItem, true); }
			if (nav.classList.contains('is-open')) { setMobile(false, true); }
		});
		on(d, 'click', function (e) {
			if (!nav.contains(e.target)) { close(); }
		});

		/* ---------- mobile ---------- */
		var burger = nav.querySelector('.sg-burger');
		var panel = nav.querySelector('.sg-mnav');
		var setMobile = function (state, returnFocus) {
			if (!panel || !burger) { return; }
			nav.classList.toggle('is-open', state);
			burger.setAttribute('aria-expanded', state ? 'true' : 'false');
			if (state) {
				panel.hidden = false;
				d.documentElement.classList.add('sg-menu-open');
				var first = panel.querySelector('a, button');
				setTimeout(function () { if (first) { first.focus(); } }, 60);
			} else {
				d.documentElement.classList.remove('sg-menu-open');
				setTimeout(function () { if (!nav.classList.contains('is-open')) { panel.hidden = true; } }, 460);
				if (returnFocus) { burger.focus(); }
			}
			setHeaderState();
		};
		if (burger && panel) {
			on(burger, 'click', function () { setMobile(!nav.classList.contains('is-open')); });
			var closeBtn = panel.querySelector('.sg-mnav-close');
			if (closeBtn) { on(closeBtn, 'click', function () { setMobile(false, true); }); }
			Array.prototype.forEach.call(panel.querySelectorAll('.sg-mnav-toggle'), function (t) {
				on(t, 'click', function () {
					var sub = d.getElementById(t.getAttribute('aria-controls'));
					var openNow = t.getAttribute('aria-expanded') !== 'true';
					t.setAttribute('aria-expanded', openNow ? 'true' : 'false');
					if (sub) { sub.classList.toggle('is-open', openNow); }
				});
			});
			Array.prototype.forEach.call(panel.querySelectorAll('a'), function (a) {
				on(a, 'click', function () { setMobile(false); });
			});
			/* focus trap */
			on(panel, 'keydown', function (e) {
				if (e.key !== 'Tab') { return; }
				var f = Array.prototype.filter.call(panel.querySelectorAll('a[href], button'), function (x) { return x.offsetParent !== null; });
				if (!f.length) { return; }
				var a = f[0], z = f[f.length - 1];
				if (e.shiftKey && d.activeElement === a) { e.preventDefault(); z.focus(); } else if (!e.shiftKey && d.activeElement === z) { e.preventDefault(); a.focus(); }
			});
			/* leaving the mobile layout closes the panel */
			on(w, 'resize', function () {
				if (nav.classList.contains('is-open') && getComputedStyle(nav.querySelector('.sg-nav-mob-bar')).display === 'none') { setMobile(false); }
			});
		}
		return {
			destroy: function () {
				offs.forEach(function (f) { f(); });
				d.documentElement.classList.remove('sg-menu-open');
			}
		};
	});
}(window, document));

/* Sogand Marquee: clones the item group until the track is at least twice the visible
   width, keeps the speed in px/s after resizes and font loading, hides clones from
   assistive technology and keyboard, pauses off-screen and on request. */
(function (w, d) {
	'use strict';
	var sgc = w.sgc;
	if (!sgc) { return; }
	sgc.widget('marquee', function (root, handler) {
		var mq = root.querySelector('.sg-mq');
		if (!mq) { return null; }
		var s = sgc.settings(handler);
		var speed = sgc.num(s.speed, 40);
		var rows = Array.prototype.slice.call(mq.querySelectorAll('.sg-mq-row'));
		var build = function () {
			rows.forEach(function (row) {
				var track = row.querySelector('.sg-mq-track');
				var groups = track.querySelectorAll('.sg-mq-group');
				for (var i = groups.length - 1; i > 0; i--) { groups[i].remove(); }
				var first = track.querySelector('.sg-mq-group');
				if (!first) { return; }
				var gw = first.getBoundingClientRect().width;
				if (gw < 1) { return; }
				var need = Math.max(2, Math.ceil((row.getBoundingClientRect().width * 2) / gw) + 1);
				if (need % 2) { need++; }
				for (var k = 1; k < need; k++) {
					var c = first.cloneNode(true);
					c.setAttribute('aria-hidden', 'true');
					Array.prototype.forEach.call(c.querySelectorAll('a, button'), function (a) { a.setAttribute('tabindex', '-1'); });
					track.appendChild(c);
				}
				/* move exactly one group width per loop → seamless; duration from px/s */
				var shift = gw / (gw * need) * 100;
				track.style.setProperty('--sg-mq-shift', '-' + shift.toFixed(4) + '%');
				track.style.setProperty('--sg-mq-dur', (gw / Math.max(5, speed)).toFixed(2) + 's');
			});
		};
		build();
		var t = 0;
		var rebuild = function () { clearTimeout(t); t = setTimeout(build, 150); };
		var ro = 'ResizeObserver' in w ? new ResizeObserver(rebuild) : null;
		if (ro) { ro.observe(mq); } else { w.addEventListener('resize', rebuild); }
		if (d.fonts && d.fonts.ready) { d.fonts.ready.then(rebuild); }
		var offView = sgc.inView(mq, function (v) { mq.classList.toggle('is-off', !v); }, false);
		var btn = mq.querySelector('.sg-mq-pause');
		var toggle = function () {
			var p = !mq.classList.contains('is-paused');
			mq.classList.toggle('is-paused', p);
			btn.setAttribute('aria-pressed', p ? 'true' : 'false');
		};
		if (btn) { btn.addEventListener('click', toggle); }
		return {
			destroy: function () {
				clearTimeout(t);
				if (ro) { ro.disconnect(); } else { w.removeEventListener('resize', rebuild); }
				offView();
				if (btn) { btn.removeEventListener('click', toggle); }
			}
		};
	});
}(window, document));

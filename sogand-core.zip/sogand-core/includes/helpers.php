<?php
/**
 * Shared helpers: site contact settings, portfolio data, colour tones.
 *
 * @package SogandCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Defaults of the contact / mail settings (option `sogand_settings`, shared with older theme versions). */
function sgc_setting_defaults() {
	return array(
		'site_email'       => SGC_PRIMARY_EMAIL,
		'inbox_email'      => SGC_PRIMARY_EMAIL,
		'phone'            => '+968 99161823',
		'whatsapp'         => '',
		'instagram_handle' => 'JEWELYBYSOGAND',
		'instagram_url'    => 'https://www.instagram.com/jewelybysogand/',
		'from_name'        => 'Sogand Jewelry',
		'from_email'       => '',
		'smtp_on'          => '0',
		'smtp_host'        => '',
		'smtp_port'        => '465',
		'smtp_secure'      => 'ssl',
		'smtp_user'        => '',
		'smtp_pass'        => '',
		'autoreply_on'     => '1',
		'turnstile_site'   => '',
		'turnstile_secret' => '',
		'site_en'          => '1',
		'admin_fa'         => '1',
	);
}

function sgc_setting( $key ) {
	$o = get_option( 'sogand_settings', array() );
	$o = is_array( $o ) ? $o : array();
	$d = sgc_setting_defaults();
	if ( isset( $o[ $key ] ) && '' !== $o[ $key ] ) {
		return $o[ $key ];
	}
	return isset( $d[ $key ] ) ? $d[ $key ] : '';
}

function sgc_phone_link( $phone = null ) {
	$phone = null === $phone ? sgc_setting( 'phone' ) : $phone;
	return preg_replace( '/[^\d+]/', '', (string) $phone );
}

function sgc_whatsapp_url() {
	$n = preg_replace( '/\D+/', '', (string) sgc_setting( 'whatsapp' ) );
	return $n ? 'https://wa.me/' . $n : '';
}

/** Default halo colours, used when a work has no tone of its own. */
function sgc_tones() {
	return array( '#4f6fd6', '#b3263f', '#1f9e86', '#c9a35c', '#8b5966' );
}

function sgc_work_tone( $post_id, $index = 0 ) {
	$t = sanitize_hex_color( (string) get_post_meta( $post_id, '_sg_tone', true ) );
	if ( $t ) {
		return $t;
	}
	$tones = sgc_tones();
	return $tones[ absint( $index ) % count( $tones ) ];
}

/** Categories of the portfolio in their manual order (term meta `_sg_order`, then oldest first). */
function sgc_collection_terms( $hide_empty = false ) {
	$terms = get_terms( array( 'taxonomy' => 'sg_collection', 'hide_empty' => $hide_empty, 'orderby' => 'term_id', 'order' => 'ASC' ) );
	if ( ! $terms || is_wp_error( $terms ) ) {
		return array();
	}
	usort( $terms, function ( $a, $b ) {
		$oa = (int) get_term_meta( $a->term_id, '_sg_order', true );
		$ob = (int) get_term_meta( $b->term_id, '_sg_order', true );
		if ( $oa !== $ob ) {
			return $oa - $ob;
		}
		return $a->term_id - $b->term_id;
	} );
	return $terms;
}

/** Image sizes of one attachment. */
function sgc_img( $id ) {
	$id = absint( $id );
	if ( ! $id ) {
		return null;
	}
	$full = wp_get_attachment_image_src( $id, 'full' );
	if ( ! $full ) {
		return null;
	}
	$large  = wp_get_attachment_image_src( $id, 'large' );
	$square = wp_get_attachment_image_src( $id, 'sogand-square' );
	$medium = wp_get_attachment_image_src( $id, 'medium_large' );
	return array(
		'id'     => $id,
		'full'   => $full[0],
		'large'  => $large ? $large[0] : $full[0],
		'square' => $square ? $square[0] : ( $large ? $large[0] : $full[0] ),
		'medium' => $medium ? $medium[0] : ( $large ? $large[0] : $full[0] ),
		'w'      => (int) $full[1],
		'h'      => (int) $full[2],
		'alt'    => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
	);
}

function sgc_work_gallery_ids( $post_id ) {
	return array_values( array_filter( array_map( 'absint', explode( ',', (string) get_post_meta( $post_id, '_sg_gallery', true ) ) ) ) );
}

/** Labelled detail rows of a work (collection, materials, gemstones, technique, year, extra specs). */
function sgc_work_specs_rows( $post_id ) {
	$terms = get_the_terms( $post_id, 'sg_collection' );
	$rows  = array(
		array( __( 'Collection', 'sogand-site' ), ( $terms && ! is_wp_error( $terms ) ) ? implode( ', ', wp_list_pluck( $terms, 'name' ) ) : '' ),
		array( __( 'Materials', 'sogand-site' ), get_post_meta( $post_id, '_sg_materials', true ) ),
		array( __( 'Gemstones', 'sogand-site' ), get_post_meta( $post_id, '_sg_gemstones', true ) ),
		array( __( 'Technique', 'sogand-site' ), get_post_meta( $post_id, '_sg_technique', true ) ),
		array( __( 'Year', 'sogand-site' ), get_post_meta( $post_id, '_sg_year', true ) ),
	);
	foreach ( sgc_work_specs( $post_id ) as $sp ) {
		$rows[] = array( $sp['title'], $sp['value'] );
	}
	return array_values( array_filter( $rows, function ( $r ) {
		return '' !== trim( (string) $r[1] ) && '' !== trim( (string) $r[0] );
	} ) );
}

/** Ordered list of published works (menu order, newest first). */
function sgc_works_query_args( $extra = array() ) {
	return array_merge( array(
		'post_type'      => 'sg_work',
		'post_status'    => 'publish',
		'posts_per_page' => 60,
		'orderby'        => array( 'menu_order' => 'ASC', 'date' => 'DESC' ),
		'no_found_rows'  => true,
	), $extra );
}

/** The work that is being shown (single entry, or the preview post inside the editor). */
function sgc_current_work_id() {
	/* the post being looped first: inside card templates of a grid this is the card's work */
	$id = get_the_ID();
	if ( $id && 'sg_work' === get_post_type( $id ) ) {
		return (int) $id;
	}
	$id = get_queried_object_id();
	if ( $id && 'sg_work' === get_post_type( $id ) ) {
		return (int) $id;
	}
	/* Elementor template preview: use the first work so dynamic widgets show real content */
	$first = get_posts( sgc_works_query_args( array( 'posts_per_page' => 1, 'fields' => 'ids' ) ) );
	return $first ? (int) $first[0] : 0;
}

/** URL of the Collections page (page with the Collections role, else the work archive). */
function sgc_collections_url() {
	$pid = (int) get_option( 'sgc_page_collections' );
	if ( $pid && 'publish' === get_post_status( $pid ) ) {
		return get_permalink( $pid );
	}
	$p = get_page_by_path( 'collections' );
	if ( $p ) {
		return get_permalink( $p );
	}
	return home_url( '/' );
}

function sgc_page_url( $role ) {
	$pid = (int) get_option( 'sgc_page_' . $role );
	if ( $pid && 'publish' === get_post_status( $pid ) ) {
		return get_permalink( $pid );
	}
	$p = get_page_by_path( $role );
	return $p ? get_permalink( $p ) : home_url( '/' );
}

/** Asset URL bundled with the plugin. */
function sgc_asset( $rel ) {
	return SGC_URL . 'assets/' . ltrim( $rel, '/' );
}

function sgc_sanitize_color( $c, $fallback = '' ) {
	$c = trim( (string) $c );
	if ( '' === $c ) {
		return $fallback;
	}
	if ( preg_match( '/^#([0-9a-f]{3,8})$/i', $c ) || preg_match( '/^(rgb|hsl)a?\([\d\s.,%\/-]+\)$/i', $c ) || preg_match( '/^var\(--[a-z0-9-]+\)$/i', $c ) ) {
		return $c;
	}
	return $fallback;
}

/**
 * Empty the page caches of the common caching plugins, so a changed Site Setting (page transition,
 * effects, language) shows at once instead of after the cache expires.
 */
function sgc_purge_page_caches() {
	do_action( 'litespeed_purge_all' );
	if ( function_exists( 'rocket_clean_domain' ) ) {
		rocket_clean_domain();
	}
	if ( function_exists( 'w3tc_flush_all' ) ) {
		w3tc_flush_all();
	}
	if ( function_exists( 'wp_cache_clear_cache' ) ) {
		wp_cache_clear_cache();
	}
	if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
		sg_cachepress_purge_cache();
	}
	if ( isset( $GLOBALS['wp_fastest_cache'] ) && method_exists( $GLOBALS['wp_fastest_cache'], 'deleteCache' ) ) {
		$GLOBALS['wp_fastest_cache']->deleteCache( true );
	}
	do_action( 'sgc_purge_caches' );
}

/* Site Settings saved in Elementor → page caches emptied */
add_action( 'elementor/document/after_save', function ( $document ) {
	if ( is_object( $document ) && 'kit' === $document->get_name() ) {
		sgc_purge_page_caches();
	}
} );

/* Language / contact settings saved → generated Elementor CSS and page caches renewed */
add_action( 'update_option_sogand_settings', function ( $old, $new ) {
	$keys = array( 'site_en', 'admin_fa' );
	foreach ( $keys as $k ) {
		if ( ( isset( $old[ $k ] ) ? $old[ $k ] : '1' ) !== ( isset( $new[ $k ] ) ? $new[ $k ] : '1' ) ) {
			if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
				\Elementor\Plugin::$instance->files_manager->clear_cache();
			}
			break;
		}
	}
	sgc_purge_page_caches();
}, 10, 2 );

<?php
/**
 * Site Settings → Sogand tabs: effect defaults, page transitions and template
 * assignment. Values are stored in the active Elementor kit.
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor;

use Elementor\Controls_Manager;
use Elementor\Core\Kits\Documents\Tabs\Tab_Base;
use Elementor\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Kit_Sogand extends Tab_Base {

	/** Read a kit setting with a fallback. */
	public static function get( $key, $default = '' ) {
		static $cache = null;
		if ( null === $cache ) {
			$cache = array();
			if ( isset( Plugin::$instance->kits_manager ) ) {
				$kit = Plugin::$instance->kits_manager->get_active_kit_for_frontend();
				if ( $kit ) {
					$cache = (array) $kit->get_settings();
				}
			}
		}
		/* only a setting that was never saved falls back: a switched-off switcher is '' and must stay off */
		if ( ! array_key_exists( $key, $cache ) || null === $cache[ $key ] ) {
			return $default;
		}
		return $cache[ $key ];
	}

	/** Like get(), but an empty value also falls back (selects, numbers, colours). */
	public static function val( $key, $default = '' ) {
		$v = self::get( $key, $default );
		return ( '' === $v || array() === $v ) ? $default : $v;
	}

	public static function size( $key, $default ) {
		$v = self::get( $key, null );
		if ( is_array( $v ) && isset( $v['size'] ) && '' !== $v['size'] ) {
			return $v['size'];
		}
		return $default;
	}

	public function get_id() {
		return 'sogand-effects';
	}

	public function get_title() {
		return esc_html__( 'Sogand Effects', 'sogand-core' );
	}

	public function get_group() {
		return 'settings';
	}

	public function get_icon() {
		return 'eicon-star';
	}

	public function get_help_url() {
		return '';
	}

	protected function register_tab_controls() {
		$tab = $this->get_id();

		/* ---------------- glass ---------------- */
		$this->start_controls_section( 'sgk_glass', array( 'label' => esc_html__( 'Glass surfaces', 'sogand-core' ), 'tab' => $tab ) );
		$this->add_control( 'sgk_glass_note', array(
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => esc_html__( 'Default look of every element with “Sogand Glass” switched on (containers, cards, the header). Each element can override these values.', 'sogand-core' ),
			'content_classes' => 'elementor-descriptor',
		) );
		$this->add_control( 'sgk_gl_tint', array( 'label' => esc_html__( 'Tint', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'default' => 'rgba(74,35,41,0.34)', 'selectors' => array( '{{WRAPPER}}' => '--sgk-gl-tint: {{VALUE}};' ) ) );
		$this->add_control( 'sgk_gl_tint2', array( 'label' => esc_html__( 'Tint 2', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'default' => 'rgba(59,43,43,0.26)', 'selectors' => array( '{{WRAPPER}}' => '--sgk-gl-tint2: {{VALUE}};' ) ) );
		$this->add_control( 'sgk_gl_blur', array( 'label' => esc_html__( 'Backdrop blur', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 60 ) ), 'default' => array( 'size' => 18, 'unit' => 'px' ), 'selectors' => array( '{{WRAPPER}}' => '--sgk-gl-blur: {{SIZE}}px;' ) ) );
		$this->add_control( 'sgk_gl_sat', array( 'label' => esc_html__( 'Saturation (%)', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 250 ) ), 'default' => array( 'size' => 140, 'unit' => 'px' ), 'selectors' => array( '{{WRAPPER}}' => '--sgk-gl-sat: {{SIZE}}%;' ) ) );
		$this->add_control( 'sgk_gl_edge', array( 'label' => esc_html__( 'Edge colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'default' => 'rgba(255,255,255,0.14)', 'selectors' => array( '{{WRAPPER}}' => '--sgk-gl-edge: {{VALUE}};' ) ) );
		$this->add_control( 'sgk_gl_r', array( 'label' => esc_html__( 'Corner radius', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 80 ) ), 'default' => array( 'size' => 36, 'unit' => 'px' ), 'selectors' => array( '{{WRAPPER}}' => '--sgk-gl-r: {{SIZE}}px;' ) ) );
		$this->add_control( 'sgk_gl_shadow', array( 'label' => esc_html__( 'Shadow strength', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 1, 'step' => 0.05 ) ), 'default' => array( 'size' => 0.45, 'unit' => 'px' ), 'selectors' => array( '{{WRAPPER}}' => '--sgk-gl-shadow: {{SIZE}};' ) ) );
		$this->end_controls_section();

		/* ---------------- buttons ---------------- */
		$this->start_controls_section( 'sgk_btn', array( 'label' => esc_html__( 'Buttons: shine, magnetic, sparkles', 'sogand-core' ), 'tab' => $tab ) );
		$this->add_control( 'sgk_btn_note', array(
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => esc_html__( 'Button colours, typography and radius live in Site Settings → Buttons. These are the defaults for the Sogand extras on every native Button.', 'sogand-core' ),
			'content_classes' => 'elementor-descriptor',
		) );
		$this->add_control( 'sgk_shine', array( 'label' => esc_html__( 'Glass shine on buttons', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'default' => 'yes', 'return_value' => 'yes' ) );
		$this->add_control( 'sgk_shine_trigger', array(
			'label'   => esc_html__( 'Play on', 'sogand-core' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'hover',
			'options' => array(
				'hover'      => esc_html__( 'Hover & keyboard focus', 'sogand-core' ),
				'continuous' => esc_html__( 'Continuously (with pause)', 'sogand-core' ),
				'click'      => esc_html__( 'Click only', 'sogand-core' ),
			),
			'condition' => array( 'sgk_shine' => 'yes' ),
		) );
		$this->add_control( 'sgk_sh_c', array( 'label' => esc_html__( 'Highlight colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'default' => 'rgba(255,244,214,0.85)', 'selectors' => array( '{{WRAPPER}}' => '--sgk-sh-c: {{VALUE}};' ) ) );
		$this->add_control( 'sgk_sh_c2', array( 'label' => esc_html__( 'Metal edge colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'default' => 'rgba(230,234,240,0.9)', 'selectors' => array( '{{WRAPPER}}' => '--sgk-sh-c2: {{VALUE}};' ) ) );
		$this->add_control( 'sgk_sh_dur', array( 'label' => esc_html__( 'Duration (ms)', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 200, 'max' => 4000, 'step' => 50 ) ), 'default' => array( 'size' => 1100, 'unit' => 'px' ), 'selectors' => array( '{{WRAPPER}}' => '--sgk-sh-dur: {{SIZE}}ms;' ) ) );
		$this->add_control( 'sgk_sh_every', array( 'label' => esc_html__( 'Repeat every (s, continuous)', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 1, 'max' => 20, 'step' => 0.5 ) ), 'default' => array( 'size' => 5, 'unit' => 'px' ), 'selectors' => array( '{{WRAPPER}}' => '--sgk-sh-every: {{SIZE}}s;' ) ) );
		$this->add_control( 'sgk_magnet', array( 'label' => esc_html__( 'Magnetic buttons', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'default' => 'yes', 'return_value' => 'yes', 'separator' => 'before' ) );
		$this->add_control( 'sgk_magnet_k', array( 'label' => esc_html__( 'Magnetic strength', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0.05, 'max' => 0.8, 'step' => 0.01 ) ), 'default' => array( 'size' => 0.25, 'unit' => 'px' ), 'condition' => array( 'sgk_magnet' => 'yes' ) ) );
		$this->add_control( 'sgk_sparkle', array( 'label' => esc_html__( 'Click sparkles', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'default' => 'yes', 'return_value' => 'yes', 'separator' => 'before' ) );
		$this->add_control( 'sgk_sparkle_n', array( 'label' => esc_html__( 'Sparkles per click', 'sogand-core' ), 'type' => Controls_Manager::NUMBER, 'min' => 4, 'max' => 160, 'default' => 80, 'condition' => array( 'sgk_sparkle' => 'yes' ) ) );
		$this->add_control( 'sgk_sparkle_c1', array( 'label' => esc_html__( 'Sparkle gold', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'default' => '#e9cd8c', 'condition' => array( 'sgk_sparkle' => 'yes' ) ) );
		$this->add_control( 'sgk_sparkle_c2', array( 'label' => esc_html__( 'Sparkle silver', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'default' => '#e6eaf0', 'condition' => array( 'sgk_sparkle' => 'yes' ) ) );
		$this->end_controls_section();

		/* ---------------- light & images ---------------- */
		$this->start_controls_section( 'sgk_light', array( 'label' => esc_html__( 'Glow, image fades & motion', 'sogand-core' ), 'tab' => $tab ) );
		$this->add_control( 'sgk_glow_c1', array( 'label' => esc_html__( 'Default glow colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'default' => '#b3263f', 'selectors' => array( '{{WRAPPER}}' => '--sgk-glow-c1: {{VALUE}};' ) ) );
		$this->add_control( 'sgk_glow_op', array( 'label' => esc_html__( 'Glow opacity', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 1, 'step' => 0.05 ) ), 'default' => array( 'size' => 0.75, 'unit' => 'px' ), 'selectors' => array( '{{WRAPPER}}' => '--sgk-glow-op: {{SIZE}};' ) ) );
		$this->add_control( 'sgk_glow_blur', array( 'label' => esc_html__( 'Glow blur', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 150 ) ), 'default' => array( 'size' => 30, 'unit' => 'px' ), 'selectors' => array( '{{WRAPPER}}' => '--sgk-glow-blur: {{SIZE}}px;' ) ) );
		$this->add_control( 'sgk_fsoft', array( 'label' => esc_html__( 'Image fade softness', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 1, 'step' => 0.05 ) ), 'default' => array( 'size' => 0.3, 'unit' => 'px' ), 'selectors' => array( '{{WRAPPER}}' => '--sgk-fsoft: {{SIZE}};' ) ) );
		$this->add_control( 'sgk_motion', array( 'label' => esc_html__( 'Motion speed (all loops)', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0.25, 'max' => 3, 'step' => 0.05 ) ), 'default' => array( 'size' => 1, 'unit' => 'px' ), 'selectors' => array( '{{WRAPPER}}' => '--sgk-speed: {{SIZE}};' ), 'description' => esc_html__( '1 = designed speed, 2 = twice as fast.', 'sogand-core' ) ) );
		$this->add_control( 'sg_reduce_motion', array(
			'label'       => esc_html__( 'Reduced motion', 'sogand-core' ),
			'type'        => Controls_Manager::SELECT,
			'default'     => 'system',
			'options'     => array(
				'system' => esc_html__( 'Follow the visitor’s system setting', 'sogand-core' ),
				'always' => esc_html__( 'Always calm (no loops, no parallax)', 'sogand-core' ),
			),
			'description' => esc_html__( 'Content always stays visible; only movement is removed.', 'sogand-core' ),
		) );
		$this->end_controls_section();

		/* ---------------- site extras ---------------- */
		$this->start_controls_section( 'sgk_extras', array( 'label' => esc_html__( 'Site extras', 'sogand-core' ), 'tab' => $tab ) );
		$this->add_control( 'sgk_cursor_light', array( 'label' => esc_html__( 'Soft light following the mouse', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes' ) );
		$this->add_control( 'sgk_cursor_light_c', array( 'label' => esc_html__( 'Light colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'default' => 'rgba(220,224,195,0.09)', 'condition' => array( 'sgk_cursor_light' => 'yes' ), 'selectors' => array( '{{WRAPPER}}' => '--sgk-cl-c: {{VALUE}};' ) ) );
		$this->add_control( 'sgk_cursor_light_s', array( 'label' => esc_html__( 'Light size', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 120, 'max' => 1200 ) ), 'default' => array( 'size' => 520, 'unit' => 'px' ), 'condition' => array( 'sgk_cursor_light' => 'yes' ), 'selectors' => array( '{{WRAPPER}}' => '--sgk-cl-s: {{SIZE}}px;' ) ) );
		$this->add_control( 'sgk_progress', array( 'label' => esc_html__( 'Reading progress bar at the top of the window', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'separator' => 'before', 'description' => esc_html__( 'Independent from the header’s own progress line.', 'sogand-core' ) ) );
		$this->add_control( 'sgk_progress_c', array( 'label' => esc_html__( 'Bar colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'condition' => array( 'sgk_progress' => 'yes' ), 'selectors' => array( '{{WRAPPER}}' => '--sgk-pg-c: {{VALUE}};' ) ) );
		$this->add_control( 'sgk_progress_h', array( 'label' => esc_html__( 'Bar height', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 1, 'max' => 8 ) ), 'default' => array( 'size' => 2, 'unit' => 'px' ), 'condition' => array( 'sgk_progress' => 'yes' ), 'selectors' => array( '{{WRAPPER}}' => '--sgk-pg-h: {{SIZE}}px;' ) ) );
		$this->add_control( 'sgk_grain', array( 'label' => esc_html__( 'Film grain over the page', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'separator' => 'before' ) );
		$this->add_control( 'sgk_grain_op', array( 'label' => esc_html__( 'Grain strength', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0.01, 'max' => 0.2, 'step' => 0.01 ) ), 'default' => array( 'size' => 0.05, 'unit' => 'px' ), 'condition' => array( 'sgk_grain' => 'yes' ), 'selectors' => array( '{{WRAPPER}}' => '--sgk-grain: {{SIZE}};' ) ) );
		$this->add_control( 'sgk_preloader', array( 'label' => esc_html__( 'Preloader with the logo', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'separator' => 'before', 'description' => esc_html__( 'Shown once per visit while the first page loads; never longer than 3 seconds.', 'sogand-core' ) ) );
		$this->add_control( 'sgk_preloader_bg', array( 'label' => esc_html__( 'Preloader background', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'default' => '#1d0f11', 'condition' => array( 'sgk_preloader' => 'yes' ), 'selectors' => array( '{{WRAPPER}}' => '--sgk-pl-bg: {{VALUE}};' ) ) );
		$this->add_control( 'sgk_selection', array( 'label' => esc_html__( 'Text selection colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'default' => 'rgba(220,224,195,0.25)', 'separator' => 'before', 'selectors' => array( '{{WRAPPER}} ::selection' => 'background: {{VALUE}};' ) ) );
		$this->add_control( 'sgk_scrollbar', array( 'label' => esc_html__( 'Scrollbar colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'default' => '#5b2029', 'selectors' => array( 'html' => 'scrollbar-color: {{VALUE}} transparent;' ) ) );
		$this->end_controls_section();
	}
}

class Kit_Transitions extends Tab_Base {

	public function get_id() {
		return 'sogand-transitions';
	}

	public function get_title() {
		return esc_html__( 'Sogand Page Transitions', 'sogand-core' );
	}

	public function get_group() {
		return 'settings';
	}

	public function get_icon() {
		return 'eicon-exchange';
	}

	public function get_help_url() {
		return '';
	}

	public static function presets() {
		return array(
			'slide-up'    => esc_html__( 'Slide up', 'sogand-core' ),
			'slide-down'  => esc_html__( 'Slide down', 'sogand-core' ),
			'slide-left'  => esc_html__( 'Slide left', 'sogand-core' ),
			'slide-right' => esc_html__( 'Slide right', 'sogand-core' ),
			'fade'        => esc_html__( 'Soft fade', 'sogand-core' ),
			'circle'      => esc_html__( 'Circle from the centre', 'sogand-core' ),
			'diamond'     => esc_html__( 'Diamond from the centre', 'sogand-core' ),
			'split-v'     => esc_html__( 'Double doors (vertical)', 'sogand-core' ),
			'split-h'     => esc_html__( 'Double doors (horizontal)', 'sogand-core' ),
			'blinds'      => esc_html__( 'Vertical blinds', 'sogand-core' ),
			'shutter'     => esc_html__( 'Horizontal shutter', 'sogand-core' ),
			'diagonal'    => esc_html__( 'Diagonal sweep', 'sogand-core' ),
			'zoom'        => esc_html__( 'Logo zoom', 'sogand-core' ),
			'iris'        => esc_html__( 'Iris', 'sogand-core' ),
			'stairs'      => esc_html__( 'Stairs', 'sogand-core' ),
			'rotate'      => esc_html__( 'Rotate', 'sogand-core' ),
			'blur'        => esc_html__( 'Frosted glass', 'sogand-core' ),
			'line'        => esc_html__( 'Golden line', 'sogand-core' ),
			'corner'      => esc_html__( 'From the corner', 'sogand-core' ),
			'ripple'      => esc_html__( 'Ripple from the click', 'sogand-core' ),
		);
	}

	protected function register_tab_controls() {
		$tab = $this->get_id();
		$this->start_controls_section( 'sgk_ct', array( 'label' => esc_html__( 'Curtain between pages', 'sogand-core' ), 'tab' => $tab ) );
		$this->add_control( 'sgk_ct_on', array( 'label' => esc_html__( 'Page transition curtain', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'default' => 'yes', 'return_value' => 'yes' ) );
		$on = array( 'sgk_ct_on' => 'yes' );
		$this->add_control( 'sgk_ct_preset', array( 'label' => esc_html__( 'Style', 'sogand-core' ), 'type' => Controls_Manager::SELECT, 'default' => 'split-v', 'options' => self::presets(), 'condition' => $on ) );
		$this->add_control( 'sgk_ct_c1', array( 'label' => esc_html__( 'Colour 1', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'default' => '#4b292c', 'condition' => $on ) );
		$this->add_control( 'sgk_ct_c2', array( 'label' => esc_html__( 'Colour 2', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'default' => '#3b2b2b', 'condition' => $on ) );
		$this->add_control( 'sgk_ct_dur', array( 'label' => esc_html__( 'Duration (ms)', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 200, 'max' => 1600, 'step' => 20 ) ), 'default' => array( 'size' => 420, 'unit' => 'px' ), 'condition' => $on ) );
		$this->add_control( 'sgk_ct_ease', array(
			'label'     => esc_html__( 'Easing', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'cubic-bezier(.7,0,.2,1)',
			'options'   => array(
				'cubic-bezier(.7,0,.2,1)'   => esc_html__( 'Luxury (slow in & out)', 'sogand-core' ),
				'cubic-bezier(.16,1,.3,1)'  => esc_html__( 'Soft landing', 'sogand-core' ),
				'cubic-bezier(.22,.61,.36,1)' => esc_html__( 'Natural', 'sogand-core' ),
				'linear'                    => esc_html__( 'Linear', 'sogand-core' ),
			),
			'condition' => $on,
		) );
		$this->add_control( 'sgk_ct_logo', array( 'label' => esc_html__( 'Show the logo', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'default' => 'yes', 'return_value' => 'yes', 'condition' => $on, 'separator' => 'before' ) );
		$this->add_control( 'sgk_ct_logo_img', array( 'label' => esc_html__( 'Logo image', 'sogand-core' ), 'type' => Controls_Manager::MEDIA, 'condition' => array( 'sgk_ct_on' => 'yes', 'sgk_ct_logo' => 'yes' ), 'description' => esc_html__( 'Empty = the Sogand mark.', 'sogand-core' ) ) );
		$this->add_control( 'sgk_ct_logo_size', array( 'label' => esc_html__( 'Logo size', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 40, 'max' => 480 ) ), 'default' => array( 'size' => 300, 'unit' => 'px' ), 'condition' => array( 'sgk_ct_on' => 'yes', 'sgk_ct_logo' => 'yes' ) ) );
		$this->add_control( 'sgk_ct_spin', array( 'label' => esc_html__( 'Rotate the logo', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'condition' => array( 'sgk_ct_on' => 'yes', 'sgk_ct_logo' => 'yes' ) ) );
		$this->add_control( 'sgk_ct_pulse', array( 'label' => esc_html__( 'Pulse the logo', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'condition' => array( 'sgk_ct_on' => 'yes', 'sgk_ct_logo' => 'yes' ) ) );
		$this->add_control( 'sgk_ct_name', array( 'label' => esc_html__( 'Show the name under the logo', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'condition' => $on ) );
		$this->add_control( 'sgk_ct_name_text', array( 'label' => esc_html__( 'Name', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'SOGAND ANDALIBAZAR', 'condition' => array( 'sgk_ct_on' => 'yes', 'sgk_ct_name' => 'yes' ) ) );
		$this->add_control( 'sgk_ct_pattern', array( 'label' => esc_html__( 'Decorative pattern', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'condition' => $on, 'separator' => 'before' ) );
		$this->add_control( 'sgk_ct_line', array( 'label' => esc_html__( 'Golden line', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'condition' => $on ) );
		$this->add_control( 'sgk_ct_line_c', array( 'label' => esc_html__( 'Line colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'default' => '#E3C88F', 'condition' => array( 'sgk_ct_on' => 'yes', 'sgk_ct_line' => 'yes' ) ) );
		$this->add_control( 'sgk_ct_progress', array( 'label' => esc_html__( 'Loading progress', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'condition' => $on ) );
		$this->add_control( 'sgk_ct_note', array(
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => esc_html__( 'Runs around normal page loads for internal links only. New tabs, downloads, phone, email, anchors and external links are never covered; a safety timer always lifts the curtain. If Elementor Pro Page Transitions are switched on for a page, this curtain steps aside there.', 'sogand-core' ),
			'content_classes' => 'elementor-descriptor',
			'condition'       => $on,
		) );
		$this->end_controls_section();
	}
}

class Kit_Layout extends Tab_Base {

	public function get_id() {
		return 'sogand-layout';
	}

	public function get_title() {
		return esc_html__( 'Sogand Templates', 'sogand-core' );
	}

	public function get_group() {
		return 'settings';
	}

	public function get_icon() {
		return 'eicon-header';
	}

	public function get_help_url() {
		return '';
	}

	public static function template_options( $types = array() ) {
		$args = array(
			'post_type'      => 'elementor_library',
			'post_status'    => 'publish',
			'posts_per_page' => 300,
			'orderby'        => 'title',
			'order'          => 'ASC',
			'fields'         => 'ids',
		);
		if ( $types ) {
			$args['tax_query'] = array( array( 'taxonomy' => 'elementor_library_type', 'field' => 'slug', 'terms' => $types ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		}
		$out = array( '' => esc_html__( '— None —', 'sogand-core' ) );
		foreach ( get_posts( $args ) as $id ) {
			$out[ (string) $id ] = get_the_title( $id );
		}
		return $out;
	}

	protected function register_tab_controls() {
		$tab   = $this->get_id();
		$types = array( 'section', 'container', 'page', 'header', 'footer', 'single', 'single-post', 'archive' );
		$this->start_controls_section( 'sgk_tpl', array( 'label' => esc_html__( 'Header, footer and work page', 'sogand-core' ), 'tab' => $tab ) );
		$this->add_control( 'sgk_tpl_note', array(
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => esc_html__( 'Choose which saved templates the theme shows around every page. With Elementor Pro, a Theme Builder header, footer or single template with display conditions takes priority and these choices are skipped where it applies. To edit a template, open Templates → Saved Templates.', 'sogand-core' ),
			'content_classes' => 'elementor-descriptor',
		) );
		$this->add_control( 'sg_tpl_header', array( 'label' => esc_html__( 'Header template', 'sogand-core' ), 'type' => Controls_Manager::SELECT, 'options' => self::template_options( $types ), 'default' => '' ) );
		$this->add_control( 'sg_tpl_footer', array( 'label' => esc_html__( 'Footer template', 'sogand-core' ), 'type' => Controls_Manager::SELECT, 'options' => self::template_options( $types ), 'default' => '' ) );
		$this->add_control( 'sg_tpl_work', array( 'label' => esc_html__( 'Work page template', 'sogand-core' ), 'type' => Controls_Manager::SELECT, 'options' => self::template_options( $types ), 'default' => '', 'description' => esc_html__( 'Layout of every portfolio entry. Its Sogand Work widgets show the entry being viewed.', 'sogand-core' ) ) );
		$this->add_control( 'sg_tpl_404', array( 'label' => esc_html__( 'Page-not-found template', 'sogand-core' ), 'type' => Controls_Manager::SELECT, 'options' => self::template_options( $types ), 'default' => '' ) );
		$this->add_control( 'sg_tpl_archive', array( 'label' => esc_html__( 'Collection archive template', 'sogand-core' ), 'type' => Controls_Manager::SELECT, 'options' => self::template_options( $types ), 'default' => '', 'description' => esc_html__( 'Used for /collection/… category pages; its Collections Grid shows that category.', 'sogand-core' ) ) );
		$this->end_controls_section();
	}
}

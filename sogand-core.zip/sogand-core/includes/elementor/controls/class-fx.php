<?php
/**
 * Shared Sogand capabilities injected into native Elementor elements:
 *
 *   Glass surface ............ containers + every widget
 *   Glow / halo .............. containers + every widget
 *   Loop motion & pointer .... containers + every widget (separate transform layer)
 *   Scroll-progress border ... containers + every widget
 *   Sticky inside parent ..... containers + every widget
 *   Header behaviour ......... containers
 *   Text reveal .............. Heading + Text Editor
 *   Image fade / mask / frame  Image widget
 *   Button shine / magnetic / sparkles  Button widget
 *
 * Each feature writes CSS custom properties on the element and a class that switches it
 * on. Unset values fall back to the Site Settings → Sogand defaults (kit variables) and
 * finally to theme fallbacks inside the stylesheet:
 *     element value  →  site default  →  theme fallback
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor;

use Elementor\Controls_Manager;
use Elementor\Element_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class FX {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		/* every widget (classic and optimized markup stacks) + containers */
		foreach ( array( 'common', 'common-optimized' ) as $stack ) {
			add_action( "elementor/element/{$stack}/_section_border/after_section_end", array( $this, 'glass' ), 10, 2 );
			add_action( "elementor/element/{$stack}/section_effects/after_section_end", array( $this, 'all_effects' ), 10, 2 );
		}
		add_action( 'elementor/element/container/section_border/after_section_end', array( $this, 'glass' ), 10, 2 );
		add_action( 'elementor/element/container/section_effects/after_section_end', array( $this, 'all_effects' ), 10, 2 );
		add_action( 'elementor/element/container/section_effects/after_section_end', array( $this, 'header_behaviour' ), 20, 2 );

		add_action( 'elementor/element/image/section_style_image/after_section_end', array( $this, 'image' ), 10, 2 );
		add_action( 'elementor/element/button/section_style/after_section_end', array( $this, 'button' ), 10, 2 );
		add_action( 'elementor/element/heading/section_title_style/after_section_end', array( $this, 'text_reveal' ), 10, 2 );
		add_action( 'elementor/element/text-editor/section_style/after_section_end', array( $this, 'text_reveal' ), 10, 2 );

	}

	/* ------------------------------------------------------------------
	 * helpers
	 * ---------------------------------------------------------------- */
	/** Section that each injection opens first (used to detect a second pass over the same stack). */
	private static $first = array(
		'glass'            => 'sg_glass_section',
		'all_effects'      => 'sg_glow_section',
		'header_behaviour' => 'sg_hdr_section',
		'text_reveal'      => 'sg_tr_section',
		'image'            => 'sg_img_section',
		'button'           => 'sg_btn_section',
	);

	/**
	 * True when this injection already added its controls to this stack. Elementor can
	 * rebuild a stack within one request (e.g. for CSS generation), so this checks the
	 * stack itself rather than remembering earlier calls.
	 */
	private static function has( Element_Base $el, $what ) {
		if ( empty( \Elementor\Plugin::$instance->controls_manager ) ) {
			return false;
		}
		$c = \Elementor\Plugin::$instance->controls_manager->get_control_from_stack( $el->get_unique_name(), self::$first[ $what ] );
		return ! is_wp_error( $c );
	}

	private static function tri( $label, $help = '' ) {
		return array(
			'label'       => $label,
			'type'        => Controls_Manager::SELECT,
			'default'     => '',
			'options'     => array(
				''    => esc_html__( 'Inherit (site default)', 'sogand-core' ),
				'on'  => esc_html__( 'Enable', 'sogand-core' ),
				'off' => esc_html__( 'Disable', 'sogand-core' ),
			),
			'description' => $help,
		);
	}

	private static function px_slider( $label, $max = 100, $selectors = array(), $unit = 'px', $min = 0, $step = 1 ) {
		return array(
			'label'      => $label,
			'type'       => Controls_Manager::SLIDER,
			'size_units' => array( $unit ),
			'range'      => array( $unit => array( 'min' => $min, 'max' => $max, 'step' => $step ) ),
			'selectors'  => $selectors,
		);
	}

	private static function num( $label, $min, $max, $step, $selectors, $default = '' ) {
		return array(
			'label'     => $label,
			'type'      => Controls_Manager::NUMBER,
			'min'       => $min,
			'max'       => $max,
			'step'      => $step,
			'default'   => $default,
			'selectors' => $selectors,
		);
	}

	/* ------------------------------------------------------------------
	 * Glass / frosted surface
	 * ---------------------------------------------------------------- */
	public function glass( Element_Base $el, $args ) {
		if ( self::has( $el, __FUNCTION__ ) ) {
			return; /* the same stack can pass through both widget-common hooks */
		}
		$tab = 'container' === $el->get_name() ? Controls_Manager::TAB_STYLE : Controls_Manager::TAB_ADVANCED;
		$el->start_controls_section( 'sg_glass_section', array(
			'label' => esc_html__( 'Sogand Glass', 'sogand-core' ),
			'tab'   => $tab,
		) );
		$el->add_control( 'sg_glass', array(
			'label'        => esc_html__( 'Frosted glass', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => '',
			'options'      => array(
				''     => esc_html__( 'Off', 'sogand-core' ),
				'on'   => esc_html__( 'On (site glass style)', 'sogand-core' ),
				'card' => esc_html__( 'On — card (lighter)', 'sogand-core' ),
				'deep' => esc_html__( 'On — deep panel', 'sogand-core' ),
			),
			'prefix_class' => 'sg-glass-',
			'description'  => esc_html__( 'Glass paints a tinted, blurred layer over the native Background and draws its edge as an inner line, so the Border controls stay free. Values left empty use Site Settings → Sogand Effects.', 'sogand-core' ),
		) );
		$on = array( 'sg_glass!' => '' );
		$el->add_control( 'sg_gl_tint', array(
			'label'     => esc_html__( 'Tint', 'sogand-core' ),
			'type'      => Controls_Manager::COLOR,
			'condition' => $on,
			'selectors' => array( '{{WRAPPER}}' => '--sg-gl-tint: {{VALUE}};' ),
		) );
		$el->add_control( 'sg_gl_tint2', array(
			'label'       => esc_html__( 'Tint 2 (gradient end)', 'sogand-core' ),
			'type'        => Controls_Manager::COLOR,
			'condition'   => $on,
			'selectors'   => array( '{{WRAPPER}}' => '--sg-gl-tint2: {{VALUE}};' ),
			'description' => esc_html__( 'Same as Tint for a solid colour.', 'sogand-core' ),
		) );
		$el->add_control( 'sg_gl_angle', array_merge( self::px_slider( esc_html__( 'Gradient angle', 'sogand-core' ), 360, array( '{{WRAPPER}}' => '--sg-gl-angle: {{SIZE}}deg;' ), 'deg' ), array( 'condition' => $on ) ) );
		$el->add_responsive_control( 'sg_gl_blur', array_merge( self::px_slider( esc_html__( 'Backdrop blur', 'sogand-core' ), 60, array( '{{WRAPPER}}' => '--sg-gl-blur: {{SIZE}}px;' ) ), array( 'condition' => $on ) ) );
		$el->add_control( 'sg_gl_sat', array_merge( self::px_slider( esc_html__( 'Saturation (%)', 'sogand-core' ), 250, array( '{{WRAPPER}}' => '--sg-gl-sat: {{SIZE}}%;' ), '%' ), array( 'condition' => $on ) ) );
		$el->add_control( 'sg_gl_bri', array_merge( self::px_slider( esc_html__( 'Brightness (%)', 'sogand-core' ), 200, array( '{{WRAPPER}}' => '--sg-gl-bri: {{SIZE}}%;' ), '%' ), array( 'condition' => $on ) ) );
		$el->add_control( 'sg_gl_edge', array(
			'label'     => esc_html__( 'Edge colour', 'sogand-core' ),
			'type'      => Controls_Manager::COLOR,
			'condition' => $on,
			'selectors' => array( '{{WRAPPER}}' => '--sg-gl-edge: {{VALUE}};' ),
		) );
		$el->add_control( 'sg_gl_edge_w', array_merge( self::px_slider( esc_html__( 'Edge width', 'sogand-core' ), 6, array( '{{WRAPPER}}' => '--sg-gl-edge-w: {{SIZE}}px;' ), 'px', 0, 0.5 ), array( 'condition' => $on ) ) );
		$el->add_responsive_control( 'sg_gl_radius', array(
			'label'       => esc_html__( 'Corner radius', 'sogand-core' ),
			'type'        => Controls_Manager::SLIDER,
			'size_units'  => array( 'px', '%', 'em' ),
			'range'       => array( 'px' => array( 'min' => 0, 'max' => 120 ) ),
			'condition'   => $on,
			'selectors'   => array( '{{WRAPPER}}' => '--sg-gl-r: {{SIZE}}{{UNIT}};' ),
			'description' => esc_html__( 'Leave empty to use the Border → Radius control or the site value.', 'sogand-core' ),
		) );
		$el->add_control( 'sg_gl_shadow', array(
			'label'     => esc_html__( 'Shadow strength', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0, 'max' => 1, 'step' => 0.05 ) ),
			'condition' => $on,
			'selectors' => array( '{{WRAPPER}}' => '--sg-gl-shadow: {{SIZE}};' ),
		) );
		$el->add_control( 'sg_gl_glow', array(
			'label'     => esc_html__( 'Edge glow colour', 'sogand-core' ),
			'type'      => Controls_Manager::COLOR,
			'condition' => $on,
			'selectors' => array( '{{WRAPPER}}' => '--sg-gl-glow: {{VALUE}};' ),
		) );
		$el->add_control( 'sg_gl_hl', array(
			'label'        => esc_html__( 'Top highlight line', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'default'      => 'yes',
			'return_value' => 'yes',
			'condition'    => $on,
			'selectors'    => array( '{{WRAPPER}}' => '--sg-gl-hl: 1;' ),
		) );
		$el->add_control( 'sg_gl_reflect', array(
			'label'        => esc_html__( 'Moving reflection', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'return_value' => 'yes',
			'prefix_class' => 'sg-glass-reflect-',
			'condition'    => $on,
		) );
		$el->add_control( 'sg_gl_hover_h', array(
			'label'     => esc_html__( 'Hover', 'sogand-core' ),
			'type'      => Controls_Manager::HEADING,
			'separator' => 'before',
			'condition' => $on,
		) );
		$el->add_control( 'sg_gl_tint_h', array(
			'label'     => esc_html__( 'Tint on hover', 'sogand-core' ),
			'type'      => Controls_Manager::COLOR,
			'condition' => $on,
			'selectors' => array( '{{WRAPPER}}' => '--sg-gl-tint-h: {{VALUE}};' ),
		) );
		$el->add_control( 'sg_gl_edge_h', array(
			'label'     => esc_html__( 'Edge colour on hover', 'sogand-core' ),
			'type'      => Controls_Manager::COLOR,
			'condition' => $on,
			'selectors' => array( '{{WRAPPER}}' => '--sg-gl-edge-h: {{VALUE}};' ),
		) );
		$el->add_control( 'sg_gl_lift', array_merge( self::px_slider( esc_html__( 'Lift on hover', 'sogand-core' ), 20, array( '{{WRAPPER}}' => '--sg-gl-lift: -{{SIZE}}px;' ) ), array( 'condition' => $on ) ) );
		$el->add_control( 'sg_gl_note', array(
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => esc_html__( 'Browsers without backdrop blur show a solid tint instead, so text stays readable.', 'sogand-core' ),
			'content_classes' => 'elementor-descriptor',
			'condition'       => $on,
		) );
		$el->end_controls_section();
	}

	/* ------------------------------------------------------------------
	 * Glow, loop motion, progress border, sticky (Advanced tab, every element)
	 * ---------------------------------------------------------------- */
	public function all_effects( Element_Base $el, $args ) {
		if ( self::has( $el, __FUNCTION__ ) ) {
			return; /* the same stack can pass through both widget-common hooks */
		}
		$this->glow( $el );
		$this->motion( $el );
		$this->progress( $el );
		$this->sticky( $el );
	}

	private function glow( Element_Base $el ) {
		$el->start_controls_section( 'sg_glow_section', array(
			'label' => esc_html__( 'Sogand Glow & Halo', 'sogand-core' ),
			'tab'   => Controls_Manager::TAB_ADVANCED,
		) );
		$el->add_control( 'sg_glow', array(
			'label'        => esc_html__( 'Glow', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => '',
			'options'      => array(
				''      => esc_html__( 'Off', 'sogand-core' ),
				'halo'  => esc_html__( 'Halo behind (soft light)', 'sogand-core' ),
				'ring'  => esc_html__( 'Ring light', 'sogand-core' ),
				'front' => esc_html__( 'Light in front (screen)', 'sogand-core' ),
			),
			'prefix_class' => 'sg-glow-',
			'description'  => esc_html__( 'A coloured light layer drawn behind (or over) this element without changing its own background.', 'sogand-core' ),
		) );
		$on = array( 'sg_glow!' => '' );
		$el->add_control( 'sg_glow_c1', array(
			'label'       => esc_html__( 'Colour', 'sogand-core' ),
			'type'        => Controls_Manager::COLOR,
			'condition'   => $on,
			'selectors'   => array( '{{WRAPPER}}' => '--sg-glow-c1: {{VALUE}};' ),
			'description' => esc_html__( 'Overrides the halo colour of a portfolio piece when set.', 'sogand-core' ),
		) );
		$el->add_control( 'sg_glow_c2', array(
			'label'     => esc_html__( 'Colour 2 (gradient)', 'sogand-core' ),
			'type'      => Controls_Manager::COLOR,
			'condition' => $on,
			'selectors' => array( '{{WRAPPER}}' => '--sg-glow-c2: {{VALUE}};' ),
		) );
		$el->add_control( 'sg_glow_op', array(
			'label'     => esc_html__( 'Opacity', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0, 'max' => 1, 'step' => 0.05 ) ),
			'condition' => $on,
			'selectors' => array( '{{WRAPPER}}' => '--sg-glow-op: {{SIZE}};' ),
		) );
		$el->add_control( 'sg_glow_int', array(
			'label'     => esc_html__( 'Intensity (colour strength %)', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 10, 'max' => 100 ) ),
			'condition' => $on,
			'selectors' => array( '{{WRAPPER}}' => '--sg-glow-int: {{SIZE}}%;' ),
		) );
		$el->add_responsive_control( 'sg_glow_w', array_merge( self::px_slider( esc_html__( 'Width (%)', 'sogand-core' ), 200, array( '{{WRAPPER}}' => '--sg-glow-w: {{SIZE}}%;' ), '%' ), array( 'condition' => $on ) ) );
		$el->add_responsive_control( 'sg_glow_h', array_merge( self::px_slider( esc_html__( 'Height (%)', 'sogand-core' ), 200, array( '{{WRAPPER}}' => '--sg-glow-h: {{SIZE}}%;' ), '%' ), array( 'condition' => $on ) ) );
		$el->add_responsive_control( 'sg_glow_blur', array_merge( self::px_slider( esc_html__( 'Blur', 'sogand-core' ), 150, array( '{{WRAPPER}}' => '--sg-glow-blur: {{SIZE}}px;' ) ), array( 'condition' => $on ) ) );
		$el->add_control( 'sg_glow_spread', array(
			'label'     => esc_html__( 'Spread (soft edge %)', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 30, 'max' => 100 ) ),
			'condition' => $on,
			'selectors' => array( '{{WRAPPER}}' => '--sg-glow-spread: {{SIZE}}%;' ),
		) );
		$el->add_control( 'sg_glow_shape', array(
			'label'     => esc_html__( 'Shape', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => '',
			'options'   => array(
				''        => esc_html__( 'Circle / ellipse', 'sogand-core' ),
				'rounded' => esc_html__( 'Rounded box', 'sogand-core' ),
				'square'  => esc_html__( 'Box', 'sogand-core' ),
			),
			'condition' => $on,
			'selectors_dictionary' => array( '' => '50%', 'rounded' => '28%', 'square' => '0' ),
			'selectors' => array( '{{WRAPPER}}' => '--sg-glow-r: {{VALUE}};' ),
		) );
		$el->add_responsive_control( 'sg_glow_x', array_merge( self::px_slider( esc_html__( 'Offset X (%)', 'sogand-core' ), 60, array( '{{WRAPPER}}' => '--sg-glow-x: {{SIZE}}%;' ), '%', -60 ), array( 'condition' => $on ) ) );
		$el->add_responsive_control( 'sg_glow_y', array_merge( self::px_slider( esc_html__( 'Offset Y (%)', 'sogand-core' ), 60, array( '{{WRAPPER}}' => '--sg-glow-y: {{SIZE}}%;' ), '%', -60 ), array( 'condition' => $on ) ) );
		$el->add_control( 'sg_glow_blend', array(
			'label'     => esc_html__( 'Blend mode', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => '',
			'options'   => array(
				''        => esc_html__( 'Normal', 'sogand-core' ),
				'screen'  => esc_html__( 'Screen', 'sogand-core' ),
				'lighten' => esc_html__( 'Lighten', 'sogand-core' ),
				'overlay' => esc_html__( 'Overlay', 'sogand-core' ),
				'plus-lighter' => esc_html__( 'Plus lighter', 'sogand-core' ),
			),
			'condition' => $on,
			'selectors' => array( '{{WRAPPER}}' => '--sg-glow-blend: {{VALUE}};' ),
		) );
		$el->add_control( 'sg_glow_anim', array(
			'label'        => esc_html__( 'Animation', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => 'breathe',
			'options'      => array(
				'none'    => esc_html__( 'Static', 'sogand-core' ),
				'breathe' => esc_html__( 'Breathe', 'sogand-core' ),
				'pulse'   => esc_html__( 'Pulse', 'sogand-core' ),
				'drift'   => esc_html__( 'Drift', 'sogand-core' ),
				'spin'    => esc_html__( 'Rotate (gradient)', 'sogand-core' ),
			),
			'prefix_class' => 'sg-glow-a-',
			'condition'    => $on,
		) );
		$el->add_control( 'sg_glow_speed', array(
			'label'     => esc_html__( 'Speed (seconds per cycle)', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 1, 'max' => 40, 'step' => 0.5 ) ),
			'condition' => $on,
			'selectors' => array( '{{WRAPPER}}' => '--sg-glow-dur: {{SIZE}}s;' ),
		) );
		$el->add_control( 'sg_glow_hover', array(
			'label'        => esc_html__( 'Brighter on hover', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'return_value' => 'yes',
			'prefix_class' => 'sg-glow-hv-',
			'condition'    => $on,
		) );
		$el->end_controls_section();
	}

	private function motion( Element_Base $el ) {
		$el->start_controls_section( 'sg_motion_section', array(
			'label' => esc_html__( 'Sogand Motion', 'sogand-core' ),
			'tab'   => Controls_Manager::TAB_ADVANCED,
		) );
		$el->add_control( 'sg_loop', array(
			'frontend_available' => true,
			'label'        => esc_html__( 'Loop motion', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => '',
			'options'      => array(
				''      => esc_html__( 'None', 'sogand-core' ),
				'float' => esc_html__( 'Float', 'sogand-core' ),
				'drift' => esc_html__( 'Drift', 'sogand-core' ),
				'sway'  => esc_html__( 'Sway', 'sogand-core' ),
				'pulse' => esc_html__( 'Pulse', 'sogand-core' ),
				'zoom'  => esc_html__( 'Slow zoom', 'sogand-core' ),
				'spin'  => esc_html__( 'Spin', 'sogand-core' ),
				'swing' => esc_html__( 'Pendulum swing', 'sogand-core' ),
			),
			'prefix_class' => 'sg-loop-',
			'description'  => esc_html__( 'Runs on its own layer (CSS translate / rotate / scale), so the Transform and Position controls keep working.', 'sogand-core' ),
		) );
		$loop = array( 'sg_loop!' => '' );
		$el->add_control( 'sg_loop_amp', array(
			'label'     => esc_html__( 'Amount', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0, 'max' => 3, 'step' => 0.05 ) ),
			'default'   => array( 'size' => 1 ),
			'condition' => $loop,
			'selectors' => array( '{{WRAPPER}}' => '--sg-loop-amp: {{SIZE}};' ),
		) );
		$el->add_control( 'sg_loop_dur', array(
			'label'     => esc_html__( 'Duration (s)', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 1, 'max' => 90, 'step' => 0.5 ) ),
			'condition' => $loop,
			'selectors' => array( '{{WRAPPER}}' => '--sg-loop-dur: {{SIZE}}s;' ),
		) );
		$el->add_control( 'sg_loop_delay', array(
			'label'     => esc_html__( 'Delay (s)', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => -20, 'max' => 20, 'step' => 0.1 ) ),
			'condition' => $loop,
			'selectors' => array( '{{WRAPPER}}' => '--sg-loop-delay: {{SIZE}}s;' ),
		) );
		$el->add_control( 'sg_loop_rev', array(
			'label'        => esc_html__( 'Reverse direction', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'return_value' => 'yes',
			'condition'    => $loop,
			'selectors'    => array( '{{WRAPPER}}' => '--sg-loop-dir: reverse;' ),
		) );
		$el->add_control( 'sg_ptr', array(
			'frontend_available' => true,
			'label'        => esc_html__( 'Pointer effect', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => '',
			'separator'    => 'before',
			'options'      => array(
				''         => esc_html__( 'None', 'sogand-core' ),
				'tilt'     => esc_html__( '3D tilt', 'sogand-core' ),
				'parallax' => esc_html__( 'Parallax shift', 'sogand-core' ),
				'magnet'   => esc_html__( 'Magnetic pull', 'sogand-core' ),
			),
			'prefix_class' => 'sg-ptr-',
			'description'  => esc_html__( 'Only on devices with a mouse; skipped when reduced motion is requested.', 'sogand-core' ),
		) );
		$ptr = array( 'sg_ptr!' => '' );
		$el->add_control( 'sg_ptr_k', array(
			'frontend_available' => true,
			'label'     => esc_html__( 'Strength', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => -60, 'max' => 60 ) ),
			'default'   => array( 'size' => 12 ),
			'condition' => $ptr,
		) );
		$el->add_control( 'sg_ptr_area', array(
			'frontend_available' => true,
			'label'     => esc_html__( 'Follow the pointer over', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'self',
			'options'   => array(
				'self'    => esc_html__( 'This element', 'sogand-core' ),
				'parent'  => esc_html__( 'Parent container', 'sogand-core' ),
				'section' => esc_html__( 'Whole section', 'sogand-core' ),
			),
			'condition' => $ptr,
		) );
		$el->add_control( 'sg_ptr_glare', array(
			'label'        => esc_html__( 'Glare', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'return_value' => 'yes',
			'prefix_class' => 'sg-glare-',
			'condition'    => array( 'sg_ptr' => 'tilt' ),
		) );
		$el->add_control( 'sg_scroll_par', array(
			'frontend_available' => true,
			'label'       => esc_html__( 'Scroll parallax', 'sogand-core' ),
			'type'        => Controls_Manager::SLIDER,
			'separator'   => 'before',
			'range'       => array( 'px' => array( 'min' => -1, 'max' => 1, 'step' => 0.05 ) ),
			'description' => esc_html__( 'Moves the element slower (positive) or faster (negative) than the page while scrolling. 0 = off.', 'sogand-core' ),
		) );
		$el->end_controls_section();
	}

	private function progress( Element_Base $el ) {
		$el->start_controls_section( 'sg_pb_section', array(
			'label' => esc_html__( 'Sogand Scroll-progress Border', 'sogand-core' ),
			'tab'   => Controls_Manager::TAB_ADVANCED,
		) );
		$el->add_control( 'sg_pb', array(
			'frontend_available' => true,
			'label'        => esc_html__( 'Progress border', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => '',
			'options'      => array(
				''   => esc_html__( 'Off', 'sogand-core' ),
				'on' => esc_html__( 'On', 'sogand-core' ),
			),
			'prefix_class' => 'sg-pb-',
			'description'  => esc_html__( 'A line that fills as the visitor scrolls (like the line under the header). Separate from entrance animations and image fades.', 'sogand-core' ),
		) );
		$on = array( 'sg_pb' => 'on' );
		$el->add_control( 'sg_pb_edges', array(
			'frontend_available' => true,
			'label'     => esc_html__( 'Edges', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT2,
			'multiple'  => true,
			'default'   => array( 'bottom' ),
			'options'   => array(
				'top'    => esc_html__( 'Top', 'sogand-core' ),
				'right'  => esc_html__( 'Right', 'sogand-core' ),
				'bottom' => esc_html__( 'Bottom', 'sogand-core' ),
				'left'   => esc_html__( 'Left', 'sogand-core' ),
			),
			'condition' => $on,
		) );
		$el->add_control( 'sg_pb_source', array(
			'frontend_available' => true,
			'label'     => esc_html__( 'Progress of', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'page',
			'options'   => array(
				'page'    => esc_html__( 'Whole page', 'sogand-core' ),
				'element' => esc_html__( 'This element passing the screen', 'sogand-core' ),
			),
			'condition' => $on,
		) );
		$el->add_control( 'sg_pb_dir', array(
			'frontend_available' => true,
			'label'     => esc_html__( 'Direction', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'start',
			'options'   => array(
				'start'  => esc_html__( 'From start (left / top)', 'sogand-core' ),
				'end'    => esc_html__( 'From end (right / bottom)', 'sogand-core' ),
				'center' => esc_html__( 'From the centre outwards', 'sogand-core' ),
			),
			'condition' => $on,
		) );
		$el->add_control( 'sg_pb_seq', array(
			'frontend_available' => true,
			'label'     => esc_html__( 'Several edges', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'together',
			'options'   => array(
				'together'   => esc_html__( 'Fill together', 'sogand-core' ),
				'sequential' => esc_html__( 'One after another (clockwise)', 'sogand-core' ),
			),
			'condition' => $on,
		) );
		$el->add_control( 'sg_pb_track', array(
			'label'     => esc_html__( 'Track colour', 'sogand-core' ),
			'type'      => Controls_Manager::COLOR,
			'condition' => $on,
			'selectors' => array( '{{WRAPPER}}' => '--sg-pb-track: {{VALUE}};' ),
		) );
		$el->add_control( 'sg_pb_color', array(
			'label'       => esc_html__( 'Fill colour', 'sogand-core' ),
			'type'        => Controls_Manager::COLOR,
			'condition'   => $on,
			'selectors'   => array( '{{WRAPPER}}' => '--sg-pb-fill: {{VALUE}};' ),
			'description' => esc_html__( 'Empty = the gold & silver metal gradient.', 'sogand-core' ),
		) );
		$el->add_control( 'sg_pb_color2', array(
			'label'     => esc_html__( 'Fill colour 2 (gradient)', 'sogand-core' ),
			'type'      => Controls_Manager::COLOR,
			'condition' => $on,
			'selectors' => array( '{{WRAPPER}}' => '--sg-pb-fill2: {{VALUE}};' ),
		) );
		$el->add_responsive_control( 'sg_pb_w', array_merge( self::px_slider( esc_html__( 'Thickness', 'sogand-core' ), 12, array( '{{WRAPPER}}' => '--sg-pb-w: {{SIZE}}px;' ), 'px', 0, 0.5 ), array( 'condition' => $on ) ) );
		$el->add_control( 'sg_pb_inset', array_merge( self::px_slider( esc_html__( 'Inset', 'sogand-core' ), 60, array( '{{WRAPPER}}' => '--sg-pb-inset: {{SIZE}}px;' ), 'px', -20 ), array( 'condition' => $on ) ) );
		$el->add_control( 'sg_pb_round', array(
			'label'        => esc_html__( 'Rounded ends', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'return_value' => 'yes',
			'condition'    => $on,
			'selectors'    => array( '{{WRAPPER}}' => '--sg-pb-cap: 99px;' ),
		) );
		$el->add_control( 'sg_pb_start', array(
			'frontend_available' => true,
			'label'       => esc_html__( 'Start offset (%)', 'sogand-core' ),
			'type'        => Controls_Manager::SLIDER,
			'range'       => array( 'px' => array( 'min' => 0, 'max' => 90 ) ),
			'condition'   => $on,
			'description' => esc_html__( 'Progress before this point is ignored.', 'sogand-core' ),
		) );
		$el->add_control( 'sg_pb_end', array(
			'frontend_available' => true,
			'label'     => esc_html__( 'End offset (%)', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 10, 'max' => 100 ) ),
			'condition' => $on,
		) );
		$el->add_control( 'sg_pb_smooth', array(
			'frontend_available' => true,
			'label'     => esc_html__( 'Smoothing', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0, 'max' => 0.95, 'step' => 0.05 ) ),
			'condition' => $on,
		) );
		$el->add_control( 'sg_pb_hide', array(
			'frontend_available' => true,
			'label'     => esc_html__( 'Hide on', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT2,
			'multiple'  => true,
			'options'   => array(
				'desktop' => esc_html__( 'Desktop', 'sogand-core' ),
				'tablet'  => esc_html__( 'Tablet', 'sogand-core' ),
				'mobile'  => esc_html__( 'Mobile', 'sogand-core' ),
			),
			'condition' => $on,
		) );
		$el->end_controls_section();
	}

	private function sticky( Element_Base $el ) {
		$el->start_controls_section( 'sg_sticky_section', array(
			'label' => esc_html__( 'Sogand Sticky in Section', 'sogand-core' ),
			'tab'   => Controls_Manager::TAB_ADVANCED,
		) );
		$el->add_control( 'sg_sticky', array(
			'frontend_available' => true,
			'label'        => esc_html__( 'Stay visible while scrolling its section', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'return_value' => 'yes',
			'prefix_class' => 'sg-sticky-',
			'description'  => esc_html__( 'The element stays in view while its parent container scrolls by, then stops at the parent’s end — e.g. the owner’s portrait beside a long biography.', 'sogand-core' ),
		) );
		$on = array( 'sg_sticky' => 'yes' );
		$el->add_control( 'sg_sticky_on', array(
			'frontend_available' => true,
			'label'     => esc_html__( 'Devices', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT2,
			'multiple'  => true,
			'default'   => array( 'desktop', 'tablet' ),
			'options'   => array(
				'desktop' => esc_html__( 'Desktop', 'sogand-core' ),
				'tablet'  => esc_html__( 'Tablet', 'sogand-core' ),
				'mobile'  => esc_html__( 'Mobile', 'sogand-core' ),
			),
			'condition' => $on,
			'description' => esc_html__( 'On small phones the element returns to the normal flow so it never covers the text.', 'sogand-core' ),
		) );
		$el->add_responsive_control( 'sg_sticky_top', array(
			'label'      => esc_html__( 'Top offset', 'sogand-core' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => array( 'px', 'vh' ),
			'range'      => array( 'px' => array( 'min' => 0, 'max' => 300 ) ),
			'condition'  => $on,
			'selectors'  => array( '{{WRAPPER}}' => '--sg-sticky-top: {{SIZE}}{{UNIT}};' ),
		) );
		$el->add_control( 'sg_sticky_hdr', array(
			'label'        => esc_html__( 'Add the header height', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'default'      => 'yes',
			'return_value' => 'yes',
			'condition'    => $on,
			'selectors'    => array( '{{WRAPPER}}' => '--sg-sticky-hdr: 1;' ),
			'description'  => esc_html__( 'The WordPress admin bar is always taken into account.', 'sogand-core' ),
		) );
		$el->add_control( 'sg_sticky_bottom', array_merge( self::px_slider( esc_html__( 'Bottom spacing', 'sogand-core' ), 200, array( '{{WRAPPER}}' => '--sg-sticky-bottom: {{SIZE}}px;' ) ), array( 'condition' => $on ) ) );
		$el->add_control( 'sg_sticky_z', array(
			'label'     => esc_html__( 'Layer order (z-index)', 'sogand-core' ),
			'type'      => Controls_Manager::NUMBER,
			'min'       => 0,
			'max'       => 99,
			'condition' => $on,
			'selectors' => array( '{{WRAPPER}}' => '--sg-sticky-z: {{VALUE}};' ),
		) );
		$el->end_controls_section();
	}

	/* ------------------------------------------------------------------
	 * Header behaviour (containers)
	 * ---------------------------------------------------------------- */
	public function header_behaviour( Element_Base $el, $args ) {
		if ( self::has( $el, __FUNCTION__ ) ) {
			return; /* the same stack can pass through both widget-common hooks */
		}
		$el->start_controls_section( 'sg_hdr_section', array(
			'label' => esc_html__( 'Sogand Header Behaviour', 'sogand-core' ),
			'tab'   => Controls_Manager::TAB_ADVANCED,
		) );
		$el->add_control( 'sg_hdr', array(
			'frontend_available' => true,
			'label'        => esc_html__( 'Behaviour', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => '',
			'options'      => array(
				''      => esc_html__( 'None', 'sogand-core' ),
				'fixed' => esc_html__( 'Fixed over the page', 'sogand-core' ),
				'smart' => esc_html__( 'Fixed, hides when scrolling down', 'sogand-core' ),
				'stick' => esc_html__( 'Sticky (keeps its space)', 'sogand-core' ),
			),
			'prefix_class' => 'sg-hdr-',
			'description'  => esc_html__( 'Use on the outer container of the header template. Glass (Style tab) can be set to appear only after scrolling below.', 'sogand-core' ),
		) );
		$on = array( 'sg_hdr!' => '' );
		$el->add_control( 'sg_hdr_glass_scroll', array(
			'label'        => esc_html__( 'Glass only after scrolling', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'return_value' => 'yes',
			'default'      => 'yes',
			'prefix_class' => 'sg-hdr-gs-',
			'condition'    => $on,
		) );
		$el->add_control( 'sg_hdr_offset', array(
			'frontend_available' => true,
			'label'     => esc_html__( 'Scrolled state after (px)', 'sogand-core' ),
			'type'      => Controls_Manager::NUMBER,
			'default'   => 30,
			'min'       => 0,
			'max'       => 600,
			'condition' => $on,
		) );
		$el->add_control( 'sg_hdr_top_bg', array(
			'label'     => esc_html__( 'Background at the top', 'sogand-core' ),
			'type'      => Controls_Manager::COLOR,
			'condition' => $on,
			'selectors' => array( '{{WRAPPER}}' => '--sg-hdr-top-bg: {{VALUE}};' ),
		) );
		$el->add_control( 'sg_hdr_scrolled_bg', array(
			'label'     => esc_html__( 'Background when scrolled', 'sogand-core' ),
			'type'      => Controls_Manager::COLOR,
			'condition' => $on,
			'selectors' => array( '{{WRAPPER}}' => '--sg-hdr-bg: {{VALUE}};' ),
		) );
		$el->add_control( 'sg_hdr_collapse', array(
			'label'        => esc_html__( 'Collapse this container when the header is scrolled', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'return_value' => 'yes',
			'separator'    => 'before',
			'prefix_class' => 'sg-collapse-',
			'description'  => esc_html__( 'For the top information bar inside the header.', 'sogand-core' ),
		) );
		$el->end_controls_section();
	}

	/* ------------------------------------------------------------------
	 * Text reveal (Heading, Text Editor)
	 * ---------------------------------------------------------------- */
	public function text_reveal( Element_Base $el, $args ) {
		if ( self::has( $el, __FUNCTION__ ) ) {
			return; /* the same stack can pass through both widget-common hooks */
		}
		$el->start_controls_section( 'sg_tr_section', array(
			'label' => esc_html__( 'Sogand Text Reveal', 'sogand-core' ),
			'tab'   => Controls_Manager::TAB_STYLE,
		) );
		$el->add_control( 'sg_tr', array(
			'frontend_available' => true,
			'label'        => esc_html__( 'Reveal', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => '',
			'options'      => array(
				''        => esc_html__( 'None', 'sogand-core' ),
				'words'   => esc_html__( 'Words rise', 'sogand-core' ),
				'letters' => esc_html__( 'Letters rise', 'sogand-core' ),
				'blur'    => esc_html__( 'Words from blur', 'sogand-core' ),
				'type'    => esc_html__( 'Typewriter', 'sogand-core' ),
				'shimmer' => esc_html__( 'Metal shimmer (continuous)', 'sogand-core' ),
			),
			'prefix_class' => 'sg-tr-',
			'render_type'  => 'template',
		) );
		$on = array( 'sg_tr!' => array( '', 'shimmer' ) );
		$el->add_control( 'sg_tr_trigger', array(
			'frontend_available' => true,
			'label'     => esc_html__( 'Start', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'view',
			'options'   => array(
				'load' => esc_html__( 'When the page loads', 'sogand-core' ),
				'view' => esc_html__( 'When scrolled into view', 'sogand-core' ),
			),
			'condition' => $on,
		) );
		$el->add_control( 'sg_tr_delay', array(
			'frontend_available' => true,
			'label'     => esc_html__( 'Delay (ms)', 'sogand-core' ),
			'type'      => Controls_Manager::NUMBER,
			'min'       => 0,
			'max'       => 5000,
			'step'      => 50,
			'default'   => 150,
			'condition' => $on,
		) );
		$el->add_control( 'sg_tr_stagger', array(
			'frontend_available' => true,
			'label'     => esc_html__( 'Stagger (ms)', 'sogand-core' ),
			'type'      => Controls_Manager::NUMBER,
			'min'       => 5,
			'max'       => 400,
			'step'      => 5,
			'default'   => 80,
			'condition' => $on,
		) );
		$el->add_control( 'sg_tr_accent', array(
			'label'       => esc_html__( 'Accent colour', 'sogand-core' ),
			'type'        => Controls_Manager::COLOR,
			'selectors'   => array( '{{WRAPPER}} .sg-accent, {{WRAPPER}} em' => 'color: {{VALUE}};' ),
			'description' => esc_html__( 'Colour of text wrapped in <span class="sg-accent"> or <em> — e.g. the second line of a hero title.', 'sogand-core' ),
		) );
		$el->end_controls_section();
	}

	/* ------------------------------------------------------------------
	 * Image fade, mask, frame (Image widget)
	 * ---------------------------------------------------------------- */
	public function image( Element_Base $el, $args ) {
		if ( self::has( $el, __FUNCTION__ ) ) {
			return; /* the same stack can pass through both widget-common hooks */
		}
		$el->start_controls_section( 'sg_img_section', array(
			'label' => esc_html__( 'Sogand Image Effects', 'sogand-core' ),
			'tab'   => Controls_Manager::TAB_STYLE,
		) );
		$el->add_control( 'sg_fade_h', array(
			'label' => esc_html__( 'Edge fades', 'sogand-core' ),
			'type'  => Controls_Manager::HEADING,
		) );
		$el->add_control( 'sg_fade_mode', array(
			'label'        => esc_html__( 'Fade type', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => 'mask',
			'options'      => array(
				'mask'  => esc_html__( 'Transparency (true fade to what is behind)', 'sogand-core' ),
				'color' => esc_html__( 'Colour overlay (fade into a colour)', 'sogand-core' ),
			),
			'prefix_class' => 'sg-fm-',
		) );
		foreach ( array( 't' => esc_html__( 'Top fade', 'sogand-core' ), 'r' => esc_html__( 'Right fade', 'sogand-core' ), 'b' => esc_html__( 'Bottom fade', 'sogand-core' ), 'l' => esc_html__( 'Left fade', 'sogand-core' ) ) as $k => $label ) {
			$el->add_responsive_control( 'sg_fade_' . $k, array(
				'label'      => $label,
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( '%' ),
				'range'      => array( '%' => array( 'min' => 0, 'max' => 100 ) ),
				'selectors'  => array( '{{WRAPPER}}' => '--sg-f' . $k . ': {{SIZE}}%;', '{{WRAPPER}}.sg-fm-mask img, {{WRAPPER}}.sg-fm-mask .sg-media' => '-webkit-mask-image: var(--sg-fmask); mask-image: var(--sg-fmask); -webkit-mask-composite: source-in; mask-composite: intersect;' ),
			) );
		}
		$el->add_control( 'sg_fade_soft', array(
			'label'       => esc_html__( 'Softness', 'sogand-core' ),
			'type'        => Controls_Manager::SLIDER,
			'range'       => array( 'px' => array( 'min' => 0, 'max' => 1, 'step' => 0.05 ) ),
			'selectors'   => array( '{{WRAPPER}}' => '--sg-fsoft: {{SIZE}};' ),
			'description' => esc_html__( 'How much of the picture stays visible at the middle of the fade (0 = steep, 1 = very gentle).', 'sogand-core' ),
		) );
		$el->add_control( 'sg_fade_color', array(
			'label'     => esc_html__( 'Fade colour', 'sogand-core' ),
			'type'      => Controls_Manager::COLOR,
			'condition' => array( 'sg_fade_mode' => 'color' ),
			'selectors' => array( '{{WRAPPER}}' => '--sg-fcol: {{VALUE}};' ),
		) );
		$el->add_control( 'sg_fade_radial', array(
			'label'      => esc_html__( 'Radial vignette', 'sogand-core' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => array( '%' ),
			'range'      => array( '%' => array( 'min' => 0, 'max' => 100 ) ),
			'selectors'  => array( '{{WRAPPER}}' => '--sg-frad: {{SIZE}}%;', '{{WRAPPER}}.sg-fm-mask img' => '-webkit-mask-image: var(--sg-fmask, linear-gradient(#000,#000)), radial-gradient(closest-side, #000 calc(100% - var(--sg-frad)), transparent); mask-image: var(--sg-fmask, linear-gradient(#000,#000)), radial-gradient(closest-side, #000 calc(100% - var(--sg-frad)), transparent); -webkit-mask-composite: source-in; mask-composite: intersect;' ),
			'description' => esc_html__( 'Fades the picture towards an oval edge. 0 = off.', 'sogand-core' ),
		) );
		$el->add_control( 'sg_fade_hover', array(
			'label'        => esc_html__( 'Remove fades on hover', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'return_value' => 'yes',
			'prefix_class' => 'sg-fh-',
		) );

		$el->add_control( 'sg_mask_h', array(
			'label'     => esc_html__( 'Shape & frame', 'sogand-core' ),
			'type'      => Controls_Manager::HEADING,
			'separator' => 'before',
		) );
		$el->add_control( 'sg_mask', array(
			'label'        => esc_html__( 'Shape', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => '',
			'options'      => array(
				''        => esc_html__( 'As uploaded', 'sogand-core' ),
				'circle'  => esc_html__( 'Circle', 'sogand-core' ),
				'arch'    => esc_html__( 'Arch', 'sogand-core' ),
				'pill'    => esc_html__( 'Pill', 'sogand-core' ),
				'diamond' => esc_html__( 'Diamond', 'sogand-core' ),
				'octagon' => esc_html__( 'Octagon', 'sogand-core' ),
				'hexagon' => esc_html__( 'Hexagon', 'sogand-core' ),
				'blob'    => esc_html__( 'Organic blob', 'sogand-core' ),
				'slant'   => esc_html__( 'Slanted edge', 'sogand-core' ),
			),
			'prefix_class' => 'sg-mask-',
		) );
		$el->add_control( 'sg_reveal', array(
			'label'        => esc_html__( 'Entrance reveal', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => '',
			'options'      => array(
				''        => esc_html__( 'None', 'sogand-core' ),
				'wipe'    => esc_html__( 'Wipe up', 'sogand-core' ),
				'side'    => esc_html__( 'Wipe from the side', 'sogand-core' ),
				'iris'    => esc_html__( 'Iris (circle)', 'sogand-core' ),
				'diamond' => esc_html__( 'Diamond', 'sogand-core' ),
				'blinds'  => esc_html__( 'Blinds', 'sogand-core' ),
				'curtain' => esc_html__( 'Curtains part', 'sogand-core' ),
				'blur'    => esc_html__( 'From blur', 'sogand-core' ),
			),
			'prefix_class' => 'sg-rv-',
		) );
		$el->add_control( 'sg_frame', array(
			'label'        => esc_html__( 'Frame', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => '',
			'options'      => array(
				''       => esc_html__( 'None', 'sogand-core' ),
				'line'   => esc_html__( 'Fine gold line', 'sogand-core' ),
				'double' => esc_html__( 'Double line', 'sogand-core' ),
				'gilt'   => esc_html__( 'Gilded frame', 'sogand-core' ),
				'corner' => esc_html__( 'Corner marks', 'sogand-core' ),
			),
			'prefix_class' => 'sg-frame-',
		) );
		$el->add_control( 'sg_frame_color', array(
			'label'     => esc_html__( 'Frame colour', 'sogand-core' ),
			'type'      => Controls_Manager::COLOR,
			'condition' => array( 'sg_frame!' => '' ),
			'selectors' => array( '{{WRAPPER}}' => '--sg-frame-c: {{VALUE}};' ),
		) );
		$el->add_control( 'sg_frame_gap', array_merge( self::px_slider( esc_html__( 'Frame distance', 'sogand-core' ), 40, array( '{{WRAPPER}}' => '--sg-frame-gap: {{SIZE}}px;' ), 'px', -10 ), array( 'condition' => array( 'sg_frame!' => '' ) ) ) );
		$el->add_control( 'sg_reflect', array(
			'label'        => esc_html__( 'Floor reflection', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'return_value' => 'yes',
			'prefix_class' => 'sg-reflect-',
		) );
		$el->add_control( 'sg_dshadow', array(
			'label'     => esc_html__( 'Piece shadow (follows the shape)', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0, 'max' => 1, 'step' => 0.05 ) ),
			'selectors' => array( '{{WRAPPER}}' => 'filter: drop-shadow(0 30px 40px rgba(0,0,0,{{SIZE}}));' ),
			'description' => esc_html__( 'A drop shadow that follows transparent PNG / WebP pieces.', 'sogand-core' ),
		) );

		$el->add_control( 'sg_tf_h', array(
			'label'     => esc_html__( 'Picture transform (inside its box)', 'sogand-core' ),
			'type'      => Controls_Manager::HEADING,
			'separator' => 'before',
		) );
		$el->add_responsive_control( 'sg_scale', array(
			'label'     => esc_html__( 'Scale', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0.2, 'max' => 3, 'step' => 0.01 ) ),
			'selectors' => array( '{{WRAPPER}}' => '--sg-is: {{SIZE}};' ),
		) );
		$el->add_responsive_control( 'sg_rot', array(
			'label'      => esc_html__( 'Rotate', 'sogand-core' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => array( 'deg' ),
			'range'      => array( 'deg' => array( 'min' => -180, 'max' => 180 ) ),
			'selectors'  => array( '{{WRAPPER}}' => '--sg-ir: {{SIZE}}deg;' ),
		) );
		$el->add_responsive_control( 'sg_ox', array(
			'label'      => esc_html__( 'Shift X', 'sogand-core' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => array( '%', 'px' ),
			'range'      => array( '%' => array( 'min' => -60, 'max' => 60 ), 'px' => array( 'min' => -400, 'max' => 400 ) ),
			'selectors'  => array( '{{WRAPPER}}' => '--sg-ix: {{SIZE}}{{UNIT}};' ),
		) );
		$el->add_responsive_control( 'sg_oy', array(
			'label'      => esc_html__( 'Shift Y', 'sogand-core' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => array( '%', 'px' ),
			'range'      => array( '%' => array( 'min' => -60, 'max' => 60 ), 'px' => array( 'min' => -400, 'max' => 400 ) ),
			'selectors'  => array( '{{WRAPPER}}' => '--sg-iy: {{SIZE}}{{UNIT}};' ),
		) );
		$el->add_control( 'sg_flip', array(
			'label'     => esc_html__( 'Flip', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => '',
			'options'   => array(
				''  => esc_html__( 'None', 'sogand-core' ),
				'h' => esc_html__( 'Horizontal', 'sogand-core' ),
				'v' => esc_html__( 'Vertical', 'sogand-core' ),
			),
			'selectors_dictionary' => array( '' => '--sg-ifx: 1; --sg-ify: 1;', 'h' => '--sg-ifx: -1; --sg-ify: 1;', 'v' => '--sg-ifx: 1; --sg-ify: -1;' ),
			'selectors' => array( '{{WRAPPER}}' => '{{VALUE}}' ),
		) );
		$el->add_control( 'sg_blend', array(
			'label'     => esc_html__( 'Blend mode', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => '',
			'options'   => array(
				''           => esc_html__( 'Normal', 'sogand-core' ),
				'screen'     => esc_html__( 'Screen', 'sogand-core' ),
				'multiply'   => esc_html__( 'Multiply', 'sogand-core' ),
				'lighten'    => esc_html__( 'Lighten', 'sogand-core' ),
				'luminosity' => esc_html__( 'Luminosity', 'sogand-core' ),
				'soft-light' => esc_html__( 'Soft light', 'sogand-core' ),
			),
			'selectors' => array( '{{WRAPPER}} img' => 'mix-blend-mode: {{VALUE}};' ),
		) );
		$el->end_controls_section();
	}

	/* ------------------------------------------------------------------
	 * Button shine, magnetic, sparkles (Button widget)
	 * ---------------------------------------------------------------- */
	public function button( Element_Base $el, $args ) {
		if ( self::has( $el, __FUNCTION__ ) ) {
			return; /* the same stack can pass through both widget-common hooks */
		}
		$el->start_controls_section( 'sg_btn_section', array(
			'label' => esc_html__( 'Sogand Shine & Motion', 'sogand-core' ),
			'tab'   => Controls_Manager::TAB_STYLE,
		) );
		$el->add_control( 'sg_shine', array_merge( array( 'frontend_available' => true ),  self::tri( esc_html__( 'Glass shine', 'sogand-core' ), esc_html__( 'The moving glass-like highlight. Inherit uses Site Settings → Sogand Effects.', 'sogand-core' ) ), array( 'prefix_class' => 'sg-shine-' ) ) );
		$s = array( 'sg_shine!' => 'off' );
		$el->add_control( 'sg_shine_trigger', array(
			'label'     => esc_html__( 'Play on', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => '',
			'options'   => array(
				''           => esc_html__( 'Inherit', 'sogand-core' ),
				'hover'      => esc_html__( 'Hover & keyboard focus', 'sogand-core' ),
				'continuous' => esc_html__( 'Continuously (with pause)', 'sogand-core' ),
				'click'      => esc_html__( 'Click only', 'sogand-core' ),
			),
			'prefix_class' => 'sg-st-',
			'condition'    => $s,
		) );
		$el->add_control( 'sg_shine_color', array(
			'label'     => esc_html__( 'Highlight colour', 'sogand-core' ),
			'type'      => Controls_Manager::COLOR,
			'condition' => $s,
			'selectors' => array( '{{WRAPPER}}' => '--sg-sh-c: {{VALUE}};' ),
		) );
		$el->add_control( 'sg_shine_color2', array(
			'label'     => esc_html__( 'Highlight colour 2 (metal edge)', 'sogand-core' ),
			'type'      => Controls_Manager::COLOR,
			'condition' => $s,
			'selectors' => array( '{{WRAPPER}}' => '--sg-sh-c2: {{VALUE}};' ),
		) );
		$el->add_control( 'sg_shine_op', array(
			'label'     => esc_html__( 'Opacity', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0, 'max' => 1, 'step' => 0.05 ) ),
			'condition' => $s,
			'selectors' => array( '{{WRAPPER}}' => '--sg-sh-op: {{SIZE}};' ),
		) );
		$el->add_control( 'sg_shine_angle', array_merge( self::px_slider( esc_html__( 'Angle', 'sogand-core' ), 180, array( '{{WRAPPER}}' => '--sg-sh-a: {{SIZE}}deg;' ), 'deg', 0 ), array( 'condition' => $s ) ) );
		$el->add_control( 'sg_shine_dir', array(
			'label'     => esc_html__( 'Travel', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => '',
			'options'   => array(
				''    => esc_html__( 'Left → right', 'sogand-core' ),
				'rtl' => esc_html__( 'Right → left', 'sogand-core' ),
			),
			'selectors_dictionary' => array( '' => '--sg-sh-x0: -120%; --sg-sh-x1: 120%;', 'rtl' => '--sg-sh-x0: 120%; --sg-sh-x1: -120%;' ),
			'selectors' => array( '{{WRAPPER}}' => '{{VALUE}}' ),
			'condition' => $s,
		) );
		$el->add_control( 'sg_shine_w', array(
			'label'     => esc_html__( 'Band width (%)', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 4, 'max' => 60 ) ),
			'condition' => $s,
			'selectors' => array( '{{WRAPPER}}' => '--sg-sh-w: {{SIZE}};' ),
		) );
		$el->add_control( 'sg_shine_soft', array(
			'label'     => esc_html__( 'Softness (blur px)', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0, 'max' => 20 ) ),
			'condition' => $s,
			'selectors' => array( '{{WRAPPER}}' => '--sg-sh-blur: {{SIZE}}px;' ),
		) );
		$el->add_control( 'sg_shine_glow', array(
			'label'     => esc_html__( 'Glow spread while shining', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0, 'max' => 60 ) ),
			'condition' => $s,
			'selectors' => array( '{{WRAPPER}}' => '--sg-sh-spread: {{SIZE}}px;' ),
		) );
		$el->add_control( 'sg_shine_dur', array(
			'label'     => esc_html__( 'Duration (ms)', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 200, 'max' => 4000, 'step' => 50 ) ),
			'condition' => $s,
			'selectors' => array( '{{WRAPPER}}' => '--sg-sh-dur: {{SIZE}}ms;' ),
		) );
		$el->add_control( 'sg_shine_delay', array(
			'label'     => esc_html__( 'Delay (ms)', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0, 'max' => 3000, 'step' => 50 ) ),
			'condition' => $s,
			'selectors' => array( '{{WRAPPER}}' => '--sg-sh-delay: {{SIZE}}ms;' ),
		) );
		$el->add_control( 'sg_shine_every', array(
			'label'     => esc_html__( 'Repeat every (s, continuous mode)', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 1, 'max' => 20, 'step' => 0.5 ) ),
			'condition' => $s,
			'selectors' => array( '{{WRAPPER}}' => '--sg-sh-every: {{SIZE}}s;' ),
		) );
		$el->add_control( 'sg_shine_blend', array(
			'label'     => esc_html__( 'Blend', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => '',
			'options'   => array(
				''           => esc_html__( 'Auto', 'sogand-core' ),
				'overlay'    => esc_html__( 'Overlay', 'sogand-core' ),
				'soft-light' => esc_html__( 'Soft light', 'sogand-core' ),
				'screen'     => esc_html__( 'Screen', 'sogand-core' ),
				'normal'     => esc_html__( 'Normal', 'sogand-core' ),
			),
			'condition' => $s,
			'selectors' => array( '{{WRAPPER}}' => '--sg-sh-blend: {{VALUE}};' ),
		) );
		$el->add_control( 'sg_shine_touch', array(
			'label'     => esc_html__( 'On touch screens', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => '',
			'options'   => array(
				''     => esc_html__( 'Shine when tapped', 'sogand-core' ),
				'none' => esc_html__( 'No shine', 'sogand-core' ),
			),
			'prefix_class' => 'sg-stouch-',
			'condition'    => $s,
		) );

		$el->add_control( 'sg_magnet', array_merge( array( 'frontend_available' => true ),  self::tri( esc_html__( 'Magnetic movement', 'sogand-core' ) ), array( 'separator' => 'before', 'prefix_class' => 'sg-mag-' ) ) );
		$el->add_control( 'sg_magnet_k', array(
			'frontend_available' => true,
			'label'     => esc_html__( 'Magnetic strength', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0.05, 'max' => 0.8, 'step' => 0.01 ) ),
			'condition' => array( 'sg_magnet!' => 'off' ),
		) );
		$el->add_control( 'sg_sparkle', array_merge( array( 'frontend_available' => true ),  self::tri( esc_html__( 'Click sparkles', 'sogand-core' ), esc_html__( 'Gold and silver sparkles burst from the click point.', 'sogand-core' ) ), array( 'prefix_class' => 'sg-spk-' ) ) );
		$el->end_controls_section();
	}
}

<?php
/**
 * Small bridge between the theme and Elementor:
 *  - renders the header / footer / work / 404 / archive templates chosen in
 *    Site Settings → Sogand Templates (Elementor Free has no Theme Builder);
 *  - steps aside where an Elementor Pro Theme Builder location applies;
 *  - prints the site extras (cursor light, progress bar, grain, preloader);
 *  - adds body classes for the button defaults.
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor;

use Elementor\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Bridge {

	private static $instance = null;
	private static $rendering = array();

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_filter( 'body_class', array( $this, 'body_class' ) );
		add_action( 'wp_body_open', array( $this, 'extras_open' ), 1 );
		add_action( 'wp_footer', array( $this, 'extras_footer' ), 5 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_location_css' ), 20 );
		add_filter( 'sogand_theme_location', array( $this, 'theme_location' ), 10, 2 );
	}

	/** Template id chosen for a slot (validated), or 0. */
	public static function template_for( $slot ) {
		$id = absint( Kit_Sogand::val( 'sg_tpl_' . $slot, 0 ) );
		if ( $id && 'elementor_library' === get_post_type( $id ) && 'publish' === get_post_status( $id ) ) {
			return $id;
		}
		return 0;
	}

	/** Does an Elementor Pro Theme Builder location already cover this slot on this request? */
	public static function pro_covers( $location ) {
		if ( ! function_exists( 'elementor_theme_do_location' ) || ! class_exists( '\ElementorPro\Modules\ThemeBuilder\Module' ) ) {
			return false;
		}
		$module = \ElementorPro\Modules\ThemeBuilder\Module::instance();
		$docs   = $module->get_conditions_manager()->get_documents_for_location( $location );
		return ! empty( $docs );
	}

	/** Render a saved template by id with a recursion guard. */
	public static function render_template( $id, $wrap_class = '' ) {
		$id = absint( $id );
		if ( ! $id || isset( self::$rendering[ $id ] ) ) {
			return '';
		}
		self::$rendering[ $id ] = true;
		$html = Plugin::$instance->frontend->get_builder_content_for_display( $id, true );
		unset( self::$rendering[ $id ] );
		if ( '' === trim( (string) $html ) ) {
			return '';
		}
		return $wrap_class ? '<div class="' . esc_attr( $wrap_class ) . '">' . $html . '</div>' : $html;
	}

	public static function is_rendering( $id ) {
		return isset( self::$rendering[ absint( $id ) ] );
	}

	/**
	 * Used by the theme: filter `sogand_theme_location` returns true when the slot was printed.
	 *
	 * @param bool   $done     Already handled.
	 * @param string $location header|footer|single|archive|404.
	 */
	public function theme_location( $done, $location ) {
		if ( $done ) {
			return true;
		}
		$pro_location = in_array( $location, array( '404', 'work' ), true ) ? 'single' : $location;
		if ( self::pro_covers( $pro_location ) ) {
			elementor_theme_do_location( $pro_location );
			return true;
		}
		$slot = $location;
		$id   = self::template_for( $slot );
		if ( ! $id ) {
			return false;
		}
		$tag = 'header' === $location ? 'header' : ( 'footer' === $location ? 'footer' : 'div' );
		$out = self::render_template( $id );
		if ( '' === $out ) {
			return false;
		}
		echo '<' . $tag . ' class="sg-location sg-location-' . esc_attr( $location ) . '"' . ( 'header' === $location ? ' id="sg-header"' : ( 'footer' === $location ? ' id="sg-footer"' : '' ) ) . '>' . $out . '</' . $tag . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Elementor output
		return true;
	}

	/** Load the CSS of the assigned header / footer templates in the <head> (avoids a flash). */
	public function enqueue_location_css() {
		if ( is_admin() ) {
			return;
		}
		foreach ( array( 'header', 'footer' ) as $slot ) {
			$id = self::template_for( $slot );
			if ( $id && ! self::pro_covers( $slot ) && class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
				$css = \Elementor\Core\Files\CSS\Post::create( $id );
				$css->enqueue();
			}
		}
	}

	public function body_class( $classes ) {
		if ( 'yes' === Kit_Sogand::get( 'sgk_shine', 'yes' ) ) {
			$classes[] = 'sgk-shine-on';
			$classes[] = 'sgk-st-' . sanitize_html_class( Kit_Sogand::val( 'sgk_shine_trigger', 'hover' ) );
		}
		if ( 'yes' === Kit_Sogand::get( 'sgk_magnet', 'yes' ) ) {
			$classes[] = 'sgk-mag-on';
		}
		if ( 'yes' === Kit_Sogand::get( 'sgk_sparkle', 'yes' ) ) {
			$classes[] = 'sgk-spk-on';
		}
		if ( 'always' === Kit_Sogand::val( 'sg_reduce_motion', 'system' ) ) {
			$classes[] = 'sg-calm';
		}
		$classes[] = 'sg-site';
		return $classes;
	}

	public function extras_open() {
		if ( 'yes' === Kit_Sogand::get( 'sgk_preloader' ) ) {
			$mark = sgc_asset( 'img/mark-gold.webp' );
			echo '<div class="sg-preloader" aria-hidden="true"><img src="' . esc_url( $mark ) . '" alt="" width="120" height="98"></div>';
			echo '<script>(function(){try{if(sessionStorage.getItem("sgPre")){document.documentElement.classList.add("sg-pre-seen")}else{sessionStorage.setItem("sgPre","1")}}catch(e){}setTimeout(function(){document.documentElement.classList.add("sg-pre-done")},3000);window.addEventListener("load",function(){document.documentElement.classList.add("sg-pre-done")})})();</script>';
		}
		if ( 'yes' === Kit_Sogand::get( 'sgk_progress' ) ) {
			echo '<div class="sg-readbar" aria-hidden="true"><i></i></div>';
		}
	}

	public function extras_footer() {
		if ( 'yes' === Kit_Sogand::get( 'sgk_cursor_light' ) ) {
			echo '<div class="sg-cursor-light" aria-hidden="true"></div>';
		}
		if ( 'yes' === Kit_Sogand::get( 'sgk_grain' ) ) {
			echo '<div class="sg-grain" aria-hidden="true"></div>';
		}
		$cfg = array(
			'spark'  => 'yes' === Kit_Sogand::get( 'sgk_sparkle', 'yes' ) ? array(
				'n'  => (int) Kit_Sogand::val( 'sgk_sparkle_n', 80 ),
				'c1' => sgc_sanitize_color( Kit_Sogand::val( 'sgk_sparkle_c1', '#e9cd8c' ), '#e9cd8c' ),
				'c2' => sgc_sanitize_color( Kit_Sogand::val( 'sgk_sparkle_c2', '#e6eaf0' ), '#e6eaf0' ),
			) : null,
			'magk'   => (float) Kit_Sogand::size( 'sgk_magnet_k', 0.25 ),
		);
		echo '<script>window.sgcSite=' . wp_json_encode( $cfg ) . ';</script>';
	}
}

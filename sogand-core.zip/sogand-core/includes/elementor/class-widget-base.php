<?php
/**
 * Base class for Sogand widgets.
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor;

use Elementor\Widget_Base as Elementor_Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class Widget_Base extends Elementor_Widget_Base {

	public function get_categories() {
		return array( 'sogand' );
	}

	public function get_keywords() {
		return array( 'sogand' );
	}

	public function get_style_depends(): array {
		return array( 'sgc-base' );
	}

	public function get_script_depends(): array {
		return array( 'sgc-core' );
	}

	public function get_custom_help_url() {
		return '';
	}

	/** Optimized markup: no extra inner wrapper (where supported). */
	public function has_widget_inner_wrapper(): bool {
		return false;
	}

	/** Sogand widgets read the current page, menu or portfolio: never serve them from Elementor's element cache. */
	protected function is_dynamic_content(): bool {
		return true;
	}

	/** True inside the Elementor editor preview. */
	protected function in_editor() {
		return \Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode();
	}

	/** Image URL + alt from a MEDIA control value (falls back to a bundled asset). */
	protected function media( $value, $fallback_rel = '' ) {
		$id  = isset( $value['id'] ) ? absint( $value['id'] ) : 0;
		$url = isset( $value['url'] ) ? (string) $value['url'] : '';
		if ( $id ) {
			$src = wp_get_attachment_image_url( $id, 'full' );
			if ( $src ) {
				$url = $src;
			}
		}
		if ( '' === $url && $fallback_rel ) {
			$url = sgc_asset( $fallback_rel );
		}
		$alt = isset( $value['alt'] ) ? (string) $value['alt'] : '';
		if ( '' === $alt && $id ) {
			$alt = (string) get_post_meta( $id, '_wp_attachment_image_alt', true );
		}
		return array( 'id' => $id, 'url' => $url, 'alt' => $alt );
	}

	/** Link attributes from a URL control value. */
	protected function link_attrs( $link ) {
		if ( empty( $link['url'] ) ) {
			return '';
		}
		$a = ' href="' . esc_url( $link['url'] ) . '"';
		if ( ! empty( $link['is_external'] ) ) {
			$a .= ' target="_blank"';
		}
		$rel = array();
		if ( ! empty( $link['is_external'] ) ) {
			$rel[] = 'noopener';
		}
		if ( ! empty( $link['nofollow'] ) ) {
			$rel[] = 'nofollow';
		}
		if ( $rel ) {
			$a .= ' rel="' . esc_attr( implode( ' ', $rel ) ) . '"';
		}
		return $a;
	}

	/** Small inline icon set used across widgets. */
	public static function icon( $name, $size = 16 ) {
		$p = array(
			'arrow-right' => '<path d="M5 12h14M13 6l6 6-6 6"/>',
			'arrow-left'  => '<path d="M19 12H5M11 6l-6 6 6 6"/>',
			'arrow-up'    => '<path d="M12 19V5M6 11l6-6 6 6"/>',
			'chevron'     => '<path d="M6 9l6 6 6-6"/>',
			'plus'        => '<path d="M12 5v14M5 12h14"/>',
			'phone'       => '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/>',
			'mail'        => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
			'instagram'   => '<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/>',
			'whatsapp'    => '<path d="M20 12a8 8 0 0 1-11.8 7L4 20l1.1-4A8 8 0 1 1 20 12z"/><path d="M9 9.5c.5 2 2 3.5 4 4l1-1 2 1c-.3 1-1.2 1.5-2 1.5-3 0-6-3-6-6 0-.8.5-1.7 1.5-2l1 2z"/>',
			'zoom'        => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5M11 8v6M8 11h6"/>',
			'search'      => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
			'close'       => '<path d="M6 6l12 12M18 6 6 18"/>',
			'sketch'      => '<path d="M4 20l4-1 11-11-3-3L5 16z"/><path d="M14 6l3 3"/>',
			'gem'         => '<path d="M6 3h12l3 6-9 12L3 9z"/><path d="M3 9h18M9 3l3 18 3-18"/>',
			'brush'       => '<path d="M19 3l2 2-9 9-2-2z"/><path d="M10 12c-3 0-5 2-5 5 0 1-1 2-2 2 2 2 7 2 9-1 1-2 0-4-2-6z"/>',
			'cube'        => '<path d="M12 2 3 7v10l9 5 9-5V7z"/><path d="m3 7 9 5 9-5M12 12v10"/>',
			'pen'         => '<path d="M3 21l3-1 12-12-2-2L4 18z"/><path d="M14 6l4 4M17 3l4 4"/>',
			'sparkle'     => '<path d="M12 3l1.8 5.4L19 10l-5.2 1.6L12 17l-1.8-5.4L5 10l5.2-1.6z"/>',
		);
		if ( ! isset( $p[ $name ] ) ) {
			return '';
		}
		return '<svg class="sg-ic" width="' . (int) $size . '" height="' . (int) $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $p[ $name ] . '</svg>';
	}
}

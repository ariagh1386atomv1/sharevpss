<?php
/**
 * Sogand Collections Grid — the live portfolio: collection filters, 1024 × 1024 cards
 * with halo and glass name box (or any saved template as the card), ordering,
 * "load more" and an empty state.
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Sogand\Core\Elementor\Widget_Base;
use Sogand\Core\Elementor\Bridge;
use Sogand\Core\Elementor\Kit_Layout;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/collection-slider.php';

class Collection_Grid extends Widget_Base {

	public function get_name() {
		return 'sogand-collection-grid';
	}

	public function get_title() {
		return esc_html__( 'Collections Grid', 'sogand-core' );
	}

	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	public function get_keywords() {
		return array( 'sogand', 'grid', 'portfolio', 'collection', 'works', 'filter', 'archive', 'loop' );
	}

	public function get_style_depends(): array {
		return array( 'sgc-base', 'sgc-collection' );
	}

	public function get_script_depends(): array {
		return array( 'sgc-core', 'sgc-collection' );
	}

	protected function register_controls() {
		$this->start_controls_section( 'query', array( 'label' => esc_html__( 'Works', 'sogand-core' ) ) );
		$this->add_control( 'source', array(
			'label'   => esc_html__( 'Show', 'sogand-core' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'all',
			'options' => array(
				'all'     => esc_html__( 'All works', 'sogand-core' ),
				'cat'     => esc_html__( 'One collection', 'sogand-core' ),
				'current' => esc_html__( 'The collection being viewed (archive pages)', 'sogand-core' ),
			),
		) );
		$this->add_control( 'cat', array( 'label' => esc_html__( 'Collection', 'sogand-core' ), 'type' => Controls_Manager::SELECT, 'options' => Collection_Slider::cat_options(), 'condition' => array( 'source' => 'cat' ) ) );
		$this->add_control( 'orderby', array(
			'label'   => esc_html__( 'Order', 'sogand-core' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'menu',
			'options' => array(
				'menu'  => esc_html__( 'Manual order (Works → Order), then newest', 'sogand-core' ),
				'date'  => esc_html__( 'Newest first', 'sogand-core' ),
				'title' => esc_html__( 'Title A–Z', 'sogand-core' ),
				'rand'  => esc_html__( 'Random', 'sogand-core' ),
			),
		) );
		$this->add_control( 'per_page', array( 'label' => esc_html__( 'Works shown at first', 'sogand-core' ), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 120, 'default' => 24 ) );
		$this->add_control( 'more', array( 'label' => esc_html__( '“Show more” button for the rest', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes' ) );
		$this->add_control( 'more_text', array( 'label' => esc_html__( 'Button text', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Show more', 'condition' => array( 'more' => 'yes' ) ) );
		$this->add_control( 'empty', array( 'label' => esc_html__( 'Text when there are no works', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'New pieces are on their way.', 'label_block' => true ) );
		$this->end_controls_section();

		$this->start_controls_section( 'filters', array( 'label' => esc_html__( 'Filters', 'sogand-core' ) ) );
		$this->add_control( 'tabs', array( 'label' => esc_html__( 'Collection filters', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'description' => esc_html__( 'Every collection under Works → Collections becomes a filter (also new, still empty ones), in their Display order.', 'sogand-core' ) ) );
		$this->add_control( 'all_text', array( 'label' => esc_html__( 'First filter', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'All works', 'condition' => array( 'tabs' => 'yes' ) ) );
		$this->add_control( 'hide_empty', array( 'label' => esc_html__( 'Hide collections without works', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'condition' => array( 'tabs' => 'yes' ) ) );
		$this->add_control( 'url_param', array( 'label' => esc_html__( 'Remember the filter in the address (?cat=…)', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'condition' => array( 'tabs' => 'yes' ) ) );
		$this->add_responsive_control( 'tabs_align', array(
			'label'     => esc_html__( 'Alignment', 'sogand-core' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => array(
				'flex-start' => array( 'title' => esc_html__( 'Start', 'sogand-core' ), 'icon' => 'eicon-text-align-left' ),
				'center'     => array( 'title' => esc_html__( 'Center', 'sogand-core' ), 'icon' => 'eicon-text-align-center' ),
				'flex-end'   => array( 'title' => esc_html__( 'End', 'sogand-core' ), 'icon' => 'eicon-text-align-right' ),
			),
			'default'   => 'center',
			'condition' => array( 'tabs' => 'yes' ),
			'selectors' => array( '{{WRAPPER}} .sg-cg-tabs-wrap' => 'justify-content: {{VALUE}};' ),
		) );
		$this->end_controls_section();

		$this->start_controls_section( 'card', array( 'label' => esc_html__( 'Card', 'sogand-core' ) ) );
		$this->add_control( 'card_mode', array(
			'label'   => esc_html__( 'Card design', 'sogand-core' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'builtin',
			'options' => array(
				'builtin'  => esc_html__( 'Sogand card (picture + halo + glass name box)', 'sogand-core' ),
				'template' => esc_html__( 'A saved Elementor template', 'sogand-core' ),
			),
			'description' => esc_html__( 'With a template, design the card freely in Elementor using the Sogand Work widgets (title, picture, details, link); they show each work in turn.', 'sogand-core' ),
		) );
		$this->add_control( 'card_tpl', array( 'label' => esc_html__( 'Card template', 'sogand-core' ), 'type' => Controls_Manager::SELECT, 'options' => Kit_Layout::template_options( array( 'section', 'container', 'loop-item', 'page' ) ), 'condition' => array( 'card_mode' => 'template' ) ) );
		$this->add_control( 'btn', array( 'label' => esc_html__( 'Button text', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'discover', 'condition' => array( 'card_mode' => 'builtin' ) ) );
		$this->add_control( 'show_cat', array( 'label' => esc_html__( 'Show the collection name', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'condition' => array( 'card_mode' => 'builtin' ) ) );
		$this->add_control( 'halo', array( 'label' => esc_html__( 'Coloured halo behind each piece', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'condition' => array( 'card_mode' => 'builtin' ) ) );
		$this->add_control( 'img_size', array(
			'label'     => esc_html__( 'Picture size', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'sogand-square',
			'options'   => array( 'sogand-square' => '1024 × 1024', 'large' => esc_html__( 'Large', 'sogand-core' ), 'medium_large' => esc_html__( 'Medium', 'sogand-core' ), 'full' => esc_html__( 'Original', 'sogand-core' ) ),
			'condition' => array( 'card_mode' => 'builtin' ),
		) );
		$this->add_control( 'reveal', array( 'label' => esc_html__( 'Cards rise in while scrolling', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'prefix_class' => 'sg-cg-rv-' ) );
		$this->end_controls_section();

		/* ---------------- style ---------------- */
		$this->start_controls_section( 's_grid', array( 'label' => esc_html__( 'Grid', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_responsive_control( 'cols', array( 'label' => esc_html__( 'Columns', 'sogand-core' ), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 6, 'default' => 3, 'tablet_default' => 2, 'mobile_default' => 1, 'selectors' => array( '{{WRAPPER}} .sg-cg-grid' => 'grid-template-columns: repeat({{VALUE}}, minmax(0, 1fr));' ) ) );
		$this->add_responsive_control( 'gap', array( 'label' => esc_html__( 'Gap', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 80 ) ), 'selectors' => array( '{{WRAPPER}} .sg-cg-grid' => 'gap: {{SIZE}}px;' ) ) );
		$this->add_responsive_control( 'tabs_space', array( 'label' => esc_html__( 'Space under the filters', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 120 ) ), 'selectors' => array( '{{WRAPPER}} .sg-cg-tabs-wrap' => 'margin-bottom: {{SIZE}}px;' ) ) );
		$this->end_controls_section();

		$this->start_controls_section( 's_card', array( 'label' => esc_html__( 'Card', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE, 'condition' => array( 'card_mode' => 'builtin' ) ) );
		$this->add_responsive_control( 'ratio', array( 'label' => esc_html__( 'Picture box ratio', 'sogand-core' ), 'type' => Controls_Manager::SELECT, 'default' => '1/1', 'options' => array( '1/1' => '1 : 1', '4/5' => '4 : 5', '3/4' => '3 : 4', '4/3' => '4 : 3' ), 'selectors' => array( '{{WRAPPER}} .sg-card-media' => 'aspect-ratio: {{VALUE}};' ) ) );
		$this->add_control( 'radius', array( 'label' => esc_html__( 'Picture box radius', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 60 ) ), 'selectors' => array( '{{WRAPPER}}' => '--sg-card-r: {{SIZE}}px;' ) ) );
		$this->add_control( 'media_bg', array( 'label' => esc_html__( 'Picture box colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-card-media: {{VALUE}};' ) ) );
		$this->add_control( 'border', array( 'label' => esc_html__( 'Edge colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-card-border: {{VALUE}};' ) ) );
		$this->add_control( 'img_scale', array( 'label' => esc_html__( 'Piece size in its box (%)', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 40, 'max' => 100 ) ), 'selectors' => array( '{{WRAPPER}}' => '--sg-card-img: {{SIZE}}%;' ) ) );
		$this->add_control( 'halo_op', array( 'label' => esc_html__( 'Halo strength', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 1, 'step' => 0.05 ) ), 'selectors' => array( '{{WRAPPER}}' => '--sg-card-halo: {{SIZE}};' ) ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'name_t', 'label' => esc_html__( 'Name', 'sogand-core' ), 'selector' => '{{WRAPPER}} .sg-card-name' ) );
		$this->add_control( 'btn_bg', array( 'label' => esc_html__( 'Button colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-card-btn: {{VALUE}};' ) ) );
		$this->add_control( 'btn_c', array( 'label' => esc_html__( 'Button text colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-card-btn-c: {{VALUE}};' ) ) );
		$this->add_control( 'lift', array( 'label' => esc_html__( 'Hover lift (px)', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 20 ) ), 'selectors' => array( '{{WRAPPER}}' => '--sg-card-lift: -{{SIZE}}px;' ) ) );
		$this->end_controls_section();

		$this->start_controls_section( 's_tabs', array( 'label' => esc_html__( 'Filters', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE, 'condition' => array( 'tabs' => 'yes' ) ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'tab_t', 'selector' => '{{WRAPPER}} .sg-tab' ) );
		$this->add_control( 'tab_c', array( 'label' => esc_html__( 'Text', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-tab' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'tab_ca', array( 'label' => esc_html__( 'Active text', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-tab.is-active' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'pill', array( 'label' => esc_html__( 'Active pill', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-tab-pill' => 'background: {{VALUE}};' ) ) );
		$this->add_control( 'tabs_bg', array( 'label' => esc_html__( 'Background', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-tabs' => 'background: {{VALUE}};' ) ) );
		$this->end_controls_section();
	}

	private function query_args( $s ) {
		$args = array( 'posts_per_page' => 120 );
		switch ( $s['orderby'] ) {
			case 'date':
				$args['orderby'] = array( 'date' => 'DESC' );
				break;
			case 'title':
				$args['orderby'] = array( 'title' => 'ASC' );
				break;
			case 'rand':
				$args['orderby'] = 'rand';
				break;
		}
		$term = 0;
		if ( 'cat' === $s['source'] && $s['cat'] ) {
			$term = absint( $s['cat'] );
		} elseif ( 'current' === $s['source'] && is_tax( 'sg_collection' ) ) {
			$term = get_queried_object_id();
		}
		if ( $term ) {
			$args['tax_query'] = array( array( 'taxonomy' => 'sg_collection', 'field' => 'term_id', 'terms' => $term ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		}
		return array( sgc_works_query_args( $args ), $term );
	}

	public function card( $p, $i, $s ) {
		$terms = get_the_terms( $p, 'sg_collection' );
		$slugs = ( $terms && ! is_wp_error( $terms ) ) ? wp_list_pluck( $terms, 'slug' ) : array();
		$tone  = sgc_work_tone( $p->ID, $i );
		$title = get_the_title( $p );
		$out   = '<a class="sg-card" href="' . esc_url( get_permalink( $p ) ) . '" style="--tone:' . esc_attr( $tone ) . '">';
		$out  .= '<span class="sg-card-media">';
		if ( 'yes' === $s['halo'] ) {
			$out .= '<span class="sg-card-halo" aria-hidden="true"></span>';
		}
		$out .= get_the_post_thumbnail( $p, $s['img_size'] ? $s['img_size'] : 'sogand-square', array( 'alt' => $title, 'loading' => $i > 2 ? 'lazy' : 'eager', 'decoding' => 'async', 'sizes' => '(max-width: 560px) 92vw, (max-width: 980px) 46vw, 420px' ) );
		$out .= '</span><span class="sg-card-glass"><span class="sg-card-text">';
		if ( 'yes' === $s['show_cat'] && $terms && ! is_wp_error( $terms ) ) {
			$out .= '<span class="sg-card-cat">' . esc_html( $terms[0]->name ) . '</span>';
		}
		$out .= '<span class="sg-card-name">' . esc_html( $title ) . '</span></span>';
		$out .= '<span class="sg-card-btn">' . esc_html( '' !== (string) $s['btn'] ? $s['btn'] : 'discover' ) . ' ' . self::icon( 'arrow-right', 14 ) . '</span></span></a>';
		return array( $out, $slugs );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		list( $args, $term ) = $this->query_args( $s );
		$q    = new \WP_Query( $args );
		$per  = max( 1, (int) $s['per_page'] );
		$tabs = 'yes' === $s['tabs'] && ! $term;
		echo '<div class="sg-cg" data-per="' . (int) $per . '" data-url="' . ( 'yes' === $s['url_param'] ? '1' : '0' ) . '">';
		if ( $tabs ) {
			$cats = sgc_collection_terms( 'yes' === $s['hide_empty'] );
			if ( $cats ) {
				echo '<div class="sg-cg-tabs-wrap"><div class="sg-tabs" role="tablist" aria-label="' . esc_attr__( 'Filter by collection', 'sogand-site' ) . '"><i class="sg-tab-pill" aria-hidden="true"></i>';
				echo '<button type="button" role="tab" class="sg-tab is-active" aria-selected="true" data-cat="all">' . esc_html( $s['all_text'] ? $s['all_text'] : __( 'All works', 'sogand-site' ) ) . '</button>';
				foreach ( $cats as $c ) {
					echo '<button type="button" role="tab" class="sg-tab" aria-selected="false" data-cat="' . esc_attr( $c->slug ) . '">' . esc_html( $c->name ) . '</button>';
				}
				echo '</div></div>';
			}
		}
		echo '<div class="sg-cg-grid">';
		$i   = 0;
		$tpl = 'template' === $s['card_mode'] ? absint( $s['card_tpl'] ) : 0;
		if ( $q->have_posts() ) {
			global $post;
			while ( $q->have_posts() ) {
				$q->the_post();
				$p = get_post();
				if ( $tpl && ! Bridge::is_rendering( $tpl ) ) {
					$terms = get_the_terms( $p, 'sg_collection' );
					$slugs = ( $terms && ! is_wp_error( $terms ) ) ? wp_list_pluck( $terms, 'slug' ) : array();
					$html  = '<div class="sg-card-tpl" style="--tone:' . esc_attr( sgc_work_tone( $p->ID, $i ) ) . '">' . Bridge::render_template( $tpl ) . '</div>';
				} else {
					list( $html, $slugs ) = $this->card( $p, $i, $s );
				}
				echo '<div class="sg-cg-cell' . ( $i >= $per ? ' is-more' : '' ) . '" data-cats="' . esc_attr( implode( ' ', $slugs ) ) . '"' . ( $i >= $per ? ' hidden' : '' ) . '>' . $html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				$i++;
			}
			wp_reset_postdata();
		}
		echo '</div>';
		echo '<p class="sg-cg-empty"' . ( $i ? ' hidden' : '' ) . '>' . esc_html( $s['empty'] ) . '</p>';
		if ( 'yes' === $s['more'] && $i > $per ) {
			echo '<div class="sg-cg-more-wrap"><button type="button" class="sg-btn sg-btn-glass sg-cg-more">' . esc_html( $s['more_text'] ? $s['more_text'] : __( 'Show more', 'sogand-site' ) ) . '</button></div>';
		}
		echo '</div>';
	}
}

<?php
/**
 * Sogand Saved Template — shows a saved template (section, container or page) by
 * reference, so one shared block (the Collections slider, the archive grid…) is edited
 * once and updates everywhere. Recursion-safe.
 *
 * With Elementor Pro active the widget is hidden from the panel (Pro has its own
 * Template widget); existing instances keep working.
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor\Widgets;

use Elementor\Controls_Manager;
use Sogand\Core\Elementor\Widget_Base;
use Sogand\Core\Elementor\Bridge;
use Sogand\Core\Elementor\Kit_Layout;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Template_Ref extends Widget_Base {

	public function get_name() {
		return 'sogand-template';
	}

	public function get_title() {
		return esc_html__( 'Saved Template', 'sogand-core' );
	}

	public function get_icon() {
		return 'eicon-document-file';
	}

	public function get_keywords() {
		return array( 'sogand', 'template', 'saved', 'reference', 'global', 'shared', 'library' );
	}

	public function show_in_panel() {
		return ! defined( 'ELEMENTOR_PRO_VERSION' );
	}

	protected function register_controls() {
		$this->start_controls_section( 'content', array( 'label' => esc_html__( 'Template', 'sogand-core' ) ) );
		$this->add_control( 'template_id', array(
			'label'       => esc_html__( 'Saved template', 'sogand-core' ),
			'type'        => Controls_Manager::SELECT,
			'options'     => Kit_Layout::template_options( array( 'section', 'container', 'page' ) ),
			'default'     => '',
			'label_block' => true,
		) );
		$this->add_control( 'template_note', array(
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => esc_html__( 'The template is shown by reference: edit it once under Templates → Saved Templates and every page that uses it updates. A template cannot include itself.', 'sogand-core' ),
			'content_classes' => 'elementor-descriptor',
		) );
		$this->end_controls_section();
	}

	protected function render() {
		$s  = $this->get_settings_for_display();
		$id = absint( $s['template_id'] );
		$ok = $id && 'elementor_library' === get_post_type( $id ) && in_array( get_post_status( $id ), array( 'publish', 'private' ), true );
		if ( ! $ok ) {
			if ( $this->in_editor() ) {
				echo '<div class="sg-empty">' . esc_html__( 'Choose a saved template in the panel.', 'sogand-core' ) . '</div>';
			}
			return;
		}
		/* the template being edited, or one already on the render stack, would loop */
		$current = get_the_ID();
		if ( (int) $current === $id || Bridge::is_rendering( $id ) ) {
			if ( $this->in_editor() ) {
				echo '<div class="sg-empty">' . esc_html__( 'A template cannot include itself.', 'sogand-core' ) . '</div>';
			}
			return;
		}
		$html = Bridge::render_template( $id );
		if ( '' === $html ) {
			if ( $this->in_editor() ) {
				echo '<div class="sg-empty">' . esc_html__( 'This template is empty.', 'sogand-core' ) . '</div>';
			}
			return;
		}
		if ( $this->in_editor() && current_user_can( 'edit_post', $id ) ) {
			$edit = add_query_arg( array( 'post' => $id, 'action' => 'elementor' ), admin_url( 'post.php' ) );
			echo '<a class="sg-tpl-edit" href="' . esc_url( $edit ) . '" target="_blank" rel="noopener">' . esc_html__( 'Edit template', 'sogand-core' ) . '</a>';
		}
		echo '<div class="sg-tpl-ref">' . $html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Elementor output
	}
}

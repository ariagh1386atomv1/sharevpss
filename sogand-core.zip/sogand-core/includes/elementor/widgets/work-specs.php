<?php
/**
 * Sogand Work Details — the labelled detail list of a portfolio entry
 * (collection, materials, gemstones, technique, year and any extra rows).
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Sogand\Core\Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Work_Specs extends Widget_Base {

	public function get_name() {
		return 'sogand-work-specs';
	}

	public function get_title() {
		return esc_html__( 'Work Details', 'sogand-core' );
	}

	public function get_icon() {
		return 'eicon-bullet-list';
	}

	public function get_keywords() {
		return array( 'sogand', 'work', 'specs', 'details', 'materials', 'gemstones', 'portfolio' );
	}

	protected function register_controls() {
		$this->start_controls_section( 'content', array( 'label' => esc_html__( 'Details', 'sogand-core' ) ) );
		$this->add_control( 'hide', array(
			'label'       => esc_html__( 'Hide rows', 'sogand-core' ),
			'type'        => Controls_Manager::SELECT2,
			'multiple'    => true,
			'label_block' => true,
			'default'     => array(),
			'options'     => array(
				'collection' => esc_html__( 'Collection', 'sogand-core' ),
				'materials'  => esc_html__( 'Materials', 'sogand-core' ),
				'gemstones'  => esc_html__( 'Gemstones', 'sogand-core' ),
				'technique'  => esc_html__( 'Technique', 'sogand-core' ),
				'year'       => esc_html__( 'Year', 'sogand-core' ),
				'extra'      => esc_html__( 'Extra rows of the work', 'sogand-core' ),
			),
		) );
		$this->add_control( 'layout', array(
			'label'        => esc_html__( 'Layout', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => 'rows',
			'options'      => array(
				'rows'    => esc_html__( 'Rows (label left, value right)', 'sogand-core' ),
				'stacked' => esc_html__( 'Stacked (label above value)', 'sogand-core' ),
			),
			'prefix_class' => 'sg-ws-',
		) );
		$this->add_responsive_control( 'cols', array(
			'label'     => esc_html__( 'Columns', 'sogand-core' ),
			'type'      => Controls_Manager::NUMBER,
			'min'       => 1,
			'max'       => 4,
			'default'   => 1,
			'selectors' => array( '{{WRAPPER}} .sg-specs' => 'grid-template-columns: repeat({{VALUE}}, minmax(0, 1fr));' ),
		) );
		$this->add_control( 'empty', array( 'label' => esc_html__( 'Text when the work has no details', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => '' ) );
		$this->end_controls_section();

		$this->start_controls_section( 'style', array( 'label' => esc_html__( 'Details', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_responsive_control( 'gap', array(
			'label'      => esc_html__( 'Row gap', 'sogand-core' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => array( 'px', 'rem' ),
			'range'      => array( 'px' => array( 'min' => 0, 'max' => 60 ) ),
			'selectors'  => array( '{{WRAPPER}} .sg-specs' => 'row-gap: {{SIZE}}{{UNIT}};' ),
		) );
		$this->add_responsive_control( 'pad', array(
			'label'      => esc_html__( 'Row padding', 'sogand-core' ),
			'type'       => Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'rem' ),
			'selectors'  => array( '{{WRAPPER}} .sg-specs > div' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );
		$this->add_group_control( Group_Control_Border::get_type(), array( 'name' => 'row_border', 'label' => esc_html__( 'Row line', 'sogand-core' ), 'selector' => '{{WRAPPER}} .sg-specs > div' ) );
		$this->add_control( 'h_label', array( 'label' => esc_html__( 'Label', 'sogand-core' ), 'type' => Controls_Manager::HEADING, 'separator' => 'before' ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'lt', 'selector' => '{{WRAPPER}} .sg-specs dt' ) );
		$this->add_control( 'lc', array( 'label' => esc_html__( 'Colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-specs dt' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'h_value', array( 'label' => esc_html__( 'Value', 'sogand-core' ), 'type' => Controls_Manager::HEADING, 'separator' => 'before' ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'vt', 'selector' => '{{WRAPPER}} .sg-specs dd' ) );
		$this->add_control( 'vc', array( 'label' => esc_html__( 'Colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-specs dd' => 'color: {{VALUE}};' ) ) );
		$this->end_controls_section();
	}

	protected function render() {
		$s  = $this->get_settings_for_display();
		$id = sgc_current_work_id();
		if ( ! $id ) {
			if ( $this->in_editor() ) {
				echo '<div class="sg-empty">' . esc_html__( 'Add a work under Works to preview its details.', 'sogand-core' ) . '</div>';
			}
			return;
		}
		$hide  = is_array( $s['hide'] ) ? $s['hide'] : array();
		$terms = get_the_terms( $id, 'sg_collection' );
		$rows  = array();
		$fixed = array(
			'collection' => array( __( 'Collection', 'sogand-site' ), ( $terms && ! is_wp_error( $terms ) ) ? implode( ', ', wp_list_pluck( $terms, 'name' ) ) : '' ),
			'materials'  => array( __( 'Materials', 'sogand-site' ), get_post_meta( $id, '_sg_materials', true ) ),
			'gemstones'  => array( __( 'Gemstones', 'sogand-site' ), get_post_meta( $id, '_sg_gemstones', true ) ),
			'technique'  => array( __( 'Technique', 'sogand-site' ), get_post_meta( $id, '_sg_technique', true ) ),
			'year'       => array( __( 'Year', 'sogand-site' ), get_post_meta( $id, '_sg_year', true ) ),
		);
		foreach ( $fixed as $k => $r ) {
			if ( ! in_array( $k, $hide, true ) ) {
				$rows[] = $r;
			}
		}
		if ( ! in_array( 'extra', $hide, true ) ) {
			foreach ( sgc_work_specs( $id ) as $sp ) {
				$rows[] = array( $sp['title'], $sp['value'] );
			}
		}
		$rows = array_filter( $rows, function ( $r ) {
			return '' !== trim( (string) $r[0] ) && '' !== trim( (string) $r[1] );
		} );
		if ( ! $rows ) {
			if ( '' !== (string) $s['empty'] ) {
				echo '<p class="sg-specs-empty">' . esc_html( $s['empty'] ) . '</p>';
			}
			return;
		}
		echo '<dl class="sg-specs">';
		foreach ( $rows as $r ) {
			echo '<div><dt>' . esc_html( $r[0] ) . '</dt><dd>' . esc_html( $r[1] ) . '</dd></div>';
		}
		echo '</dl>';
	}
}

<?php
/**
 * Sogand Inquiry Form — the commission / contact form. Messages are stored under
 * Inquiries and emailed to the addresses set in Settings → Sogand Settings
 * (never to an address taken from the page). Honeypot, timing token, rate limit and
 * optional Cloudflare Turnstile protect it.
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Sogand\Core\Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Contact_Form extends Widget_Base {

	public function get_name() {
		return 'sogand-contact-form';
	}

	public function get_title() {
		return esc_html__( 'Inquiry Form', 'sogand-core' );
	}

	public function get_icon() {
		return 'eicon-form-horizontal';
	}

	public function get_keywords() {
		return array( 'sogand', 'form', 'contact', 'inquiry', 'commission', 'email' );
	}

	public function get_style_depends(): array {
		return array( 'sgc-base', 'sgc-forms' );
	}

	public function get_script_depends(): array {
		return array( 'sgc-core', 'sgc-forms' );
	}

	public static function default_services() {
		return array(
			array( 'value' => 'design-ideation', 'label' => 'Design & Ideation' ),
			array( 'value' => 'bespoke-jewelry', 'label' => 'Bespoke Jewelry' ),
			array( 'value' => 'digital-rendering', 'label' => 'Digital Rendering' ),
			array( 'value' => '3d-modeling', 'label' => '3D Modeling' ),
			array( 'value' => 'procreate-brushes', 'label' => 'Custom Procreate Brush Creation' ),
			array( 'value' => 'collaboration', 'label' => 'Brand collaboration' ),
			array( 'value' => 'other', 'label' => 'Something else' ),
		);
	}

	protected function register_controls() {
		/* ---- fields ---- */
		$this->start_controls_section( 'fields', array( 'label' => esc_html__( 'Fields', 'sogand-core' ) ) );
		$this->add_control( 'l_name', array( 'label' => esc_html__( 'Name label', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Your name' ) );
		$this->add_control( 'l_email', array( 'label' => esc_html__( 'Email label', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Email' ) );
		$this->add_control( 'show_service', array( 'label' => esc_html__( 'Service field', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'separator' => 'before' ) );
		$this->add_control( 'l_service', array( 'label' => esc_html__( 'Service label', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Service', 'condition' => array( 'show_service' => 'yes' ) ) );
		$this->add_control( 'ph_service', array( 'label' => esc_html__( 'Service placeholder', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Choose a service', 'condition' => array( 'show_service' => 'yes' ) ) );
		$r = new Repeater();
		$r->add_control( 'label', array( 'label' => esc_html__( 'Shown text', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => '' ) );
		$r->add_control( 'value', array( 'label' => esc_html__( 'Value (used in links like ?service=bespoke-jewelry)', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => '' ) );
		$this->add_control( 'services', array(
			'label'       => esc_html__( 'Services', 'sogand-core' ),
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $r->get_controls(),
			'default'     => self::default_services(),
			'title_field' => '{{{ label }}}',
			'condition'   => array( 'show_service' => 'yes' ),
		) );
		$this->add_control( 'show_piece', array( 'label' => esc_html__( 'Piece / reference field', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'separator' => 'before' ) );
		$this->add_control( 'l_piece', array( 'label' => esc_html__( 'Piece label', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Piece or reference (optional)', 'condition' => array( 'show_piece' => 'yes' ) ) );
		$this->add_control( 'show_phone', array( 'label' => esc_html__( 'Phone field', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'separator' => 'before' ) );
		$this->add_control( 'l_phone', array( 'label' => esc_html__( 'Phone label', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Phone (optional)', 'condition' => array( 'show_phone' => 'yes' ) ) );
		$this->add_control( 'l_message', array( 'label' => esc_html__( 'Message label', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Tell me about your idea', 'separator' => 'before' ) );
		$this->add_control( 'rows', array( 'label' => esc_html__( 'Message height (lines)', 'sogand-core' ), 'type' => Controls_Manager::NUMBER, 'min' => 2, 'max' => 20, 'default' => 6 ) );
		$this->add_control( 'show_consent', array( 'label' => esc_html__( 'Consent checkbox', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => '', 'separator' => 'before' ) );
		$this->add_control( 'l_consent', array( 'label' => esc_html__( 'Consent text', 'sogand-core' ), 'type' => Controls_Manager::TEXTAREA, 'default' => 'I agree to be contacted about my inquiry.', 'condition' => array( 'show_consent' => 'yes' ) ) );
		$this->add_control( 'btn', array( 'label' => esc_html__( 'Button text', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Send message', 'separator' => 'before' ) );
		$this->add_control( 'btn_style', array(
			'label'   => esc_html__( 'Button style', 'sogand-core' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'light',
			'options' => array(
				'light' => esc_html__( 'Light (gold)', 'sogand-core' ),
				'glass' => esc_html__( 'Glass', 'sogand-core' ),
			),
		) );
		$this->end_controls_section();

		/* ---- messages ---- */
		$this->start_controls_section( 'messages', array( 'label' => esc_html__( 'Messages', 'sogand-core' ) ) );
		$this->add_control( 'm_name', array( 'label' => esc_html__( 'Missing name', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Please tell me your name.' ) );
		$this->add_control( 'm_email', array( 'label' => esc_html__( 'Invalid email', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Please enter a valid email.' ) );
		$this->add_control( 'm_message', array( 'label' => esc_html__( 'Short message', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'A few words about your project, please.' ) );
		$this->add_control( 'm_consent', array( 'label' => esc_html__( 'Consent missing', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Please confirm the checkbox.' ) );
		$this->add_control( 'm_all', array( 'label' => esc_html__( 'Check the fields', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Please check the highlighted fields.' ) );
		$this->add_control( 'm_sending', array( 'label' => esc_html__( 'While sending', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Sending…' ) );
		$this->add_control( 'done_title', array( 'label' => esc_html__( 'Thank-you title', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Thank you', 'separator' => 'before' ) );
		$this->add_control( 'm_ok', array(
			'label'       => esc_html__( 'Thank-you text', 'sogand-core' ),
			'type'        => Controls_Manager::TEXTAREA,
			'default'     => 'Your message has been received. I will reply personally as soon as possible.',
			'description' => esc_html__( 'Shown when the website has stored the message and handed the email to the mail server. Delivery to the inbox itself cannot be confirmed by a website.', 'sogand-core' ),
		) );
		$this->add_control( 'm_saved', array(
			'label'       => esc_html__( 'Text when the email could not be sent', 'sogand-core' ),
			'type'        => Controls_Manager::TEXTAREA,
			'default'     => 'Your message has been saved on the website, but the email notification could not be sent. I will still see it — or write to me directly at the address on this page.',
		) );
		$this->add_control( 'done_mark', array( 'label' => esc_html__( 'Show the logo mark', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes' ) );
		$this->add_control( 'done_btn1', array( 'label' => esc_html__( 'First button', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Browse collections' ) );
		$this->add_control( 'done_link1', array( 'label' => esc_html__( 'First button link', 'sogand-core' ), 'type' => Controls_Manager::URL, 'description' => esc_html__( 'Empty = the Collections page.', 'sogand-core' ) ) );
		$this->add_control( 'done_btn2', array( 'label' => esc_html__( '“Send another” button', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Send another' ) );
		$this->end_controls_section();

		/* ---- style ---- */
		$this->start_controls_section( 's_fields', array( 'label' => esc_html__( 'Fields', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_responsive_control( 'gap', array( 'label' => esc_html__( 'Space between fields', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 60 ) ), 'selectors' => array( '{{WRAPPER}} .sg-form' => '--sg-f-gap: {{SIZE}}px;' ) ) );
		$this->add_control( 'two_cols', array( 'label' => esc_html__( 'Name and email side by side', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'prefix_class' => 'sg-f2-' ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'lab_t', 'label' => esc_html__( 'Labels', 'sogand-core' ), 'selector' => '{{WRAPPER}} .sg-f > span' ) );
		$this->add_control( 'lab_c', array( 'label' => esc_html__( 'Label colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-f > span' => 'color: {{VALUE}};' ) ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'in_t', 'label' => esc_html__( 'Typed text', 'sogand-core' ), 'selector' => '{{WRAPPER}} .sg-f input, {{WRAPPER}} .sg-f select, {{WRAPPER}} .sg-f textarea' ) );
		$this->add_control( 'in_c', array( 'label' => esc_html__( 'Text colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-f input, {{WRAPPER}} .sg-f select, {{WRAPPER}} .sg-f textarea' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'in_bg', array( 'label' => esc_html__( 'Field background', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-f input, {{WRAPPER}} .sg-f select, {{WRAPPER}} .sg-f textarea' => 'background-color: {{VALUE}};' ) ) );
		$this->add_group_control( Group_Control_Border::get_type(), array( 'name' => 'in_b', 'selector' => '{{WRAPPER}} .sg-f input, {{WRAPPER}} .sg-f select, {{WRAPPER}} .sg-f textarea' ) );
		$this->add_control( 'in_r', array( 'label' => esc_html__( 'Corner radius', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 40 ) ), 'selectors' => array( '{{WRAPPER}} .sg-f input, {{WRAPPER}} .sg-f select, {{WRAPPER}} .sg-f textarea' => 'border-radius: {{SIZE}}px;' ) ) );
		$this->add_control( 'focus_c', array( 'label' => esc_html__( 'Focus colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-form' => '--sg-f-focus: {{VALUE}};' ) ) );
		$this->add_control( 'err_c', array( 'label' => esc_html__( 'Error colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-form' => '--sg-f-err: {{VALUE}};' ) ) );
		$this->end_controls_section();

		$this->start_controls_section( 's_btn', array( 'label' => esc_html__( 'Button', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'btn_t', 'selector' => '{{WRAPPER}} .sg-form .sg-btn' ) );
		$this->add_control( 'btn_c', array( 'label' => esc_html__( 'Text colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-form .sg-btn' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'btn_bg', array( 'label' => esc_html__( 'Background', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-form .sg-btn' => 'background: {{VALUE}};' ) ) );
		$this->add_control( 'btn_align', array(
			'label'     => esc_html__( 'Position', 'sogand-core' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => array(
				'flex-start'    => array( 'title' => esc_html__( 'Start', 'sogand-core' ), 'icon' => 'eicon-h-align-left' ),
				'space-between' => array( 'title' => esc_html__( 'Spread', 'sogand-core' ), 'icon' => 'eicon-h-align-stretch' ),
				'flex-end'      => array( 'title' => esc_html__( 'End', 'sogand-core' ), 'icon' => 'eicon-h-align-right' ),
			),
			'selectors' => array( '{{WRAPPER}} .sg-f-foot' => 'justify-content: {{VALUE}};' ),
		) );
		$this->end_controls_section();
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$uid   = 'sgf' . $this->get_id();
		$tsite = (string) sgc_setting( 'turnstile_site' );
		$tsec  = (string) sgc_setting( 'turnstile_secret' );
		$ts_on = '' !== $tsite && '' !== $tsec && ! $this->in_editor();
		if ( $ts_on ) {
			wp_enqueue_script( 'sgc-turnstile', 'https://challenges.cloudflare.com/turnstile/v0/api.js', array(), null, array( 'strategy' => 'defer', 'in_footer' => true ) ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
		}
		$msgs = array(
			'name'    => $s['m_name'],
			'email'   => $s['m_email'],
			'message' => $s['m_message'],
			'consent' => $s['m_consent'],
			'all'     => $s['m_all'],
			'sending' => $s['m_sending'],
			'ok'      => $s['m_ok'],
			'saved'   => $s['m_saved'],
		);
		$btn_cls = 'glass' === $s['btn_style'] ? 'sg-btn sg-btn-glass' : 'sg-btn sg-btn-light';
		$link1   = ! empty( $s['done_link1']['url'] ) ? $s['done_link1']['url'] : sgc_collections_url();

		echo '<div class="sg-form-box" data-sg-form="contact" data-msgs="' . esc_attr( wp_json_encode( $msgs ) ) . '">';
		echo '<form class="sg-form" novalidate>';
		echo '<input type="text" name="website" tabindex="-1" autocomplete="off" class="sg-hp" aria-hidden="true">';
		echo '<input type="hidden" name="_sgt" value="' . esc_attr( sgc_form_token() ) . '">';
		echo '<input type="hidden" name="type" value="contact">';
		echo '<div class="sg-f-row sg-f-pair">';
		$this->field( $uid, 'name', $s['l_name'], 'text', array( 'autocomplete' => 'name', 'required' => true ) );
		$this->field( $uid, 'email', $s['l_email'], 'email', array( 'autocomplete' => 'email', 'required' => true ) );
		echo '</div>';
		if ( 'yes' === $s['show_service'] ) {
			echo '<label class="sg-f" for="' . esc_attr( $uid ) . '-service"><span>' . esc_html( $s['l_service'] ) . '</span><select id="' . esc_attr( $uid ) . '-service" name="service">';
			echo '<option value="">' . esc_html( $s['ph_service'] ) . '</option>';
			foreach ( (array) $s['services'] as $o ) {
				$label = trim( (string) $o['label'] );
				if ( '' === $label ) {
					continue;
				}
				$val = '' !== trim( (string) $o['value'] ) ? sanitize_title( $o['value'] ) : sanitize_title( $label );
				echo '<option value="' . esc_attr( $val ) . '">' . esc_html( $label ) . '</option>';
			}
			echo '</select></label>';
		}
		if ( 'yes' === $s['show_piece'] ) {
			$this->field( $uid, 'piece', $s['l_piece'], 'text', array() );
		}
		if ( 'yes' === $s['show_phone'] ) {
			$this->field( $uid, 'phone', $s['l_phone'], 'tel', array( 'autocomplete' => 'tel', 'dir' => 'ltr' ) );
		}
		$this->field( $uid, 'message', $s['l_message'], 'textarea', array( 'rows' => max( 2, (int) $s['rows'] ), 'required' => true ) );
		if ( 'yes' === $s['show_consent'] ) {
			echo '<label class="sg-f-check"><input type="checkbox" name="consent" value="1" data-required="1"><span>' . esc_html( $s['l_consent'] ) . '</span></label>';
		}
		if ( $ts_on ) {
			echo '<div class="cf-turnstile sg-f-ts" data-sitekey="' . esc_attr( $tsite ) . '" data-theme="dark"></div>';
		}
		echo '<div class="sg-f-foot"><p class="sg-f-note" role="status" aria-live="polite"></p>';
		echo '<button type="submit" class="' . esc_attr( $btn_cls ) . '"><span class="sg-btn-t">' . esc_html( $s['btn'] ) . '</span></button></div>';
		echo '</form>';

		echo '<div class="sg-form-done" hidden tabindex="-1">';
		if ( 'yes' === $s['done_mark'] ) {
			echo '<img src="' . esc_url( sgc_asset( 'img/mark-gold.webp' ) ) . '" alt="" width="72" height="72" loading="lazy">';
		}
		echo '<h3 class="sg-form-done-t">' . esc_html( $s['done_title'] ) . '</h3><p class="sg-form-done-m"></p>';
		echo '<div class="sg-btn-row">';
		if ( '' !== (string) $s['done_btn1'] ) {
			echo '<a class="sg-btn sg-btn-glass" href="' . esc_url( $link1 ) . '">' . esc_html( $s['done_btn1'] ) . '</a>';
		}
		if ( '' !== (string) $s['done_btn2'] ) {
			echo '<button type="button" class="sg-btn sg-btn-light" data-sg-again>' . esc_html( $s['done_btn2'] ) . '</button>';
		}
		echo '</div></div>';
		echo '</div>';
	}

	private function field( $uid, $name, $label, $type, $attrs ) {
		$id  = $uid . '-' . $name;
		$req = ! empty( $attrs['required'] );
		unset( $attrs['required'] );
		$a = '';
		foreach ( $attrs as $k => $v ) {
			$a .= ' ' . $k . '="' . esc_attr( $v ) . '"';
		}
		if ( $req ) {
			$a .= ' data-required="1" aria-required="true"';
		}
		echo '<label class="sg-f" for="' . esc_attr( $id ) . '"><span>' . esc_html( $label ) . '</span>';
		if ( 'textarea' === $type ) {
			echo '<textarea id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '"' . $a . '></textarea>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} else {
			echo '<input id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" type="' . esc_attr( $type ) . '"' . $a . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '<em class="sg-f-err" id="' . esc_attr( $id ) . '-err" hidden></em></label>';
	}
}

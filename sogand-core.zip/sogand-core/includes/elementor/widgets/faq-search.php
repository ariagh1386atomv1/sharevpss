<?php
/**
 * Sogand FAQ — questions grouped under headings, with an instant search box and
 * accessible open/close answers (native details/summary). Optional FAQPage schema.
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Sogand\Core\Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Faq_Search extends Widget_Base {

	public function get_name() {
		return 'sogand-faq';
	}

	public function get_title() {
		return esc_html__( 'FAQ with Search', 'sogand-core' );
	}

	public function get_icon() {
		return 'eicon-help-o';
	}

	public function get_keywords() {
		return array( 'sogand', 'faq', 'questions', 'answers', 'accordion', 'search' );
	}

	public function get_style_depends(): array {
		return array( 'sgc-base', 'sgc-forms' );
	}

	public function get_script_depends(): array {
		return array( 'sgc-core', 'sgc-forms' );
	}

	/** The client's FAQ copy (do not reword). */
	public static function default_items() {
		return array(
			array( 'group' => 'About My Design Services', 'q' => 'What services do you offer?', 'a' => 'I specialize in jewelry design, concept development, and visual presentation. My services include original jewelry concepts, bespoke design, collection development, and digital renderings tailored to each project’s creative direction and requirements.' ),
			array( 'group' => 'About My Design Services', 'q' => 'Do you accept custom jewelry design requests?', 'a' => 'Yes. I welcome custom design requests and work closely with clients to develop original pieces that reflect their personal style, vision, and preferences.' ),
			array( 'group' => 'About My Design Services', 'q' => 'Can I commission a completely original jewelry design?', 'a' => 'Absolutely. Each project begins with an understanding of your vision, inspiration, and objectives, allowing me to develop a distinctive design concept tailored specifically to your needs.' ),
			array( 'group' => 'About My Design Services', 'q' => 'Do you work with jewelry brands and manufacturers?', 'a' => 'Yes. I collaborate with jewelry brands, manufacturers, and industry professionals on individual designs, exclusive collections, and creative development projects.' ),
			array( 'group' => 'The Design Process', 'q' => 'How does the jewelry design process work?', 'a' => 'The process begins with an initial discussion about your ideas, preferences, and project requirements. From there, I develop the design concept and refine the details through a collaborative process, ensuring the final design aligns with the agreed creative direction.' ),
			array( 'group' => 'The Design Process', 'q' => 'Can I share my own inspiration or reference images?', 'a' => 'Of course. Reference images, sketches, gemstones, architectural forms, cultural influences, or personal stories can all serve as inspiration. These references help establish the creative direction while allowing room for an original interpretation.' ),
			array( 'group' => 'The Design Process', 'q' => 'Do you provide digital jewelry renderings?', 'a' => 'Yes. Digital renderings can be included in selected projects to communicate the design’s form, proportions, materials, and gemstones through detailed visual presentations.' ),
			array( 'group' => 'The Design Process', 'q' => 'Can you create a complete jewelry collection for my brand?', 'a' => 'Yes. I accept projects involving the creative development of jewelry collections, from establishing a cohesive design language to developing individual pieces that work together as a unified collection.' ),
			array( 'group' => 'Orders & Collaboration', 'q' => 'How can I request a design or discuss a project?', 'a' => 'You can get in touch through the contact form on my website or via email. Please include a brief description of your project, your ideas, and any relevant references so I can better understand your requirements.' ),
			array( 'group' => 'Orders & Collaboration', 'q' => 'Do you work with international clients?', 'a' => 'Yes. I welcome inquiries from clients and brands worldwide. The design process can be managed remotely through online communication and digital presentations.' ),
			array( 'group' => 'Orders & Collaboration', 'q' => 'How long does a jewelry design project take?', 'a' => 'The timeline depends on the project’s complexity, scope, and revision requirements. Once I understand your brief, I can provide a more accurate estimate of the expected timeframe.' ),
			array( 'group' => 'Orders & Collaboration', 'q' => 'How much do your design services cost?', 'a' => 'Pricing depends on the nature of the project, its complexity, and the scope of work involved. Please contact me with your project details to receive information tailored to your requirements.' ),
			array( 'group' => 'Design Rights & Deliverables', 'q' => 'Will I own the rights to my commissioned design?', 'a' => 'Design ownership and usage rights depend on the terms agreed upon for each project. Intellectual property, exclusivity, and permitted use will be clarified before the project begins.' ),
			array( 'group' => 'Design Rights & Deliverables', 'q' => 'Do you offer exclusive designs for jewelry brands?', 'a' => 'Yes. Exclusive design arrangements can be discussed for suitable projects. The terms of exclusivity, including the scope of use and ownership rights, will be established through a separate agreement.' ),
			array( 'group' => 'Design Rights & Deliverables', 'q' => 'Do you provide manufacturing services?', 'a' => 'My primary focus is jewelry design and creative development. Manufacturing arrangements depend on the specific project and can be discussed during the initial consultation.' ),
			array( 'group' => 'Design Rights & Deliverables', 'q' => 'Can I request revisions to a design?', 'a' => 'Yes. The design process includes opportunities for feedback and refinement. The number of revisions and the scope of any additional changes will be agreed upon at the beginning of the project.' ),
		);
	}

	protected function register_controls() {
		$this->start_controls_section( 'content', array( 'label' => esc_html__( 'Questions', 'sogand-core' ) ) );
		$r = new Repeater();
		$r->add_control( 'group', array( 'label' => esc_html__( 'Group heading', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => '', 'description' => esc_html__( 'Questions with the same heading are shown together.', 'sogand-core' ) ) );
		$r->add_control( 'q', array( 'label' => esc_html__( 'Question', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'label_block' => true, 'default' => '' ) );
		$r->add_control( 'a', array( 'label' => esc_html__( 'Answer', 'sogand-core' ), 'type' => Controls_Manager::WYSIWYG, 'default' => '' ) );
		$this->add_control( 'items', array(
			'label'       => esc_html__( 'Questions', 'sogand-core' ),
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $r->get_controls(),
			'default'     => self::default_items(),
			'title_field' => '{{{ q }}}',
		) );
		$this->add_control( 'layout', array(
			'label'        => esc_html__( 'Layout', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => 'sidebar',
			'options'      => array(
				'sidebar' => esc_html__( 'Topic list + answers', 'sogand-core' ),
				'columns' => esc_html__( 'Groups in columns', 'sogand-core' ),
				'stacked' => esc_html__( 'All groups one under another', 'sogand-core' ),
			),
			'prefix_class' => 'sg-faq-l-',
			'separator'    => 'before',
		) );
		$this->add_control( 'search', array( 'label' => esc_html__( 'Search box', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'separator' => 'before' ) );
		$this->add_control( 'search_ph', array( 'label' => esc_html__( 'Search placeholder', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Search the questions', 'condition' => array( 'search' => 'yes' ) ) );
		$this->add_control( 'none', array( 'label' => esc_html__( 'Text when nothing matches', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'No question matches — write to me and I will answer personally.', 'condition' => array( 'search' => 'yes' ) ) );
		$this->add_control( 'show_groups', array( 'label' => esc_html__( 'Show group headings', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes' ) );
		$this->add_control( 'group_tag', array( 'label' => esc_html__( 'Group heading tag', 'sogand-core' ), 'type' => Controls_Manager::SELECT, 'default' => 'h3', 'options' => array( 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'div' => 'div' ), 'condition' => array( 'show_groups' => 'yes' ) ) );
		$this->add_control( 'first_open', array( 'label' => esc_html__( 'Open the first answer', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => '' ) );
		$this->add_control( 'single', array( 'label' => esc_html__( 'Only one answer open at a time', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes' ) );
		$this->add_responsive_control( 'cols', array( 'label' => esc_html__( 'Group columns', 'sogand-core' ), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 3, 'default' => 2, 'tablet_default' => 1, 'mobile_default' => 1, 'selectors' => array( '{{WRAPPER}} .sg-faq-groups' => 'grid-template-columns: repeat({{VALUE}}, minmax(0, 1fr));' ) ) );
		$this->add_control( 'schema', array( 'label' => esc_html__( 'Add FAQ structured data (SEO)', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => '', 'description' => esc_html__( 'Turn on for one FAQ per page only. Leave off if an SEO plugin already adds FAQ data.', 'sogand-core' ) ) );
		$this->end_controls_section();

		$this->start_controls_section( 's_items', array( 'label' => esc_html__( 'Questions', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'g_t', 'label' => esc_html__( 'Group headings', 'sogand-core' ), 'selector' => '{{WRAPPER}} .sg-faq-gt' ) );
		$this->add_control( 'g_c', array( 'label' => esc_html__( 'Group heading colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-faq-gt' => 'color: {{VALUE}};' ) ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'q_t', 'label' => esc_html__( 'Questions', 'sogand-core' ), 'selector' => '{{WRAPPER}} .sg-faq-q' ) );
		$this->add_control( 'q_c', array( 'label' => esc_html__( 'Question colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-faq-q' => 'color: {{VALUE}};' ) ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'a_t', 'label' => esc_html__( 'Answers', 'sogand-core' ), 'selector' => '{{WRAPPER}} .sg-faq-a' ) );
		$this->add_control( 'a_c', array( 'label' => esc_html__( 'Answer colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-faq-a' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'icon_c', array( 'label' => esc_html__( 'Plus icon colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-faq-ic' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'item_bg', array( 'label' => esc_html__( 'Item background', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-faq-item' => 'background: {{VALUE}};' ) ) );
		$this->add_group_control( Group_Control_Border::get_type(), array( 'name' => 'item_b', 'selector' => '{{WRAPPER}} .sg-faq-item' ) );
		$this->add_control( 'item_r', array( 'label' => esc_html__( 'Item corner radius', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 40 ) ), 'selectors' => array( '{{WRAPPER}} .sg-faq-item' => 'border-radius: {{SIZE}}px;' ) ) );
		$this->end_controls_section();
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$items = array_values( array_filter( (array) $s['items'], function ( $i ) {
			return '' !== trim( (string) $i['q'] );
		} ) );
		if ( ! $items ) {
			return;
		}
		$groups = array();
		foreach ( $items as $it ) {
			$g = trim( (string) $it['group'] );
			if ( ! isset( $groups[ $g ] ) ) {
				$groups[ $g ] = array();
			}
			$groups[ $g ][] = $it;
		}
		$tag     = in_array( $s['group_tag'], array( 'h2', 'h3', 'h4', 'div' ), true ) ? $s['group_tag'] : 'h3';
		$uid     = 'sgfaq' . $this->get_id();
		$name    = 'yes' === $s['single'] ? $uid : '';
		$sidebar = 'sidebar' === $s['layout'] && count( $groups ) > 1;
		echo '<div class="sg-faq' . ( $sidebar ? ' has-nav' : '' ) . '" data-single="' . ( $name ? '1' : '0' ) . '">';
		if ( 'yes' === $s['search'] ) {
			echo '<div class="sg-faq-search"><label class="sg-sr" for="' . esc_attr( $uid ) . '-q">' . esc_html( $s['search_ph'] ) . '</label>';
			echo self::icon( 'search', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '<input id="' . esc_attr( $uid ) . '-q" type="search" placeholder="' . esc_attr( $s['search_ph'] ) . '" autocomplete="off"></div>';
		}
		if ( $sidebar ) {
			echo '<div class="sg-faq-nav" role="group" aria-label="' . esc_attr__( 'Topics', 'sogand-site' ) . '">';
			$g = 0;
			foreach ( $groups as $title => $list ) {
				echo '<button type="button" class="sg-faq-topic' . ( 0 === $g ? ' is-on' : '' ) . '" aria-pressed="' . ( 0 === $g ? 'true' : 'false' ) . '" aria-controls="' . esc_attr( $uid . '-g' . $g ) . '" data-g="' . (int) $g . '"><span>' . esc_html( str_pad( (string) ( $g + 1 ), 2, '0', STR_PAD_LEFT ) ) . '</span>' . esc_html( '' !== $title ? $title : __( 'Questions', 'sogand-site' ) ) . '<em>' . count( $list ) . '</em></button>';
				$g++;
			}
			echo '</div>';
		}
		echo '<div class="sg-faq-groups">';
		$n  = 0;
		$gi = 0;
		foreach ( $groups as $title => $list ) {
			echo '<div class="sg-faq-group" id="' . esc_attr( $uid . '-g' . $gi ) . '"' . ( $sidebar && $gi > 0 ? ' data-off="1"' : '' ) . '>';
			$gi++;
			if ( 'yes' === $s['show_groups'] && '' !== $title ) {
				echo '<' . $tag . ' class="sg-faq-gt">' . esc_html( $title ) . '</' . $tag . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			foreach ( $list as $it ) {
				$open = ( 0 === $n && 'yes' === $s['first_open'] ) ? ' open' : '';
				echo '<details class="sg-faq-item"' . $open . ( $name ? ' name="' . esc_attr( $name ) . '"' : '' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo '<summary><span class="sg-faq-q">' . esc_html( $it['q'] ) . '</span><span class="sg-faq-ic" aria-hidden="true"></span></summary>';
				echo '<div class="sg-faq-a">' . wp_kses_post( wpautop( (string) $it['a'] ) ) . '</div></details>';
				$n++;
			}
			echo '</div>';
		}
		echo '</div>';
		if ( 'yes' === $s['search'] ) {
			echo '<p class="sg-faq-none" hidden>' . esc_html( $s['none'] ) . '</p>';
		}
		echo '</div>';

		if ( 'yes' === $s['schema'] && ! $this->in_editor() ) {
			$main = array();
			foreach ( $items as $it ) {
				$main[] = array(
					'@type'          => 'Question',
					'name'           => wp_strip_all_tags( $it['q'] ),
					'acceptedAnswer' => array( '@type' => 'Answer', 'text' => wp_strip_all_tags( (string) $it['a'] ) ),
				);
			}
			echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $main ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ) . '</script>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}
}

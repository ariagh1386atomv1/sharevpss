<?php
/**
 * Sogand Animated Logo — the colour-shifting metal mark (and optional signature).
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor\Widgets;

use Elementor\Controls_Manager;
use Sogand\Core\Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Logo extends Widget_Base {

	public function get_name() {
		return 'sogand-logo';
	}

	public function get_title() {
		return esc_html__( 'Animated Logo', 'sogand-core' );
	}

	public function get_icon() {
		return 'eicon-site-logo';
	}

	public function get_keywords() {
		return array( 'sogand', 'logo', 'brand', 'mark', 'signature' );
	}

	protected function register_controls() {
		$this->start_controls_section( 'content', array( 'label' => esc_html__( 'Logo', 'sogand-core' ) ) );
		$this->add_control( 'source', array(
			'label'   => esc_html__( 'Logo image', 'sogand-core' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'bundled',
			'options' => array(
				'bundled' => esc_html__( 'Sogand mark (bundled)', 'sogand-core' ),
				'site'    => esc_html__( 'Site logo (Appearance → Customize)', 'sogand-core' ),
				'custom'  => esc_html__( 'Choose an image', 'sogand-core' ),
			),
		) );
		$this->add_control( 'image', array(
			'label'       => esc_html__( 'Image', 'sogand-core' ),
			'type'        => Controls_Manager::MEDIA,
			'condition'   => array( 'source' => 'custom' ),
			'description' => esc_html__( 'A transparent PNG, WebP or SVG works best. In the colour modes its shape is filled with the moving colours.', 'sogand-core' ),
		) );
		$this->add_control( 'mode', array(
			'label'   => esc_html__( 'Look', 'sogand-core' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'metal',
			'options' => array(
				'metal'    => esc_html__( 'Gold & silver, colour-shifting', 'sogand-core' ),
				'palette'  => esc_html__( 'Your colours, colour-shifting', 'sogand-core' ),
				'image'    => esc_html__( 'Image as uploaded', 'sogand-core' ),
			),
			'description' => esc_html__( 'The colour modes use the picture’s shape as a mask: you can change size, colours and motion here; the artwork itself is edited in an image program.', 'sogand-core' ),
		) );
		$this->add_control( 'show_sig', array(
			'label'        => esc_html__( 'Signature next to the mark', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'default'      => 'yes',
			'return_value' => 'yes',
			'separator'    => 'before',
		) );
		$this->add_control( 'sig_image', array(
			'label'       => esc_html__( 'Signature image', 'sogand-core' ),
			'type'        => Controls_Manager::MEDIA,
			'condition'   => array( 'show_sig' => 'yes' ),
			'description' => esc_html__( 'Empty = the bundled Sogand Andalibazar signature.', 'sogand-core' ),
		) );
		$this->add_control( 'sig_mode', array(
			'label'     => esc_html__( 'Signature look', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'metal',
			'options'   => array(
				'image'   => esc_html__( 'As uploaded', 'sogand-core' ),
				'metal'   => esc_html__( 'Gold & silver, colour-shifting', 'sogand-core' ),
				'palette' => esc_html__( 'Your colours, colour-shifting', 'sogand-core' ),
			),
			'condition' => array( 'show_sig' => 'yes' ),
		) );
		$this->add_control( 'link_to', array(
			'label'     => esc_html__( 'Link', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'home',
			'separator' => 'before',
			'options'   => array(
				'home'   => esc_html__( 'Home page', 'sogand-core' ),
				'custom' => esc_html__( 'Custom URL', 'sogand-core' ),
				'none'   => esc_html__( 'No link', 'sogand-core' ),
			),
		) );
		$this->add_control( 'link', array(
			'label'     => esc_html__( 'URL', 'sogand-core' ),
			'type'      => Controls_Manager::URL,
			'condition' => array( 'link_to' => 'custom' ),
		) );
		$this->add_control( 'label', array(
			'label'       => esc_html__( 'Accessible name', 'sogand-core' ),
			'type'        => Controls_Manager::TEXT,
			'default'     => 'Sogand Andalibazar — Home',
			'description' => esc_html__( 'Read by screen readers instead of the pictures.', 'sogand-core' ),
		) );
		$this->end_controls_section();

		/* ---------------- style: size ---------------- */
		$this->start_controls_section( 'style_size', array( 'label' => esc_html__( 'Size & layout', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_responsive_control( 'size', array(
			'label'      => esc_html__( 'Mark width', 'sogand-core' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => array( 'px', 'vw', 'em' ),
			'range'      => array( 'px' => array( 'min' => 16, 'max' => 600 ) ),
			'default'    => array( 'size' => 70, 'unit' => 'px' ),
			'selectors'  => array( '{{WRAPPER}}' => '--sg-logo-w: {{SIZE}}{{UNIT}};' ),
		) );
		$this->add_responsive_control( 'max', array(
			'label'      => esc_html__( 'Max width', 'sogand-core' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => array( '%', 'px' ),
			'selectors'  => array( '{{WRAPPER}} .sg-logo-mark' => 'max-width: {{SIZE}}{{UNIT}};' ),
		) );
		$this->add_control( 'ratio', array(
			'label'       => esc_html__( 'Aspect ratio (width / height)', 'sogand-core' ),
			'type'        => Controls_Manager::NUMBER,
			'min'         => 0.2,
			'max'         => 6,
			'step'        => 0.01,
			'description' => esc_html__( 'Empty = read from the image.', 'sogand-core' ),
		) );
		$this->add_responsive_control( 'sig_w', array(
			'label'      => esc_html__( 'Signature width', 'sogand-core' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => array( 'px', 'vw' ),
			'range'      => array( 'px' => array( 'min' => 40, 'max' => 600 ) ),
			'default'    => array( 'size' => 150, 'unit' => 'px' ),
			'condition'  => array( 'show_sig' => 'yes' ),
			'selectors'  => array( '{{WRAPPER}}' => '--sg-sig-w: {{SIZE}}{{UNIT}};' ),
		) );
		$this->add_responsive_control( 'dir', array(
			'label'     => esc_html__( 'Arrangement', 'sogand-core' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => array(
				'row'    => array( 'title' => esc_html__( 'Side by side', 'sogand-core' ), 'icon' => 'eicon-h-align-left' ),
				'column' => array( 'title' => esc_html__( 'Stacked', 'sogand-core' ), 'icon' => 'eicon-v-align-top' ),
			),
			'condition' => array( 'show_sig' => 'yes' ),
			'selectors' => array( '{{WRAPPER}} .sg-logo' => 'flex-direction: {{VALUE}};' ),
		) );
		$this->add_responsive_control( 'gap', array(
			'label'     => esc_html__( 'Gap', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0, 'max' => 80 ) ),
			'condition' => array( 'show_sig' => 'yes' ),
			'selectors' => array( '{{WRAPPER}} .sg-logo' => 'gap: {{SIZE}}px;' ),
		) );
		$this->add_responsive_control( 'align', array(
			'label'     => esc_html__( 'Alignment', 'sogand-core' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => array(
				'flex-start' => array( 'title' => esc_html__( 'Start', 'sogand-core' ), 'icon' => 'eicon-text-align-left' ),
				'center'     => array( 'title' => esc_html__( 'Center', 'sogand-core' ), 'icon' => 'eicon-text-align-center' ),
				'flex-end'   => array( 'title' => esc_html__( 'End', 'sogand-core' ), 'icon' => 'eicon-text-align-right' ),
			),
			'selectors' => array( '{{WRAPPER}}' => 'display: flex; justify-content: {{VALUE}};' ),
		) );
		$this->add_control( 'opacity', array(
			'label'     => esc_html__( 'Opacity', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0.1, 'max' => 1, 'step' => 0.05 ) ),
			'selectors' => array( '{{WRAPPER}} .sg-logo' => 'opacity: {{SIZE}};' ),
		) );
		$this->end_controls_section();

		/* ---------------- style: colours & motion ---------------- */
		$this->start_controls_section( 'style_motion', array( 'label' => esc_html__( 'Colours & motion', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		foreach ( array( 1 => '#b8955a', 2 => '#f3e4bd', 3 => '#e9ecf0', 4 => '#c9a35c' ) as $i => $def ) {
			$this->add_control( 'c' . $i, array(
				/* translators: %d: colour number */
				'label'     => sprintf( esc_html__( 'Colour %d', 'sogand-core' ), $i ),
				'type'      => Controls_Manager::COLOR,
				'default'   => $def,
				'condition' => array( 'mode' => 'palette' ),
				'selectors' => array( '{{WRAPPER}}' => '--sg-lc' . $i . ': {{VALUE}};' ),
			) );
		}
		$this->add_control( 'speed', array(
			'label'     => esc_html__( 'Colour shift duration (s)', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 1, 'max' => 40, 'step' => 0.5 ) ),
			'default'   => array( 'size' => 7 ),
			'selectors' => array( '{{WRAPPER}}' => '--sg-logo-dur: {{SIZE}}s;' ),
		) );
		$this->add_control( 'delay', array(
			'label'     => esc_html__( 'Delay (s)', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0, 'max' => 10, 'step' => 0.1 ) ),
			'selectors' => array( '{{WRAPPER}}' => '--sg-logo-delay: {{SIZE}}s;' ),
		) );
		$this->add_control( 'direction', array(
			'label'     => esc_html__( 'Shift direction', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'normal',
			'options'   => array(
				'normal'    => esc_html__( 'Left to right', 'sogand-core' ),
				'reverse'   => esc_html__( 'Right to left', 'sogand-core' ),
				'alternate' => esc_html__( 'Back and forth', 'sogand-core' ),
			),
			'selectors' => array( '{{WRAPPER}}' => '--sg-logo-dir: {{VALUE}};' ),
		) );
		$this->add_control( 'angle', array(
			'label'     => esc_html__( 'Colour angle', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'size_units' => array( 'deg' ),
			'range'     => array( 'deg' => array( 'min' => 0, 'max' => 360 ) ),
			'selectors' => array( '{{WRAPPER}}' => '--sg-logo-angle: {{SIZE}}deg;' ),
		) );
		$this->add_control( 'intensity', array(
			'label'     => esc_html__( 'Brightness', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0.5, 'max' => 1.8, 'step' => 0.05 ) ),
			'selectors' => array( '{{WRAPPER}} .sg-logo-mark, {{WRAPPER}} .sg-logo-sig' => 'filter: brightness({{SIZE}});' ),
		) );
		$this->add_control( 'spin', array(
			'label'        => esc_html__( 'Continuous rotation', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'return_value' => 'yes',
			'separator'    => 'before',
			'prefix_class' => 'sg-logo-spin-',
		) );
		$this->add_control( 'spin_dur', array(
			'label'     => esc_html__( 'Rotation duration (s)', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 2, 'max' => 120 ) ),
			'condition' => array( 'spin' => 'yes' ),
			'selectors' => array( '{{WRAPPER}}' => '--sg-logo-spin: {{SIZE}}s;' ),
		) );
		$this->add_control( 'spin_rev', array(
			'label'        => esc_html__( 'Counter-clockwise', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'return_value' => 'yes',
			'condition'    => array( 'spin' => 'yes' ),
			'selectors'    => array( '{{WRAPPER}}' => '--sg-logo-spin-dir: reverse;' ),
		) );
		$this->add_control( 'hover', array(
			'label'     => esc_html__( 'On hover', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'rotate',
			'options'   => array(
				'none'   => esc_html__( 'Nothing', 'sogand-core' ),
				'rotate' => esc_html__( 'Half turn', 'sogand-core' ),
				'grow'   => esc_html__( 'Grow slightly', 'sogand-core' ),
				'glow'   => esc_html__( 'Glow', 'sogand-core' ),
			),
			'prefix_class' => 'sg-logo-hv-',
		) );
		$this->add_control( 'hover_deg', array(
			'label'     => esc_html__( 'Hover rotation', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'size_units' => array( 'deg' ),
			'range'     => array( 'deg' => array( 'min' => -360, 'max' => 360 ) ),
			'condition' => array( 'hover' => 'rotate' ),
			'selectors' => array( '{{WRAPPER}}' => '--sg-logo-hdeg: {{SIZE}}deg;' ),
		) );
		$this->add_control( 'static', array(
			'label'        => esc_html__( 'Still (no motion at all)', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'return_value' => 'yes',
			'prefix_class' => 'sg-logo-static-',
			'description'  => esc_html__( 'Visitors who ask their system for reduced motion always see the still logo.', 'sogand-core' ),
		) );
		$this->end_controls_section();
	}

	private function ratio_of( $id, $fallback ) {
		if ( $id ) {
			$m = wp_get_attachment_metadata( $id );
			if ( ! empty( $m['width'] ) && ! empty( $m['height'] ) ) {
				return round( $m['width'] / $m['height'], 4 );
			}
		}
		return $fallback;
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$id = 0;
		$url = '';
		if ( 'custom' === $s['source'] && ! empty( $s['image']['url'] ) ) {
			$m   = $this->media( $s['image'] );
			$id  = $m['id'];
			$url = $m['url'];
		} elseif ( 'site' === $s['source'] && get_theme_mod( 'custom_logo' ) ) {
			$id  = (int) get_theme_mod( 'custom_logo' );
			$url = (string) wp_get_attachment_image_url( $id, 'full' );
		}
		if ( '' === $url ) {
			$url = sgc_asset( 'img/mark-gold.webp' );
		}
		$ratio = ! empty( $s['ratio'] ) ? (float) $s['ratio'] : $this->ratio_of( $id, $id ? 1 : 900 / 738 );

		$tag  = 'a';
		$href = home_url( '/' );
		if ( 'custom' === $s['link_to'] && ! empty( $s['link']['url'] ) ) {
			$href = $s['link']['url'];
		} elseif ( 'none' === $s['link_to'] ) {
			$tag = 'span';
		}
		$label = $s['label'] ? $s['label'] : get_bloginfo( 'name' );
		$attr  = 'a' === $tag ? ' href="' . esc_url( $href ) . '"' . ( 'custom' === $s['link_to'] ? $this->link_attrs( $s['link'] ) : '' ) : ' role="img"';
		echo '<' . $tag . ' class="sg-logo"' . $attr . ' aria-label="' . esc_attr( $label ) . '">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		$mode = $s['mode'];
		if ( 'image' === $mode ) {
			echo '<img class="sg-logo-mark sg-logo-img" src="' . esc_url( $url ) . '" alt="" style="aspect-ratio:' . esc_attr( $ratio ) . '" decoding="async">';
		} else {
			echo '<span class="sg-logo-mark sg-lm-' . esc_attr( $mode ) . '" style="--mark:url(&quot;' . esc_url( $url ) . '&quot;);aspect-ratio:' . esc_attr( $ratio ) . '" aria-hidden="true"></span>';
		}
		if ( 'yes' === $s['show_sig'] ) {
			$sig    = ! empty( $s['sig_image']['url'] ) ? $this->media( $s['sig_image'] ) : array( 'id' => 0, 'url' => sgc_asset( 'img/signature.webp' ) );
			$sratio = $this->ratio_of( $sig['id'], 1400 / 387 );
			if ( 'image' === $s['sig_mode'] ) {
				echo '<img class="sg-logo-sig sg-logo-img" src="' . esc_url( $sig['url'] ) . '" alt="" style="aspect-ratio:' . esc_attr( $sratio ) . '" decoding="async">';
			} else {
				echo '<span class="sg-logo-sig sg-lm-' . esc_attr( $s['sig_mode'] ) . '" style="--mark:url(&quot;' . esc_url( $sig['url'] ) . '&quot;);aspect-ratio:' . esc_attr( $sratio ) . '" aria-hidden="true"></span>';
			}
		}
		echo '</' . $tag . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}

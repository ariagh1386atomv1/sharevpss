<?php
/**
 * Sogand Signature & Orbit — the footer block: a slowly rotating mark above the
 * gold-and-silver signature.
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor\Widgets;

use Elementor\Controls_Manager;
use Sogand\Core\Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Signature extends Widget_Base {

	public function get_name() {
		return 'sogand-signature';
	}

	public function get_title() {
		return esc_html__( 'Signature & Orbit', 'sogand-core' );
	}

	public function get_icon() {
		return 'eicon-signature';
	}

	public function get_keywords() {
		return array( 'sogand', 'signature', 'logo', 'orbit', 'footer' );
	}

	protected function register_controls() {
		$this->start_controls_section( 'content', array( 'label' => esc_html__( 'Signature & mark', 'sogand-core' ) ) );
		$this->add_control( 'show_mark', array( 'label' => esc_html__( 'Show the mark', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'default' => 'yes', 'return_value' => 'yes' ) );
		$this->add_control( 'mark', array( 'label' => esc_html__( 'Mark image', 'sogand-core' ), 'type' => Controls_Manager::MEDIA, 'condition' => array( 'show_mark' => 'yes' ), 'description' => esc_html__( 'Empty = the bundled Sogand mark.', 'sogand-core' ) ) );
		$this->add_control( 'orbit', array(
			'label'     => esc_html__( 'Orbit decoration', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => '',
			'options'   => array(
				''        => esc_html__( 'None', 'sogand-core' ),
				'ring'    => esc_html__( 'Fine ring', 'sogand-core' ),
				'diamond' => esc_html__( 'Ring with orbiting diamond', 'sogand-core' ),
			),
			'condition' => array( 'show_mark' => 'yes' ),
		) );
		$this->add_control( 'show_sig', array( 'label' => esc_html__( 'Show the signature', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'default' => 'yes', 'return_value' => 'yes', 'separator' => 'before' ) );
		$this->add_control( 'sig', array( 'label' => esc_html__( 'Signature image', 'sogand-core' ), 'type' => Controls_Manager::MEDIA, 'condition' => array( 'show_sig' => 'yes' ), 'description' => esc_html__( 'Empty = the bundled signature.', 'sogand-core' ) ) );
		$this->add_control( 'sig_mode', array(
			'label'     => esc_html__( 'Signature look', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'metal',
			'options'   => array(
				'metal' => esc_html__( 'Gold & silver, shimmering', 'sogand-core' ),
				'color' => esc_html__( 'One colour', 'sogand-core' ),
				'image' => esc_html__( 'As uploaded', 'sogand-core' ),
			),
			'condition' => array( 'show_sig' => 'yes' ),
		) );
		$this->add_control( 'label', array( 'label' => esc_html__( 'Accessible name', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Sogand Andalibazar — Jewelry Designer' ) );
		$this->add_control( 'link', array( 'label' => esc_html__( 'Link (optional)', 'sogand-core' ), 'type' => Controls_Manager::URL ) );
		$this->end_controls_section();

		$this->start_controls_section( 'style', array( 'label' => esc_html__( 'Size, spacing & motion', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_responsive_control( 'mark_w', array( 'label' => esc_html__( 'Mark size', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'size_units' => array( 'px', 'vw' ), 'range' => array( 'px' => array( 'min' => 20, 'max' => 400 ) ), 'default' => array( 'size' => 90, 'unit' => 'px' ), 'selectors' => array( '{{WRAPPER}}' => '--sg-orb-w: {{SIZE}}{{UNIT}};' ) ) );
		$this->add_responsive_control( 'sig_w', array( 'label' => esc_html__( 'Signature width', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'size_units' => array( 'px', 'vw', '%' ), 'range' => array( 'px' => array( 'min' => 60, 'max' => 900 ) ), 'default' => array( 'size' => 360, 'unit' => 'px' ), 'selectors' => array( '{{WRAPPER}}' => '--sg-orb-sig: {{SIZE}}{{UNIT}};' ) ) );
		$this->add_responsive_control( 'gap', array( 'label' => esc_html__( 'Space between', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 120 ) ), 'default' => array( 'size' => 22, 'unit' => 'px' ), 'selectors' => array( '{{WRAPPER}} .sg-orb' => 'gap: {{SIZE}}px;' ) ) );
		$this->add_responsive_control( 'layout', array(
			'label'     => esc_html__( 'Arrangement', 'sogand-core' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => array(
				'column' => array( 'title' => esc_html__( 'Stacked', 'sogand-core' ), 'icon' => 'eicon-v-align-top' ),
				'row'    => array( 'title' => esc_html__( 'Side by side', 'sogand-core' ), 'icon' => 'eicon-h-align-left' ),
			),
			'selectors' => array( '{{WRAPPER}} .sg-orb' => 'flex-direction: {{VALUE}};' ),
		) );
		$this->add_responsive_control( 'align', array(
			'label'     => esc_html__( 'Alignment', 'sogand-core' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => array(
				'flex-start' => array( 'title' => esc_html__( 'Start', 'sogand-core' ), 'icon' => 'eicon-text-align-left' ),
				'center'     => array( 'title' => esc_html__( 'Center', 'sogand-core' ), 'icon' => 'eicon-text-align-center' ),
				'flex-end'   => array( 'title' => esc_html__( 'End', 'sogand-core' ), 'icon' => 'eicon-text-align-right' ),
			),
			'default'   => 'center',
			'selectors' => array( '{{WRAPPER}} .sg-orb' => 'align-items: {{VALUE}};' ),
		) );
		$this->add_control( 'spin', array( 'label' => esc_html__( 'Mark rotation', 'sogand-core' ), 'type' => Controls_Manager::SELECT, 'default' => 'cw', 'separator' => 'before', 'options' => array( 'cw' => esc_html__( 'Clockwise', 'sogand-core' ), 'ccw' => esc_html__( 'Counter-clockwise', 'sogand-core' ), 'none' => esc_html__( 'Still', 'sogand-core' ) ), 'prefix_class' => 'sg-orb-spin-' ) );
		$this->add_control( 'spin_dur', array( 'label' => esc_html__( 'One turn takes (s)', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 4, 'max' => 240 ) ), 'default' => array( 'size' => 60 ), 'condition' => array( 'spin!' => 'none' ), 'selectors' => array( '{{WRAPPER}}' => '--sg-orb-dur: {{SIZE}}s;' ) ) );
		$this->add_control( 'mark_op', array( 'label' => esc_html__( 'Mark opacity', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0.1, 'max' => 1, 'step' => 0.05 ) ), 'selectors' => array( '{{WRAPPER}} .sg-orb-mark' => 'opacity: {{SIZE}};' ) ) );
		$this->add_control( 'ring_c', array( 'label' => esc_html__( 'Ring colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'condition' => array( 'orbit!' => '' ), 'selectors' => array( '{{WRAPPER}}' => '--sg-orb-ring: {{VALUE}};' ) ) );
		$this->add_control( 'sig_color', array( 'label' => esc_html__( 'Signature colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'default' => '#e3c88f', 'condition' => array( 'sig_mode' => 'color' ), 'selectors' => array( '{{WRAPPER}} .sg-orb-sig' => 'background: {{VALUE}};' ) ) );
		$this->add_control( 'sig_speed', array( 'label' => esc_html__( 'Shimmer duration (s)', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 2, 'max' => 40 ) ), 'condition' => array( 'sig_mode' => 'metal' ), 'selectors' => array( '{{WRAPPER}}' => '--sg-orb-shim: {{SIZE}}s;' ) ) );
		$this->add_control( 'sig_op', array( 'label' => esc_html__( 'Signature opacity', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0.1, 'max' => 1, 'step' => 0.05 ) ), 'selectors' => array( '{{WRAPPER}} .sg-orb-sig' => 'opacity: {{SIZE}};' ) ) );
		$this->end_controls_section();
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$tag   = ! empty( $s['link']['url'] ) ? 'a' : 'div';
		$label = $s['label'] ? $s['label'] : get_bloginfo( 'name' );
		echo '<' . $tag . ' class="sg-orb"' . ( 'a' === $tag ? $this->link_attrs( $s['link'] ) . ' aria-label="' . esc_attr( $label ) . '"' : ' role="img" aria-label="' . esc_attr( $label ) . '"' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( 'yes' === $s['show_mark'] ) {
			$m = $this->media( $s['mark'], 'img/mark-gold.webp' );
			echo '<span class="sg-orb-markwrap' . ( $s['orbit'] ? ' sg-orb-o-' . esc_attr( $s['orbit'] ) : '' ) . '" aria-hidden="true">';
			if ( $s['orbit'] ) {
				echo '<i class="sg-orb-ring"></i>';
			}
			echo '<img class="sg-orb-mark" src="' . esc_url( $m['url'] ) . '" alt="" loading="lazy" decoding="async"></span>';
		}
		if ( 'yes' === $s['show_sig'] ) {
			$g = $this->media( $s['sig'], 'img/signature.webp' );
			if ( 'image' === $s['sig_mode'] ) {
				echo '<img class="sg-orb-sig sg-orb-sig-img" src="' . esc_url( $g['url'] ) . '" alt="" loading="lazy" decoding="async">';
			} else {
				echo '<span class="sg-orb-sig sg-orb-sig-' . esc_attr( $s['sig_mode'] ) . '" style="--mark:url(&quot;' . esc_url( $g['url'] ) . '&quot;)" aria-hidden="true"></span>';
			}
		}
		echo '</' . $tag . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}

<?php
/**
 * Sogand Ornament — decorative motion layers used by the hero, About and Services
 * designs (rings, orbit text, constellation, neon frame, curtains, aurora, sand…).
 * Drop it into any container; as a layer it fills that container behind or in front
 * of the other elements, or it can sit in the normal flow.
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor\Widgets;

use Elementor\Controls_Manager;
use Sogand\Core\Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ornament extends Widget_Base {

	public function get_name() {
		return 'sogand-ornament';
	}

	public function get_title() {
		return esc_html__( 'Ornament Layer', 'sogand-core' );
	}

	public function get_icon() {
		return 'eicon-gallery-justified';
	}

	public function get_keywords() {
		return array( 'sogand', 'decor', 'ornament', 'ring', 'orbit', 'sparkle', 'frame', 'curtain', 'aurora', 'particles', 'watermark' );
	}

	public function get_style_depends(): array {
		return array( 'sgc-base', 'sgc-ornament' );
	}

	public function get_script_depends(): array {
		return array( 'sgc-core', 'sgc-motion' );
	}

	public static function types() {
		return array(
			'ring'          => esc_html__( 'Ring with orbiting diamond', 'sogand-core' ),
			'ring-text'     => esc_html__( 'Rotating ring of text', 'sogand-core' ),
			'portal'        => esc_html__( 'Portal — three turning rings', 'sogand-core' ),
			'vault'         => esc_html__( 'Vault — turning octagon of gold', 'sogand-core' ),
			'halo'          => esc_html__( 'Soft halo light', 'sogand-core' ),
			'orbs'          => esc_html__( 'Coloured light orbs', 'sogand-core' ),
			'aurora'        => esc_html__( 'Aurora bands', 'sogand-core' ),
			'prism'         => esc_html__( 'Prism beams', 'sogand-core' ),
			'velvet'        => esc_html__( 'Velvet folds & light cone', 'sogand-core' ),
			'stage-light'   => esc_html__( 'Stage light from above', 'sogand-core' ),
			'dust'          => esc_html__( 'Rising gold dust', 'sogand-core' ),
			'sand'          => esc_html__( 'Falling gold sand', 'sogand-core' ),
			'sparks'        => esc_html__( 'Twinkling stars', 'sogand-core' ),
			'constellation' => esc_html__( 'Constellation lines', 'sogand-core' ),
			'line-frame'    => esc_html__( 'Self-drawing double frame', 'sogand-core' ),
			'corner-frame'  => esc_html__( 'Opening gold frame with gem', 'sogand-core' ),
			'neon-frame'    => esc_html__( 'Neon frame', 'sogand-core' ),
			'gallery-wire'  => esc_html__( 'Picture wire & nail', 'sogand-core' ),
			'monogram'      => esc_html__( 'Self-drawing monogram letter', 'sogand-core' ),
			'outline-text'  => esc_html__( 'Giant outline text (sliding)', 'sogand-core' ),
			'ribbon'        => esc_html__( 'Gold ribbon band with moving text', 'sogand-core' ),
			'blinds'        => esc_html__( 'Blinds that open (reveal)', 'sogand-core' ),
			'curtains'      => esc_html__( 'Stage curtains that part (reveal)', 'sogand-core' ),
			'shine'         => esc_html__( 'Diagonal sheen sweep', 'sogand-core' ),
			'spotlight'     => esc_html__( 'Spotlight following the mouse', 'sogand-core' ),
			'watermark'     => esc_html__( 'Logo watermark', 'sogand-core' ),
			'glint'         => esc_html__( 'Travelling glint line', 'sogand-core' ),
			'scroll'        => esc_html__( 'Scroll-down hint', 'sogand-core' ),
		);
	}

	protected function register_controls() {
		$this->start_controls_section( 'content', array( 'label' => esc_html__( 'Ornament', 'sogand-core' ) ) );
		$this->add_control( 'type', array( 'label' => esc_html__( 'Ornament', 'sogand-core' ), 'type' => Controls_Manager::SELECT, 'default' => 'ring', 'options' => self::types() ) );
		$this->add_control( 'layer', array(
			'label'        => esc_html__( 'Placement', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => 'behind',
			'options'      => array(
				'behind' => esc_html__( 'Layer behind the container’s content', 'sogand-core' ),
				'front'  => esc_html__( 'Layer in front of the content', 'sogand-core' ),
				'inline' => esc_html__( 'In the normal flow (own height)', 'sogand-core' ),
			),
			'prefix_class' => 'sg-orn-',
			'description'  => esc_html__( 'Layers fill the parent container and never block clicks.', 'sogand-core' ),
		) );
		$this->add_control( 'text', array(
			'label'     => esc_html__( 'Text', 'sogand-core' ),
			'type'      => Controls_Manager::TEXT,
			'default'   => 'Sogand Andalibazar · Jewelry Designer · ',
			'condition' => array( 'type' => array( 'ring-text', 'outline-text', 'ribbon' ) ),
		) );
		$this->add_control( 'letter', array(
			'label'     => esc_html__( 'Letter', 'sogand-core' ),
			'type'      => Controls_Manager::TEXT,
			'default'   => 'S',
			'condition' => array( 'type' => 'monogram' ),
		) );
		$this->add_control( 'image', array(
			'label'     => esc_html__( 'Watermark image', 'sogand-core' ),
			'type'      => Controls_Manager::MEDIA,
			'condition' => array( 'type' => 'watermark' ),
		) );
		$this->add_control( 'count', array(
			'label'     => esc_html__( 'Number of particles', 'sogand-core' ),
			'type'      => Controls_Manager::NUMBER,
			'min'       => 3,
			'max'       => 60,
			'default'   => 18,
			'condition' => array( 'type' => array( 'dust', 'sand', 'sparks' ) ),
		) );
		$this->add_control( 'scroll_label', array(
			'label'     => esc_html__( 'Accessible name', 'sogand-core' ),
			'type'      => Controls_Manager::TEXT,
			'default'   => 'Scroll down',
			'condition' => array( 'type' => 'scroll' ),
		) );
		$this->end_controls_section();

		$this->start_controls_section( 'style', array( 'label' => esc_html__( 'Look & motion', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_responsive_control( 'inline_h', array(
			'label'      => esc_html__( 'Height', 'sogand-core' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => array( 'px', 'vh', '%' ),
			'range'      => array( 'px' => array( 'min' => 1, 'max' => 900 ) ),
			'default'    => array( 'size' => 260, 'unit' => 'px' ),
			'condition'  => array( 'layer' => 'inline' ),
			'selectors'  => array( '{{WRAPPER}} .sg-ornament' => 'height: {{SIZE}}{{UNIT}};' ),
		) );
		$this->add_responsive_control( 'size', array(
			'label'      => esc_html__( 'Size', 'sogand-core' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => array( '%', 'px', 'vw' ),
			'range'      => array( '%' => array( 'min' => 10, 'max' => 200 ), 'px' => array( 'min' => 40, 'max' => 1600 ) ),
			'description' => esc_html__( 'Size of the ornament inside its layer (rings, frames, letters, light).', 'sogand-core' ),
			'selectors'  => array( '{{WRAPPER}}' => '--sg-orn-size: {{SIZE}}{{UNIT}};' ),
		) );
		$this->add_responsive_control( 'x', array(
			'label'      => esc_html__( 'Horizontal position', 'sogand-core' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => array( '%' ),
			'range'      => array( '%' => array( 'min' => 0, 'max' => 100 ) ),
			'selectors'  => array( '{{WRAPPER}}' => '--sg-orn-x: {{SIZE}}%;' ),
		) );
		$this->add_responsive_control( 'y', array(
			'label'      => esc_html__( 'Vertical position', 'sogand-core' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => array( '%' ),
			'range'      => array( '%' => array( 'min' => 0, 'max' => 100 ) ),
			'selectors'  => array( '{{WRAPPER}}' => '--sg-orn-y: {{SIZE}}%;' ),
		) );
		$this->add_control( 'c1', array( 'label' => esc_html__( 'Colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-orn-c1: {{VALUE}};' ) ) );
		$this->add_control( 'c2', array( 'label' => esc_html__( 'Colour 2', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-orn-c2: {{VALUE}};' ) ) );
		$this->add_control( 'c3', array( 'label' => esc_html__( 'Colour 3', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-orn-c3: {{VALUE}};' ) ) );
		$this->add_control( 'op', array( 'label' => esc_html__( 'Opacity', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 1, 'step' => 0.05 ) ), 'selectors' => array( '{{WRAPPER}} .sg-ornament' => 'opacity: {{SIZE}};' ) ) );
		$this->add_control( 'stroke', array( 'label' => esc_html__( 'Line width', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0.5, 'max' => 6, 'step' => 0.1 ) ), 'selectors' => array( '{{WRAPPER}}' => '--sg-orn-sw: {{SIZE}}px;' ) ) );
		$this->add_control( 'blur', array( 'label' => esc_html__( 'Blur', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 120 ) ), 'selectors' => array( '{{WRAPPER}}' => '--sg-orn-blur: {{SIZE}}px;' ) ) );
		$this->add_control( 'blend', array(
			'label'     => esc_html__( 'Blend mode', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => '',
			'options'   => array( '' => esc_html__( 'Normal', 'sogand-core' ), 'screen' => 'Screen', 'multiply' => 'Multiply', 'overlay' => 'Overlay', 'soft-light' => 'Soft light', 'lighten' => 'Lighten' ),
			'selectors' => array( '{{WRAPPER}} .sg-ornament' => 'mix-blend-mode: {{VALUE}};' ),
		) );
		$this->add_control( 'speed', array( 'label' => esc_html__( 'Speed', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 4, 'step' => 0.05 ) ), 'default' => array( 'size' => 1 ), 'separator' => 'before', 'selectors' => array( '{{WRAPPER}}' => '--sg-orn-speed: {{SIZE}};' ), 'description' => esc_html__( '0 = still.', 'sogand-core' ) ) );
		$this->add_control( 'delay', array( 'label' => esc_html__( 'Delay (s)', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 6, 'step' => 0.1 ) ), 'selectors' => array( '{{WRAPPER}}' => '--sg-orn-delay: {{SIZE}}s;' ) ) );
		$this->add_control( 'reverse', array( 'label' => esc_html__( 'Reverse direction', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'selectors' => array( '{{WRAPPER}}' => '--sg-orn-dir: reverse;' ) ) );
		$this->add_control( 'zi', array( 'label' => esc_html__( 'Layer order', 'sogand-core' ), 'type' => Controls_Manager::NUMBER, 'min' => -5, 'max' => 50, 'condition' => array( 'layer!' => 'inline' ), 'selectors' => array( '{{WRAPPER}}' => 'z-index: {{VALUE}} !important;' ) ) );
		$this->add_control( 'hide_m', array( 'label' => esc_html__( 'Hide on phones', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'prefix_class' => 'sg-orn-hm-' ) );
		$this->end_controls_section();
	}

	private function seeded( $n, $seed = 7 ) {
		$out = array();
		for ( $i = 0; $i < $n; $i++ ) {
			$seed  = ( $seed * 9301 + 49297 ) % 233280;
			$a     = $seed / 233280;
			$seed  = ( $seed * 9301 + 49297 ) % 233280;
			$b     = $seed / 233280;
			$seed  = ( $seed * 9301 + 49297 ) % 233280;
			$c     = $seed / 233280;
			$out[] = array( $a, $b, $c );
		}
		return $out;
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$type = array_key_exists( $s['type'], self::types() ) ? $s['type'] : 'ring';
		$uid  = 'sgo' . $this->get_id();
		$html = '';
		switch ( $type ) {
			case 'ring':
				$html = '<span class="o-ring"><i></i></span>';
				break;
			case 'ring-text':
				$t    = $s['text'] ? $s['text'] : get_bloginfo( 'name' ) . ' · ';
				$html = '<svg class="o-ringtext" viewBox="0 0 400 400" aria-hidden="true" focusable="false"><defs><path id="' . esc_attr( $uid ) . 'p" d="M200,200 m-170,0 a170,170 0 1,1 340,0 a170,170 0 1,1 -340,0"/></defs><text><textPath href="#' . esc_attr( $uid ) . 'p">' . esc_html( str_repeat( $t, max( 1, (int) ceil( 60 / max( 1, mb_strlen( $t ) ) ) ) ) ) . '</textPath></text></svg>';
				break;
			case 'portal':
				$html = '<span class="o-portal"><i class="r1"></i><i class="r2"></i><i class="r3"></i></span>';
				break;
			case 'vault':
				$html = '<span class="o-vault"><i></i></span>';
				break;
			case 'halo':
				$html = '<span class="o-halo"></span>';
				break;
			case 'orbs':
				$html = '<span class="o-orbs"><i></i><i></i><i></i></span>';
				break;
			case 'aurora':
				$html = '<span class="o-aurora"><i></i><i></i><i></i></span>';
				break;
			case 'prism':
				$html = '<span class="o-prism"><i></i><i class="b2"></i></span>';
				break;
			case 'velvet':
				$html = '<span class="o-velvet"><i class="folds"></i><i class="cone"></i></span>';
				break;
			case 'stage-light':
				$html = '<span class="o-stagelight"></span>';
				break;
			case 'dust':
			case 'sand':
			case 'sparks':
				$n    = max( 3, min( 60, (int) $s['count'] ) );
				$html = '<span class="o-' . esc_attr( $type ) . '">';
				foreach ( $this->seeded( $n, 'sand' === $type ? 11 : ( 'sparks' === $type ? 7 : 3 ) ) as $k => $r ) {
					$html .= sprintf( '<i style="--k:%d;--x:%.1f%%;--y:%.1f%%;--r:%.2f"></i>', $k, 4 + $r[0] * 92, 6 + $r[1] * 84, $r[2] );
				}
				$html .= '</span>';
				break;
			case 'constellation':
				$pts  = array( array( 60, 80 ), array( 140, 40 ), array( 230, 70 ), array( 330, 50 ), array( 360, 150 ), array( 300, 250 ), array( 350, 340 ), array( 220, 360 ), array( 110, 330 ), array( 40, 240 ), array( 90, 160 ) );
				$html = '<svg class="o-cons" viewBox="0 0 400 400" aria-hidden="true" focusable="false">';
				foreach ( $pts as $k => $p ) {
					$q     = $pts[ ( $k + 1 ) % count( $pts ) ];
					$html .= sprintf( '<line x1="%d" y1="%d" x2="%d" y2="%d" pathLength="1" style="--k:%d"/>', $p[0], $p[1], $q[0], $q[1], $k );
				}
				foreach ( $pts as $k => $p ) {
					$html .= sprintf( '<circle cx="%d" cy="%d" r="%s" style="--k:%d"/>', $p[0], $p[1], $k % 3 ? '2.2' : '3.4', $k );
				}
				$html .= '</svg>';
				break;
			case 'line-frame':
				$html = '<svg class="o-lines" viewBox="0 0 400 500" preserveAspectRatio="none" aria-hidden="true" focusable="false"><rect x="10" y="10" width="380" height="480" pathLength="1"/><rect x="34" y="34" width="332" height="432" pathLength="1"/></svg>';
				break;
			case 'corner-frame':
				$html = '<span class="o-frame"><i class="a"></i><i class="b"></i><i class="gem"></i></span>';
				break;
			case 'neon-frame':
				$html = '<svg class="o-neon" viewBox="0 0 400 500" preserveAspectRatio="none" aria-hidden="true" focusable="false"><rect class="n0" x="6" y="6" width="388" height="488" rx="44" pathLength="1"/><rect class="n1" x="6" y="6" width="388" height="488" rx="44" pathLength="1"/></svg>';
				break;
			case 'gallery-wire':
				$html = '<svg class="o-wire" viewBox="0 0 200 60" aria-hidden="true" focusable="false"><path d="M100 4 L20 58 M100 4 L180 58"/><circle cx="100" cy="4" r="3.5"/></svg>';
				break;
			case 'monogram':
				$l    = $s['letter'] ? mb_substr( $s['letter'], 0, 2 ) : 'S';
				$html = '<svg class="o-mono" viewBox="0 0 400 400" aria-hidden="true" focusable="false"><text x="200" y="215" text-anchor="middle" dominant-baseline="middle">' . esc_html( $l ) . '</text></svg>';
				break;
			case 'outline-text':
				$t    = $s['text'] ? $s['text'] : 'Jewelry';
				$html = '<span class="o-outline"><span class="o-outline-track"><span>' . esc_html( $t ) . '</span><span>' . esc_html( $t ) . '</span></span></span>';
				break;
			case 'ribbon':
				$t    = $s['text'] ? $s['text'] : 'Design & Ideation  ✦  Bespoke Jewelry  ✦  Digital Rendering  ✦  3D Modeling  ✦  ';
				$html = '<span class="o-ribbon"><span class="o-ribbon-track"><span>' . esc_html( $t ) . '</span><span>' . esc_html( $t ) . '</span></span></span>';
				break;
			case 'blinds':
				$html = '<span class="o-blinds">';
				for ( $k = 0; $k < 6; $k++ ) {
					$html .= '<i style="--k:' . $k . '"></i>';
				}
				$html .= '<b></b></span>';
				break;
			case 'curtains':
				$html = '<span class="o-curtains"><i class="light"></i><i class="cl"></i><i class="cr"></i><i class="valance"></i></span>';
				break;
			case 'shine':
				$html = '<span class="o-shine"></span>';
				break;
			case 'spotlight':
				$html = '<span class="o-spot"></span>';
				break;
			case 'watermark':
				$m    = $this->media( $s['image'], 'img/mark-dark.webp' );
				$html = '<span class="o-wm"><img src="' . esc_url( $m['url'] ) . '" alt="" loading="lazy" decoding="async"></span>';
				break;
			case 'glint':
				$html = '<span class="o-glint"></span>';
				break;
			case 'scroll':
				$label = $s['scroll_label'] ? $s['scroll_label'] : __( 'Scroll down', 'sogand-site' );
				echo '<div class="sg-ornament o-t-scroll"><button type="button" class="o-scroll" data-sg-scroll aria-label="' . esc_attr( $label ) . '"><i></i></button></div>';
				return;
		}
		echo '<div class="sg-ornament o-t-' . esc_attr( $type ) . '" aria-hidden="true">' . $html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}

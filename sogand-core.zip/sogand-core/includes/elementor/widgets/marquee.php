<?php
/**
 * Sogand Marquee — a seamless moving strip of words, icons or images (one or two rows).
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use Sogand\Core\Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Marquee extends Widget_Base {

	public function get_name() {
		return 'sogand-marquee';
	}

	public function get_title() {
		return esc_html__( 'Marquee', 'sogand-core' );
	}

	public function get_icon() {
		return 'eicon-slider-push';
	}

	public function get_keywords() {
		return array( 'sogand', 'marquee', 'ticker', 'scroll', 'strip', 'moving text' );
	}

	public function get_style_depends(): array {
		return array( 'sgc-base', 'sgc-marquee' );
	}

	public function get_script_depends(): array {
		return array( 'sgc-core', 'sgc-marquee' );
	}

	private function items_repeater() {
		$r = new Repeater();
		$r->add_control( 'kind', array(
			'label'   => esc_html__( 'Type', 'sogand-core' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'text',
			'options' => array(
				'text'  => esc_html__( 'Text', 'sogand-core' ),
				'image' => esc_html__( 'Image', 'sogand-core' ),
				'icon'  => esc_html__( 'Icon', 'sogand-core' ),
			),
		) );
		$r->add_control( 'text', array( 'label' => esc_html__( 'Text', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Design & Ideation', 'label_block' => true, 'condition' => array( 'kind' => 'text' ) ) );
		$r->add_control( 'image', array( 'label' => esc_html__( 'Image', 'sogand-core' ), 'type' => Controls_Manager::MEDIA, 'condition' => array( 'kind' => 'image' ) ) );
		$r->add_control( 'icon', array( 'label' => esc_html__( 'Icon', 'sogand-core' ), 'type' => Controls_Manager::ICONS, 'condition' => array( 'kind' => 'icon' ) ) );
		$r->add_control( 'link', array( 'label' => esc_html__( 'Link', 'sogand-core' ), 'type' => Controls_Manager::URL ) );
		return $r->get_controls();
	}

	protected function register_controls() {
		$defaults = array(
			array( 'kind' => 'text', 'text' => 'Design & Ideation' ),
			array( 'kind' => 'text', 'text' => 'Bespoke Jewelry' ),
			array( 'kind' => 'text', 'text' => 'Digital Rendering' ),
			array( 'kind' => 'text', 'text' => '3D Modeling' ),
		);
		$this->start_controls_section( 'content', array( 'label' => esc_html__( 'Items', 'sogand-core' ) ) );
		$this->add_control( 'items', array(
			'label'       => esc_html__( 'Row 1', 'sogand-core' ),
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $this->items_repeater(),
			'default'     => $defaults,
			'title_field' => '{{{ kind === "text" ? text : kind }}}',
		) );
		$this->add_control( 'sep', array(
			'label'   => esc_html__( 'Separator', 'sogand-core' ),
			'type'    => Controls_Manager::TEXT,
			'default' => '✦',
		) );
		$this->add_control( 'row2', array(
			'label'        => esc_html__( 'Second row moving the other way', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'return_value' => 'yes',
			'separator'    => 'before',
		) );
		$this->add_control( 'row2_same', array(
			'label'        => esc_html__( 'Second row uses the same items', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'return_value' => 'yes',
			'default'      => 'yes',
			'condition'    => array( 'row2' => 'yes' ),
		) );
		$this->add_control( 'items2', array(
			'label'       => esc_html__( 'Row 2', 'sogand-core' ),
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $this->items_repeater(),
			'default'     => $defaults,
			'title_field' => '{{{ kind === "text" ? text : kind }}}',
			'condition'   => array( 'row2' => 'yes', 'row2_same!' => 'yes' ),
		) );
		$this->add_control( 'pause_btn', array(
			'label'        => esc_html__( 'Show a pause button', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'return_value' => 'yes',
			'separator'    => 'before',
			'description'  => esc_html__( 'Lets visitors stop the movement (recommended for accessibility). Hovering or focusing the strip always pauses it.', 'sogand-core' ),
		) );
		$this->add_control( 'label', array( 'label' => esc_html__( 'Name for screen readers', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Services' ) );
		$this->end_controls_section();

		$this->start_controls_section( 'motion', array( 'label' => esc_html__( 'Movement', 'sogand-core' ) ) );
		$this->add_control( 'speed', array(
			'label'     => esc_html__( 'Speed (pixels per second)', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 5, 'max' => 400 ) ),
			'default'   => array( 'size' => 40 ),
			'frontend_available' => true,
		) );
		$this->add_control( 'dir', array(
			'label'   => esc_html__( 'Direction', 'sogand-core' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'left',
			'options' => array( 'left' => esc_html__( 'Right to left', 'sogand-core' ), 'right' => esc_html__( 'Left to right', 'sogand-core' ) ),
			'frontend_available' => true,
		) );
		$this->add_control( 'pause_hover', array( 'label' => esc_html__( 'Pause on hover', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'prefix_class' => 'sg-mq-ph-' ) );
		$this->end_controls_section();

		$this->start_controls_section( 's_items', array( 'label' => esc_html__( 'Items', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'typo', 'selector' => '{{WRAPPER}} .sg-mq-item' ) );
		$this->add_control( 'color', array( 'label' => esc_html__( 'Colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-mq-c: {{VALUE}};' ) ) );
		$this->add_control( 'color_h', array( 'label' => esc_html__( 'Link hover colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} a.sg-mq-item:hover' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'outline', array( 'label' => esc_html__( 'Outlined letters', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'prefix_class' => 'sg-mq-outline-' ) );
		$this->add_responsive_control( 'gap', array( 'label' => esc_html__( 'Space between items', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'size_units' => array( 'px', 'em' ), 'range' => array( 'px' => array( 'min' => 0, 'max' => 120 ) ), 'selectors' => array( '{{WRAPPER}}' => '--sg-mq-gap: {{SIZE}}{{UNIT}};' ) ) );
		$this->add_responsive_control( 'row_h', array( 'label' => esc_html__( 'Row height', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 20, 'max' => 300 ) ), 'selectors' => array( '{{WRAPPER}} .sg-mq-row' => 'min-height: {{SIZE}}px;' ) ) );
		$this->add_responsive_control( 'img_h', array( 'label' => esc_html__( 'Image height', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 16, 'max' => 300 ) ), 'selectors' => array( '{{WRAPPER}}' => '--sg-mq-img: {{SIZE}}px;' ) ) );
		$this->add_control( 'sep_c', array( 'label' => esc_html__( 'Separator colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-mq-sep: {{VALUE}};' ) ) );
		$this->add_control( 'sep_s', array( 'label' => esc_html__( 'Separator size (em)', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0.2, 'max' => 2, 'step' => 0.05 ) ), 'selectors' => array( '{{WRAPPER}}' => '--sg-mq-sep-s: {{SIZE}}em;' ) ) );
		$this->add_control( 'fade', array( 'label' => esc_html__( 'Edge fade (%)', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 40 ) ), 'default' => array( 'size' => 12 ), 'selectors' => array( '{{WRAPPER}}' => '--sg-mq-fade: {{SIZE}}%;' ) ) );
		$this->add_responsive_control( 'row_gap', array( 'label' => esc_html__( 'Space between rows', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 80 ) ), 'condition' => array( 'row2' => 'yes' ), 'selectors' => array( '{{WRAPPER}} .sg-mq' => 'gap: {{SIZE}}px;' ) ) );
		$this->end_controls_section();
	}

	private function row( $items, $sep ) {
		$out = '<div class="sg-mq-group">';
		foreach ( (array) $items as $it ) {
			$tag   = ! empty( $it['link']['url'] ) ? 'a' : 'span';
			$attr  = 'a' === $tag ? $this->link_attrs( $it['link'] ) : '';
			$inner = '';
			if ( 'image' === $it['kind'] && ! empty( $it['image']['url'] ) ) {
				$m     = $this->media( $it['image'] );
				$inner = '<img src="' . esc_url( $m['url'] ) . '" alt="' . esc_attr( $m['alt'] ) . '" loading="lazy" decoding="async">';
			} elseif ( 'icon' === $it['kind'] && ! empty( $it['icon']['value'] ) ) {
				ob_start();
				Icons_Manager::render_icon( $it['icon'], array( 'aria-hidden' => 'true' ) );
				$inner = ob_get_clean();
			} else {
				$inner = esc_html( isset( $it['text'] ) ? $it['text'] : '' );
			}
			$out .= '<' . $tag . ' class="sg-mq-item"' . $attr . '>' . $inner . '</' . $tag . '>';
			if ( '' !== (string) $sep ) {
				$out .= '<span class="sg-mq-sep" aria-hidden="true">' . esc_html( $sep ) . '</span>';
			}
		}
		return $out . '</div>';
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$items = ! empty( $s['items'] ) ? $s['items'] : array();
		if ( ! $items ) {
			return;
		}
		$label = $s['label'] ? $s['label'] : __( 'Moving strip', 'sogand-site' );
		echo '<div class="sg-mq" role="region" aria-label="' . esc_attr( $label ) . '">';
		echo '<div class="sg-mq-row" data-dir="' . esc_attr( $s['dir'] ) . '"><div class="sg-mq-track">' . $this->row( $items, $s['sep'] ) . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( 'yes' === $s['row2'] ) {
			$items2 = 'yes' === $s['row2_same'] || empty( $s['items2'] ) ? $items : $s['items2'];
			echo '<div class="sg-mq-row" data-dir="' . esc_attr( 'left' === $s['dir'] ? 'right' : 'left' ) . '"><div class="sg-mq-track">' . $this->row( $items2, $s['sep'] ) . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		if ( 'yes' === $s['pause_btn'] ) {
			echo '<button type="button" class="sg-mq-pause" aria-pressed="false"><span class="elementor-screen-only">' . esc_html__( 'Pause the moving strip', 'sogand-site' ) . '</span><i></i></button>';
		}
		echo '</div>';
	}
}

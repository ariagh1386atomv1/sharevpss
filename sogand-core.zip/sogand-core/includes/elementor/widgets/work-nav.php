<?php
/**
 * Sogand Work Navigation — previous / all works / next, following the portfolio order
 * (display order, then newest first). Wraps around at both ends.
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Sogand\Core\Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Work_Nav extends Widget_Base {

	public function get_name() {
		return 'sogand-work-nav';
	}

	public function get_title() {
		return esc_html__( 'Work Navigation', 'sogand-core' );
	}

	public function get_icon() {
		return 'eicon-post-navigation';
	}

	public function get_keywords() {
		return array( 'sogand', 'work', 'previous', 'next', 'navigation', 'portfolio' );
	}

	public function get_style_depends(): array {
		return array( 'sgc-base', 'sgc-collection' );
	}

	protected function register_controls() {
		$this->start_controls_section( 'content', array( 'label' => esc_html__( 'Navigation', 'sogand-core' ) ) );
		$this->add_control( 'scope', array(
			'label'   => esc_html__( 'Move between', 'sogand-core' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'all',
			'options' => array(
				'all' => esc_html__( 'All works', 'sogand-core' ),
				'cat' => esc_html__( 'Works of the same collection', 'sogand-core' ),
			),
		) );
		$this->add_control( 'prev_label', array( 'label' => esc_html__( 'Previous label', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Previous' ) );
		$this->add_control( 'next_label', array( 'label' => esc_html__( 'Next label', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Next' ) );
		$this->add_control( 'show_all', array( 'label' => esc_html__( 'Show “All works” link', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes' ) );
		$this->add_control( 'all_label', array( 'label' => esc_html__( 'All works label', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'All works', 'condition' => array( 'show_all' => 'yes' ) ) );
		$this->add_control( 'all_link', array( 'label' => esc_html__( 'All works link', 'sogand-core' ), 'type' => Controls_Manager::URL, 'description' => esc_html__( 'Empty = the Collections page.', 'sogand-core' ), 'condition' => array( 'show_all' => 'yes' ) ) );
		$this->add_control( 'thumbs', array( 'label' => esc_html__( 'Show small pictures', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => '' ) );
		$this->end_controls_section();

		$this->start_controls_section( 'style', array( 'label' => esc_html__( 'Navigation', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'tt', 'label' => esc_html__( 'Work titles', 'sogand-core' ), 'selector' => '{{WRAPPER}} .sg-pn-t' ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'st', 'label' => esc_html__( 'Small labels', 'sogand-core' ), 'selector' => '{{WRAPPER}} .sg-pn small' ) );
		$this->add_control( 'c', array( 'label' => esc_html__( 'Colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-pn-row a' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'ch', array( 'label' => esc_html__( 'Hover colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-pn-row a:hover' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'line', array( 'label' => esc_html__( 'Line colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-pn-row' => 'border-color: {{VALUE}};' ) ) );
		$this->add_responsive_control( 'pad', array(
			'label'      => esc_html__( 'Padding', 'sogand-core' ),
			'type'       => Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'rem' ),
			'selectors'  => array( '{{WRAPPER}} .sg-pn-row' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );
		$this->end_controls_section();
	}

	/** Ordered ids of the works to move between. */
	private function sequence( $id, $scope ) {
		$extra = array( 'posts_per_page' => 500, 'fields' => 'ids' );
		if ( 'cat' === $scope ) {
			$terms = get_the_terms( $id, 'sg_collection' );
			if ( $terms && ! is_wp_error( $terms ) ) {
				$extra['tax_query'] = array( array( 'taxonomy' => 'sg_collection', 'field' => 'term_id', 'terms' => (int) $terms[0]->term_id ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
			}
		}
		return array_map( 'intval', get_posts( sgc_works_query_args( $extra ) ) );
	}

	private function link( $pid, $label, $dir, $thumbs ) {
		$arrow = self::icon( 'next' === $dir ? 'arrow-right' : 'arrow-left', 18 );
		$pic   = $thumbs ? get_the_post_thumbnail( $pid, 'thumbnail', array( 'alt' => '', 'class' => 'sg-pn-img', 'loading' => 'lazy' ) ) : '';
		$text  = '<span class="sg-pn-txt"><small>' . esc_html( $label ) . '</small><span class="sg-pn-t">' . esc_html( get_the_title( $pid ) ) . '</span></span>';
		$inner = 'next' === $dir ? $text . $pic . $arrow : $arrow . $pic . $text;
		return '<a class="sg-pn sg-pn-' . esc_attr( $dir ) . '" href="' . esc_url( get_permalink( $pid ) ) . '" rel="' . esc_attr( $dir ) . '">' . $inner . '</a>';
	}

	protected function render() {
		$s  = $this->get_settings_for_display();
		$id = sgc_current_work_id();
		if ( ! $id ) {
			if ( $this->in_editor() ) {
				echo '<div class="sg-empty">' . esc_html__( 'Add at least two works to preview the navigation.', 'sogand-core' ) . '</div>';
			}
			return;
		}
		$ids = $this->sequence( $id, $s['scope'] );
		$n   = count( $ids );
		$pos = array_search( (int) $id, $ids, true );
		if ( $n < 2 || false === $pos ) {
			return;
		}
		$prev   = $ids[ ( $pos - 1 + $n ) % $n ];
		$next   = $ids[ ( $pos + 1 ) % $n ];
		$thumbs = 'yes' === $s['thumbs'];
		echo '<nav class="sg-pn-row" aria-label="' . esc_attr__( 'More works', 'sogand-site' ) . '">';
		echo $this->link( $prev, $s['prev_label'], 'prev', $thumbs ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( 'yes' === $s['show_all'] ) {
			$url = ! empty( $s['all_link']['url'] ) ? $s['all_link']['url'] : sgc_collections_url();
			echo '<a class="sg-pn-all" href="' . esc_url( $url ) . '">' . esc_html( $s['all_label'] ) . '</a>';
		}
		if ( $next !== $prev || 2 < $n ) {
			echo $this->link( $next, $s['next_label'], 'next', $thumbs ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</nav>';
	}
}

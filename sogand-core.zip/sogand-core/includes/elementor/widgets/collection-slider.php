<?php
/**
 * Sogand Collection Slider — the luxury stage that presents chosen portfolio pieces,
 * each with its own coloured halo, ring, sparkles, tilt, caption and progress bars.
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Sogand\Core\Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Collection_Slider extends Widget_Base {

	public function get_name() {
		return 'sogand-collection-slider';
	}

	public function get_title() {
		return esc_html__( 'Collection Slider', 'sogand-core' );
	}

	public function get_icon() {
		return 'eicon-slides';
	}

	public function get_keywords() {
		return array( 'sogand', 'slider', 'collection', 'portfolio', 'works', 'stage', 'halo' );
	}

	public function get_style_depends(): array {
		return array( 'sgc-base', 'sgc-collection' );
	}

	public function get_script_depends(): array {
		return array( 'sgc-core', 'sgc-collection' );
	}

	public static function work_options() {
		$out = array( '' => esc_html__( '— Choose a work —', 'sogand-core' ) );
		foreach ( get_posts( sgc_works_query_args( array( 'posts_per_page' => 200, 'post_status' => array( 'publish', 'private' ) ) ) ) as $p ) {
			$out[ (string) $p->ID ] = get_the_title( $p );
		}
		return $out;
	}

	protected function register_controls() {
		$this->start_controls_section( 'content', array( 'label' => esc_html__( 'Designs', 'sogand-core' ) ) );
		$this->add_control( 'source', array(
			'label'   => esc_html__( 'Show', 'sogand-core' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'manual',
			'options' => array(
				'manual'   => esc_html__( 'The designs chosen below', 'sogand-core' ),
				'featured' => esc_html__( 'Works marked “Featured”', 'sogand-core' ),
				'latest'   => esc_html__( 'Latest works', 'sogand-core' ),
				'category' => esc_html__( 'Works of one collection', 'sogand-core' ),
			),
		) );
		$r = new Repeater();
		$r->add_control( 'work', array( 'label' => esc_html__( 'Design', 'sogand-core' ), 'type' => Controls_Manager::SELECT, 'options' => self::work_options(), 'default' => '' ) );
		$r->add_control( 'halo', array( 'label' => esc_html__( 'Halo colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'description' => esc_html__( 'Empty = the work’s own halo colour.', 'sogand-core' ) ) );
		$r->add_control( 'image', array( 'label' => esc_html__( 'Different picture (optional)', 'sogand-core' ), 'type' => Controls_Manager::MEDIA ) );
		$this->add_control( 'slides', array(
			'label'       => esc_html__( 'Slides', 'sogand-core' ),
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $r->get_controls(),
			'default'     => array(),
			'title_field' => '<# print( work ? "#" + work : "—" ) #>',
			'condition'   => array( 'source' => 'manual' ),
			'description' => esc_html__( 'Add, remove or drag designs. Empty = the first featured work.', 'sogand-core' ),
		) );
		$this->add_control( 'cat', array(
			'label'     => esc_html__( 'Collection', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'options'   => self::cat_options(),
			'condition' => array( 'source' => 'category' ),
		) );
		$this->add_control( 'count', array(
			'label'     => esc_html__( 'Number of designs', 'sogand-core' ),
			'type'      => Controls_Manager::NUMBER,
			'min'       => 1,
			'max'       => 20,
			'default'   => 5,
			'condition' => array( 'source!' => 'manual' ),
		) );
		$this->add_control( 'caption', array( 'label' => esc_html__( 'Caption (title, details, link)', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'separator' => 'before' ) );
		$this->add_control( 'view', array( 'label' => esc_html__( 'Link text', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'View piece', 'condition' => array( 'caption' => 'yes' ) ) );
		$this->add_control( 'controls', array( 'label' => esc_html__( 'Counter & progress bars', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes' ) );
		$this->end_controls_section();

		$this->start_controls_section( 'play', array( 'label' => esc_html__( 'Playback', 'sogand-core' ) ) );
		$this->add_control( 'autoplay', array( 'label' => esc_html__( 'Autoplay', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'frontend_available' => true ) );
		$this->add_control( 'interval', array( 'label' => esc_html__( 'Seconds per design', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 1.5, 'max' => 20, 'step' => 0.5 ) ), 'default' => array( 'size' => 5 ), 'condition' => array( 'autoplay' => 'yes' ), 'frontend_available' => true ) );
		$this->add_control( 'pause', array( 'label' => esc_html__( 'Pause while hovered', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'frontend_available' => true ) );
		$this->add_control( 'tilt', array( 'label' => esc_html__( '3D tilt following the mouse (degrees)', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 30 ) ), 'default' => array( 'size' => 8 ), 'frontend_available' => true ) );
		$this->end_controls_section();

		$this->start_controls_section( 'deco', array( 'label' => esc_html__( 'Stage decoration', 'sogand-core' ) ) );
		$this->add_control( 'ring', array( 'label' => esc_html__( 'Ring with orbiting diamond', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes' ) );
		$this->add_control( 'glow', array( 'label' => esc_html__( 'Coloured halo', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes' ) );
		$this->add_control( 'sparks', array( 'label' => esc_html__( 'Twinkling stars', 'sogand-core' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 40, 'default' => 0 ) );
		$this->add_control( 'float', array( 'label' => esc_html__( 'Piece floats gently', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'prefix_class' => 'sg-cs-float-' ) );
		$this->end_controls_section();

		/* ---------------- style ---------------- */
		$this->start_controls_section( 's_stage', array( 'label' => esc_html__( 'Stage', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_responsive_control( 'min_h', array( 'label' => esc_html__( 'Stage height', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'size_units' => array( 'px', 'vh' ), 'range' => array( 'px' => array( 'min' => 200, 'max' => 1000 ) ), 'default' => array( 'size' => 520, 'unit' => 'px' ), 'selectors' => array( '{{WRAPPER}} .sg-stage' => 'min-height: {{SIZE}}{{UNIT}};' ) ) );
		$this->add_responsive_control( 'img_h', array( 'label' => esc_html__( 'Picture height', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'size_units' => array( 'px', 'vh', '%' ), 'range' => array( 'px' => array( 'min' => 80, 'max' => 900 ) ), 'selectors' => array( '{{WRAPPER}}' => '--sg-cs-img: {{SIZE}}{{UNIT}};' ) ) );
		$this->add_responsive_control( 'img_w', array( 'label' => esc_html__( 'Picture max width (%)', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 20, 'max' => 100 ) ), 'selectors' => array( '{{WRAPPER}}' => '--sg-cs-imgw: {{SIZE}}%;' ) ) );
		$this->add_control( 'ring_c', array( 'label' => esc_html__( 'Ring colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'condition' => array( 'ring' => 'yes' ), 'selectors' => array( '{{WRAPPER}}' => '--sg-cs-ring: {{VALUE}};' ) ) );
		$this->add_control( 'ring_s', array( 'label' => esc_html__( 'Ring size (%)', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 30, 'max' => 100 ) ), 'condition' => array( 'ring' => 'yes' ), 'selectors' => array( '{{WRAPPER}}' => '--sg-cs-ring-s: {{SIZE}}%;' ) ) );
		$this->add_control( 'ring_d', array( 'label' => esc_html__( 'Ring turn (s)', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 4, 'max' => 120 ) ), 'condition' => array( 'ring' => 'yes' ), 'selectors' => array( '{{WRAPPER}}' => '--sg-cs-ring-d: {{SIZE}}s;' ) ) );
		$this->add_control( 'glow_op', array( 'label' => esc_html__( 'Halo strength', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 1, 'step' => 0.05 ) ), 'condition' => array( 'glow' => 'yes' ), 'selectors' => array( '{{WRAPPER}}' => '--sg-cs-glow: {{SIZE}};' ) ) );
		$this->add_control( 'shadow', array( 'label' => esc_html__( 'Piece shadow', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 1, 'step' => 0.05 ) ), 'selectors' => array( '{{WRAPPER}}' => '--sg-cs-shadow: {{SIZE}};' ) ) );
		$this->end_controls_section();

		$this->start_controls_section( 's_cap', array( 'label' => esc_html__( 'Caption & controls', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'cap_t', 'label' => esc_html__( 'Title', 'sogand-core' ), 'selector' => '{{WRAPPER}} .sg-stage-title' ) );
		$this->add_control( 'cap_c', array( 'label' => esc_html__( 'Title colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-stage-title' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'meta_c', array( 'label' => esc_html__( 'Details colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-stage-meta' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'link_c', array( 'label' => esc_html__( 'Link colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-stage-link' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'bar_c', array( 'label' => esc_html__( 'Progress colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-cs-bar: {{VALUE}};' ) ) );
		$this->end_controls_section();
	}

	public static function cat_options() {
		$out = array( '' => esc_html__( '— Choose —', 'sogand-core' ) );
		foreach ( sgc_collection_terms() as $t ) {
			$out[ (string) $t->term_id ] = $t->name;
		}
		return $out;
	}

	private function slides( $s ) {
		$list = array();
		if ( 'manual' === $s['source'] ) {
			foreach ( (array) $s['slides'] as $sl ) {
				$id = absint( $sl['work'] );
				if ( $id && 'sg_work' === get_post_type( $id ) && 'publish' === get_post_status( $id ) ) {
					$list[] = array( 'id' => $id, 'halo' => sgc_sanitize_color( $sl['halo'] ), 'img' => ! empty( $sl['image']['url'] ) ? $sl['image'] : null );
				}
			}
			if ( ! $list ) {
				$q = get_posts( sgc_works_query_args( array( 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_sg_featured', 'meta_value' => '1' ) ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
				if ( ! $q ) {
					$q = get_posts( sgc_works_query_args( array( 'posts_per_page' => 1, 'fields' => 'ids' ) ) );
				}
				foreach ( $q as $id ) {
					$list[] = array( 'id' => (int) $id, 'halo' => '', 'img' => null );
				}
			}
			return $list;
		}
		$args = array( 'posts_per_page' => max( 1, (int) $s['count'] ), 'fields' => 'ids' );
		if ( 'featured' === $s['source'] ) {
			$args['meta_key']   = '_sg_featured'; // phpcs:ignore WordPress.DB.SlowDBQuery
			$args['meta_value'] = '1'; // phpcs:ignore WordPress.DB.SlowDBQuery
		} elseif ( 'category' === $s['source'] && $s['cat'] ) {
			$args['tax_query'] = array( array( 'taxonomy' => 'sg_collection', 'field' => 'term_id', 'terms' => absint( $s['cat'] ) ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		}
		foreach ( get_posts( sgc_works_query_args( $args ) ) as $id ) {
			$list[] = array( 'id' => (int) $id, 'halo' => '', 'img' => null );
		}
		return $list;
	}

	protected function render() {
		$s      = $this->get_settings_for_display();
		$slides = $this->slides( $s );
		if ( ! $slides ) {
			if ( $this->in_editor() ) {
				echo '<div class="sg-empty">' . esc_html__( 'Add a work under Works, then choose it here.', 'sogand-core' ) . '</div>';
			}
			return;
		}
		$order = get_posts( sgc_works_query_args( array( 'posts_per_page' => 200, 'fields' => 'ids' ) ) );
		$n     = count( $slides );
		echo '<div class="sg-stage" data-count="' . (int) $n . '"><div class="sg-stage-tilt">';
		foreach ( $slides as $i => $sl ) {
			$idx  = array_search( $sl['id'], $order, true );
			$tone = $sl['halo'] ? $sl['halo'] : sgc_work_tone( $sl['id'], false === $idx ? $i : $idx );
			$img  = '';
			if ( $sl['img'] ) {
				$m   = $this->media( $sl['img'] );
				$img = '<img class="sg-stage-img" src="' . esc_url( $m['url'] ) . '" alt="' . esc_attr( get_the_title( $sl['id'] ) ) . '" decoding="async"' . ( $i ? ' loading="lazy"' : ' fetchpriority="high"' ) . '>';
			} else {
				$img = get_the_post_thumbnail( $sl['id'], 'large', array(
					'class'    => 'sg-stage-img',
					'alt'      => get_the_title( $sl['id'] ),
					'loading'  => $i ? 'lazy' : 'eager',
					'decoding' => 'async',
				) );
			}
			echo '<div class="sg-stage-slide' . ( 0 === $i ? ' is-active' : '' ) . '" style="--tone:' . esc_attr( $tone ) . '" data-halo="' . esc_attr( $tone ) . '"' . ( $i ? ' aria-hidden="true"' : '' ) . '>';
			if ( 'yes' === $s['glow'] ) {
				echo '<div class="sg-stage-glow"></div>';
			}
			if ( 'yes' === $s['ring'] ) {
				echo '<div class="sg-stage-ring"></div>';
			}
			$sp = (int) $s['sparks'];
			if ( $sp > 0 ) {
				echo '<div class="sg-stage-sparks" aria-hidden="true">';
				$seed = 7 + $i;
				for ( $k = 0; $k < min( 40, $sp ); $k++ ) {
					$seed = ( $seed * 9301 + 49297 ) % 233280;
					$x    = 8 + ( $seed / 233280 ) * 84;
					$seed = ( $seed * 9301 + 49297 ) % 233280;
					$y    = 6 + ( $seed / 233280 ) * 80;
					$seed = ( $seed * 9301 + 49297 ) % 233280;
					$z    = $seed / 233280;
					printf( '<i style="--x:%.1f%%;--y:%.1f%%;--s:%.1fpx;--t:%.2fs;--dl:%.2fs"></i>', $x, $y, 6 + $z * 9, 2.4 + $z * 3, $z * 4 );
				}
				echo '</div>';
			}
			echo $img; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '</div>';
		}
		echo '</div>';
		$show_ui = ( 'yes' === $s['caption'] ) || ( $n > 1 && 'yes' === $s['controls'] );
		if ( $show_ui ) {
			echo '<div class="sg-stage-ui">';
			if ( 'yes' === $s['caption'] ) {
				echo '<div class="sg-stage-caps" aria-live="polite">';
				foreach ( $slides as $i => $sl ) {
					$terms = get_the_terms( $sl['id'], 'sg_collection' );
					$meta  = array_filter( array( $terms && ! is_wp_error( $terms ) ? $terms[0]->name : '', get_post_meta( $sl['id'], '_sg_materials', true ) ) );
					echo '<div class="sg-stage-caption' . ( 0 === $i ? ' is-active' : '' ) . '"' . ( $i ? ' hidden' : '' ) . '>';
					echo '<span class="sg-stage-title">' . esc_html( get_the_title( $sl['id'] ) ) . '</span>';
					if ( $meta ) {
						echo '<span class="sg-stage-meta">' . esc_html( implode( ' · ', $meta ) ) . '</span>';
					}
					echo '<a class="sg-stage-link" href="' . esc_url( get_permalink( $sl['id'] ) ) . '">' . esc_html( $s['view'] ? $s['view'] : __( 'View piece', 'sogand-site' ) ) . ' ' . self::icon( 'arrow-right', 14 ) . '</a></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}
				echo '</div>';
			} else {
				echo '<span></span>';
			}
			if ( $n > 1 && 'yes' === $s['controls'] ) {
				echo '<div class="sg-stage-ctrl"><span class="sg-stage-no"><b>01</b> <i>/ ' . esc_html( str_pad( (string) $n, 2, '0', STR_PAD_LEFT ) ) . '</i></span><div class="sg-stage-bars">';
				for ( $i = 0; $i < $n; $i++ ) {
					echo '<button type="button" class="sg-stage-bar' . ( 0 === $i ? ' is-active' : '' ) . '" aria-label="' . esc_attr( sprintf( /* translators: %d: slide number */ __( 'Design %d', 'sogand-site' ), $i + 1 ) ) . '"' . ( 0 === $i ? ' aria-current="true"' : '' ) . '><i></i></button>';
				}
				echo '</div></div>';
			}
			echo '</div>';
		}
		echo '</div>';
	}
}

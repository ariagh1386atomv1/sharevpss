<?php
/**
 * Sogand Work Field — one piece of a portfolio entry (title, excerpt, description,
 * collection, a detail, picture, link or breadcrumb). Used in the work page template
 * and in card templates; shows the work being viewed (or each work inside a grid).
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Sogand\Core\Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Work_Field extends Widget_Base {

	public function get_name() {
		return 'sogand-work-field';
	}

	public function get_title() {
		return esc_html__( 'Work Field', 'sogand-core' );
	}

	public function get_icon() {
		return 'eicon-post-title';
	}

	public function get_keywords() {
		return array( 'sogand', 'work', 'title', 'excerpt', 'content', 'portfolio', 'dynamic', 'single' );
	}

	protected function register_controls() {
		$this->start_controls_section( 'content', array( 'label' => esc_html__( 'Field', 'sogand-core' ) ) );
		$this->add_control( 'field', array(
			'label'   => esc_html__( 'Show', 'sogand-core' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'title',
			'options' => array(
				'title'     => esc_html__( 'Title', 'sogand-core' ),
				'excerpt'   => esc_html__( 'Short description (excerpt)', 'sogand-core' ),
				'content'   => esc_html__( 'Full description', 'sogand-core' ),
				'cats'      => esc_html__( 'Collections', 'sogand-core' ),
				'materials' => esc_html__( 'Materials', 'sogand-core' ),
				'gemstones' => esc_html__( 'Gemstones', 'sogand-core' ),
				'technique' => esc_html__( 'Technique', 'sogand-core' ),
				'year'      => esc_html__( 'Year', 'sogand-core' ),
				'image'     => esc_html__( 'Main picture', 'sogand-core' ),
				'link'      => esc_html__( 'Link to the work', 'sogand-core' ),
				'crumbs'    => esc_html__( 'Breadcrumb (Home / Collections / Work)', 'sogand-core' ),
			),
		) );
		$this->add_control( 'tag', array(
			'label'     => esc_html__( 'HTML tag', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'h1',
			'options'   => array( 'h1' => 'H1', 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'p' => 'p', 'div' => 'div', 'span' => 'span' ),
			'condition' => array( 'field' => array( 'title', 'excerpt', 'cats', 'materials', 'gemstones', 'technique', 'year' ) ),
		) );
		$this->add_control( 'before', array( 'label' => esc_html__( 'Text before', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'condition' => array( 'field' => array( 'cats', 'materials', 'gemstones', 'technique', 'year' ) ) ) );
		$this->add_control( 'link_text', array( 'label' => esc_html__( 'Link text', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'discover', 'condition' => array( 'field' => 'link' ) ) );
		$this->add_control( 'link_title', array( 'label' => esc_html__( 'Link the title / picture to the work', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'condition' => array( 'field' => array( 'title', 'image' ) ), 'description' => esc_html__( 'Useful inside card templates.', 'sogand-core' ) ) );
		$this->add_control( 'size', array( 'label' => esc_html__( 'Picture size', 'sogand-core' ), 'type' => Controls_Manager::SELECT, 'default' => 'sogand-square', 'options' => array( 'sogand-square' => '1024 × 1024', 'large' => esc_html__( 'Large', 'sogand-core' ), 'medium_large' => esc_html__( 'Medium', 'sogand-core' ), 'full' => esc_html__( 'Original', 'sogand-core' ) ), 'condition' => array( 'field' => 'image' ) ) );
		$this->add_control( 'crumb_home', array( 'label' => esc_html__( 'Home label', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Home', 'condition' => array( 'field' => 'crumbs' ) ) );
		$this->add_control( 'crumb_coll', array( 'label' => esc_html__( 'Collections label', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Collections', 'condition' => array( 'field' => 'crumbs' ) ) );
		$this->add_control( 'fallback', array( 'label' => esc_html__( 'Text when empty', 'sogand-core' ), 'type' => Controls_Manager::TEXT ) );
		$this->end_controls_section();

		$this->start_controls_section( 'style', array( 'label' => esc_html__( 'Text', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'typo', 'selector' => '{{WRAPPER}} .sg-wf' ) );
		$this->add_control( 'color', array( 'label' => esc_html__( 'Colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-wf, {{WRAPPER}} .sg-wf a' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'color_h', array( 'label' => esc_html__( 'Link hover colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-wf a:hover' => 'color: {{VALUE}};' ) ) );
		$this->add_responsive_control( 'align', array(
			'label'     => esc_html__( 'Alignment', 'sogand-core' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => array(
				'left'   => array( 'title' => esc_html__( 'Left', 'sogand-core' ), 'icon' => 'eicon-text-align-left' ),
				'center' => array( 'title' => esc_html__( 'Center', 'sogand-core' ), 'icon' => 'eicon-text-align-center' ),
				'right'  => array( 'title' => esc_html__( 'Right', 'sogand-core' ), 'icon' => 'eicon-text-align-right' ),
			),
			'selectors' => array( '{{WRAPPER}}' => 'text-align: {{VALUE}};' ),
		) );
		$this->end_controls_section();
	}

	protected function render() {
		$s  = $this->get_settings_for_display();
		$id = sgc_current_work_id();
		if ( ! $id ) {
			if ( $this->in_editor() ) {
				echo '<div class="sg-empty">' . esc_html__( 'Add a work under Works to preview this field.', 'sogand-core' ) . '</div>';
			}
			return;
		}
		$f    = $s['field'];
		$tag  = in_array( $s['tag'], array( 'h1', 'h2', 'h3', 'h4', 'p', 'div', 'span' ), true ) ? $s['tag'] : 'div';
		$url  = get_permalink( $id );
		$html = '';
		switch ( $f ) {
			case 'title':
				$t    = esc_html( get_the_title( $id ) );
				$html = 'yes' === $s['link_title'] ? '<a href="' . esc_url( $url ) . '">' . $t . '</a>' : $t;
				break;
			case 'excerpt':
				$html = has_excerpt( $id ) ? esc_html( get_the_excerpt( $id ) ) : '';
				break;
			case 'content':
				$p = get_post( $id );
				/* the editor shows the text without running other page builders inside it */
				$html = $p ? wpautop( wp_kses_post( $p->post_content ) ) : '';
				$tag  = 'div';
				break;
			case 'cats':
				$terms = get_the_terms( $id, 'sg_collection' );
				$html  = $terms && ! is_wp_error( $terms ) ? esc_html( implode( ' · ', wp_list_pluck( $terms, 'name' ) ) ) : '';
				break;
			case 'materials':
			case 'gemstones':
			case 'technique':
			case 'year':
				$html = esc_html( (string) get_post_meta( $id, '_sg_' . $f, true ) );
				break;
			case 'image':
				$img  = get_the_post_thumbnail( $id, $s['size'] ? $s['size'] : 'sogand-square', array( 'alt' => get_the_title( $id ), 'decoding' => 'async' ) );
				$html = 'yes' === $s['link_title'] ? '<a href="' . esc_url( $url ) . '">' . $img . '</a>' : $img;
				$tag  = 'div';
				break;
			case 'link':
				$html = '<a class="sg-wf-link" href="' . esc_url( $url ) . '">' . esc_html( $s['link_text'] ? $s['link_text'] : __( 'discover', 'sogand-site' ) ) . ' ' . self::icon( 'arrow-right', 14 ) . '</a>';
				$tag  = 'div';
				break;
			case 'crumbs':
				$html = '<a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html( $s['crumb_home'] ) . '</a><span aria-hidden="true">/</span><a href="' . esc_url( sgc_collections_url() ) . '">' . esc_html( $s['crumb_coll'] ) . '</a><span aria-hidden="true">/</span><em aria-current="page">' . esc_html( get_the_title( $id ) ) . '</em>';
				echo '<nav class="sg-wf sg-wf-crumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'sogand-site' ) . '">' . $html . '</nav>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				return;
		}
		if ( '' === trim( wp_strip_all_tags( (string) $html ) ) && 'image' !== $f ) {
			if ( '' === (string) $s['fallback'] ) {
				return;
			}
			$html = esc_html( $s['fallback'] );
		}
		if ( ! empty( $s['before'] ) && in_array( $f, array( 'cats', 'materials', 'gemstones', 'technique', 'year' ), true ) ) {
			$html = '<span class="sg-wf-before">' . esc_html( $s['before'] ) . '</span> ' . $html;
		}
		echo '<' . $tag . ' class="sg-wf sg-wf-' . esc_attr( $f ) . '">' . $html . '</' . $tag . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}

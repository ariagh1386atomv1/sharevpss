<?php
/**
 * Sogand Work Gallery — the main image + gallery of a work, with 20 transitions,
 * autoplay, thumbnails, hover zoom and the work's halo.
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor\Widgets;

use Elementor\Controls_Manager;
use Sogand\Core\Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/collection-slider.php';

class Work_Gallery extends Widget_Base {

	public function get_name() {
		return 'sogand-work-gallery';
	}

	public function get_title() {
		return esc_html__( 'Work Gallery', 'sogand-core' );
	}

	public function get_icon() {
		return 'eicon-gallery-masonry';
	}

	public function get_keywords() {
		return array( 'sogand', 'gallery', 'work', 'slider', 'zoom', 'portfolio', 'single' );
	}

	public function get_style_depends(): array {
		return array( 'sgc-base', 'sgc-gallery' );
	}

	public function get_script_depends(): array {
		return array( 'sgc-core', 'sgc-gallery' );
	}

	public static function effects() {
		return array(
			'fade'      => esc_html__( 'Soft fade', 'sogand-core' ),
			'slide'     => esc_html__( 'Slide sideways', 'sogand-core' ),
			'slide-up'  => esc_html__( 'Slide up', 'sogand-core' ),
			'zoom-in'   => esc_html__( 'Zoom in', 'sogand-core' ),
			'zoom-out'  => esc_html__( 'Zoom out', 'sogand-core' ),
			'blur'      => esc_html__( 'From blur', 'sogand-core' ),
			'flip-x'    => esc_html__( '3D flip (horizontal)', 'sogand-core' ),
			'flip-y'    => esc_html__( '3D flip (vertical)', 'sogand-core' ),
			'rotate'    => esc_html__( 'Rotate & fade', 'sogand-core' ),
			'swing'     => esc_html__( 'Swing (door)', 'sogand-core' ),
			'skew'      => esc_html__( 'Skew', 'sogand-core' ),
			'wipe-left' => esc_html__( 'Wipe sideways', 'sogand-core' ),
			'wipe-up'   => esc_html__( 'Wipe up', 'sogand-core' ),
			'circle'    => esc_html__( 'Circle from the centre', 'sogand-core' ),
			'diamond'   => esc_html__( 'Diamond from the centre', 'sogand-core' ),
			'split-v'   => esc_html__( 'Open from the middle (vertical)', 'sogand-core' ),
			'split-h'   => esc_html__( 'Open from the middle (horizontal)', 'sogand-core' ),
			'blinds'    => esc_html__( 'Blinds', 'sogand-core' ),
			'drop'      => esc_html__( 'Drop from above', 'sogand-core' ),
			'glow'      => esc_html__( 'Golden glow', 'sogand-core' ),
		);
	}

	protected function register_controls() {
		$this->start_controls_section( 'content', array( 'label' => esc_html__( 'Gallery', 'sogand-core' ) ) );
		$this->add_control( 'work', array(
			'label'       => esc_html__( 'Work', 'sogand-core' ),
			'type'        => Controls_Manager::SELECT,
			'options'     => array( '' => esc_html__( 'The work being viewed', 'sogand-core' ) ) + array_slice( Collection_Slider::work_options(), 1, null, true ),
			'default'     => '',
			'description' => esc_html__( 'Pictures: the work’s main image first, then its Gallery images (Works → edit → Work details).', 'sogand-core' ),
		) );
		$this->add_control( 'fx', array( 'label' => esc_html__( 'Transition', 'sogand-core' ), 'type' => Controls_Manager::SELECT, 'default' => 'fade', 'options' => self::effects(), 'frontend_available' => true ) );
		$this->add_control( 'dur', array( 'label' => esc_html__( 'Transition duration (ms)', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 150, 'max' => 3000, 'step' => 50 ) ), 'default' => array( 'size' => 800 ), 'selectors' => array( '{{WRAPPER}}' => '--gdur: {{SIZE}}ms;' ) ) );
		$this->add_control( 'auto', array( 'label' => esc_html__( 'Autoplay', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'frontend_available' => true ) );
		$this->add_control( 'interval', array( 'label' => esc_html__( 'Seconds per image', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 1, 'max' => 20, 'step' => 0.5 ) ), 'default' => array( 'size' => 4 ), 'condition' => array( 'auto' => 'yes' ), 'frontend_available' => true ) );
		$this->add_control( 'timer', array( 'label' => esc_html__( 'Timer line', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'condition' => array( 'auto' => 'yes' ) ) );
		$this->add_control( 'thumbs', array( 'label' => esc_html__( 'Thumbnails', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes' ) );
		$this->add_control( 'arrows', array( 'label' => esc_html__( 'Arrows', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes' ) );
		$this->add_control( 'zoom', array( 'label' => esc_html__( 'Zoom on hover', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'frontend_available' => true ) );
		$this->add_control( 'zoom_lvl', array( 'label' => esc_html__( 'Zoom level (%)', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 120, 'max' => 400 ) ), 'default' => array( 'size' => 230 ), 'condition' => array( 'zoom' => 'yes' ), 'selectors' => array( '{{WRAPPER}}' => '--gzoom: {{SIZE}}%;' ) ) );
		$this->add_control( 'zoom_hint', array( 'label' => esc_html__( 'Zoom hint', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Hover to zoom', 'condition' => array( 'zoom' => 'yes' ) ) );
		$this->add_control( 'halo', array( 'label' => esc_html__( 'Halo of the work’s colour', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes' ) );
		$this->end_controls_section();

		$this->start_controls_section( 's_box', array( 'label' => esc_html__( 'Picture box', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_responsive_control( 'ratio', array( 'label' => esc_html__( 'Ratio', 'sogand-core' ), 'type' => Controls_Manager::SELECT, 'default' => '1/1', 'options' => array( '1/1' => '1 : 1', '4/5' => '4 : 5', '3/4' => '3 : 4', '4/3' => '4 : 3', '16/9' => '16 : 9' ), 'selectors' => array( '{{WRAPPER}} .sg-gal-main' => 'aspect-ratio: {{VALUE}};' ) ) );
		$this->add_control( 'img_scale', array( 'label' => esc_html__( 'Picture size in its box (%)', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 40, 'max' => 100 ) ), 'selectors' => array( '{{WRAPPER}}' => '--gimg: {{SIZE}}%;' ) ) );
		$this->add_control( 'fit', array( 'label' => esc_html__( 'Fit', 'sogand-core' ), 'type' => Controls_Manager::SELECT, 'default' => 'contain', 'options' => array( 'contain' => esc_html__( 'Whole picture', 'sogand-core' ), 'cover' => esc_html__( 'Fill the box', 'sogand-core' ) ), 'selectors' => array( '{{WRAPPER}} .sg-gal-img' => 'object-fit: {{VALUE}};' ) ) );
		$this->add_control( 'box_bg', array( 'label' => esc_html__( 'Box colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-gal-main' => 'background: {{VALUE}};' ) ) );
		$this->add_control( 'box_r', array( 'label' => esc_html__( 'Box radius', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 60 ) ), 'selectors' => array( '{{WRAPPER}} .sg-gal-main' => 'border-radius: {{SIZE}}px;' ) ) );
		$this->add_control( 'thumb_s', array( 'label' => esc_html__( 'Thumbnail size', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 40, 'max' => 160 ) ), 'condition' => array( 'thumbs' => 'yes' ), 'selectors' => array( '{{WRAPPER}}' => '--gthumb: {{SIZE}}px;' ) ) );
		$this->add_control( 'thumb_a', array( 'label' => esc_html__( 'Active thumbnail edge', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'condition' => array( 'thumbs' => 'yes' ), 'selectors' => array( '{{WRAPPER}} .sg-gal-thumb.is-active' => 'border-color: {{VALUE}};' ) ) );
		$this->end_controls_section();
	}

	protected function render() {
		$s   = $this->get_settings_for_display();
		$wid = $s['work'] ? absint( $s['work'] ) : sgc_current_work_id();
		if ( ! $wid ) {
			if ( $this->in_editor() ) {
				echo '<div class="sg-empty">' . esc_html__( 'Add a work under Works to preview its gallery.', 'sogand-core' ) . '</div>';
			}
			return;
		}
		$ids = array_values( array_unique( array_filter( array_merge( array( (int) get_post_thumbnail_id( $wid ) ), sgc_work_gallery_ids( $wid ) ) ) ) );
		$imgs = array_values( array_filter( array_map( 'sgc_img', $ids ) ) );
		if ( ! $imgs ) {
			return;
		}
		$title = get_the_title( $wid );
		$n     = count( $imgs );
		$tone  = sgc_work_tone( $wid );
		$zoom  = 'yes' === $s['zoom'];
		echo '<div class="sg-gal" data-fx="' . esc_attr( $s['fx'] ) . '" style="--tone:' . esc_attr( $tone ) . '">';
		echo '<div class="sg-gal-main' . ( $zoom ? '' : ' no-zoom' ) . '">';
		if ( 'yes' === $s['halo'] ) {
			echo '<div class="sg-gal-glow" aria-hidden="true"></div>';
		}
		echo '<div class="sg-gal-stage">';
		foreach ( $imgs as $i => $im ) {
			$alt = $im['alt'] ? $im['alt'] : ( $i ? sprintf( /* translators: 1: work title 2: image number */ __( '%1$s — image %2$d', 'sogand-site' ), $title, $i + 1 ) : $title );
			echo '<img class="sg-gal-img' . ( 0 === $i ? ' is-current' : '' ) . '" src="' . esc_url( $im['large'] ) . '" data-full="' . esc_url( $im['full'] ) . '" width="' . (int) $im['w'] . '" height="' . (int) $im['h'] . '" alt="' . esc_attr( $alt ) . '"' . ( $i ? ' loading="lazy" hidden' : ' fetchpriority="high"' ) . ' decoding="async">';
		}
		echo '</div>';
		if ( $zoom ) {
			echo '<div class="sg-gal-zoom" aria-hidden="true"></div>';
			if ( $s['zoom_hint'] ) {
				echo '<span class="sg-gal-hint" aria-hidden="true">' . self::icon( 'zoom', 14 ) . ' ' . esc_html( $s['zoom_hint'] ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		}
		if ( $n > 1 && 'yes' === $s['arrows'] ) {
			echo '<div class="sg-gal-arrows"><button type="button" class="sg-round" data-step="-1" aria-label="' . esc_attr__( 'Previous image', 'sogand-site' ) . '">' . self::icon( 'arrow-left', 18 ) . '</button><button type="button" class="sg-round sg-round-light" data-step="1" aria-label="' . esc_attr__( 'Next image', 'sogand-site' ) . '">' . self::icon( 'arrow-right', 18 ) . '</button></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		if ( $n > 1 && 'yes' === $s['auto'] && 'yes' === $s['timer'] ) {
			echo '<span class="sg-gal-timer" aria-hidden="true"></span>';
		}
		echo '</div>';
		if ( $n > 1 && 'yes' === $s['thumbs'] ) {
			echo '<div class="sg-gal-thumbs">';
			foreach ( $imgs as $i => $im ) {
				echo '<button type="button" class="sg-gal-thumb' . ( 0 === $i ? ' is-active' : '' ) . '" data-i="' . (int) $i . '" aria-label="' . esc_attr( sprintf( /* translators: %d: image number */ __( 'Image %d', 'sogand-site' ), $i + 1 ) ) . '"' . ( 0 === $i ? ' aria-current="true"' : '' ) . '><img src="' . esc_url( $im['medium'] ) . '" alt="" loading="lazy" decoding="async"></button>';
			}
			echo '</div>';
		}
		echo '<p class="elementor-screen-only" aria-live="polite" data-sg-live></p>';
		echo '</div>';
	}
}

<?php
/**
 * Sogand Related Works — other pieces from the same collection (topped up with the
 * latest works), shown with the same cards as the Collections grid.
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor\Widgets;

use Elementor\Controls_Manager;
use Sogand\Core\Elementor\Widget_Base;
use Sogand\Core\Elementor\Bridge;
use Sogand\Core\Elementor\Kit_Layout;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/collection-grid.php';

class Related extends Widget_Base {

	public function get_name() {
		return 'sogand-related';
	}

	public function get_title() {
		return esc_html__( 'Related Works', 'sogand-core' );
	}

	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	public function get_keywords() {
		return array( 'sogand', 'related', 'more', 'works', 'portfolio', 'collection' );
	}

	public function get_style_depends(): array {
		return array( 'sgc-base', 'sgc-collection' );
	}

	protected function register_controls() {
		$this->start_controls_section( 'content', array( 'label' => esc_html__( 'Related works', 'sogand-core' ) ) );
		$this->add_control( 'count', array( 'label' => esc_html__( 'How many', 'sogand-core' ), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 12, 'default' => 3 ) );
		$this->add_control( 'order', array(
			'label'   => esc_html__( 'Order', 'sogand-core' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'rand',
			'options' => array(
				'rand' => esc_html__( 'Random', 'sogand-core' ),
				'menu' => esc_html__( 'Portfolio order', 'sogand-core' ),
				'date' => esc_html__( 'Newest first', 'sogand-core' ),
			),
		) );
		$this->add_control( 'fill', array( 'label' => esc_html__( 'Fill up with latest works', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'description' => esc_html__( 'When the collection has fewer pieces than requested.', 'sogand-core' ) ) );
		$this->add_control( 'card_mode', array(
			'label'   => esc_html__( 'Card', 'sogand-core' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'builtin',
			'options' => array(
				'builtin'  => esc_html__( 'Sogand card', 'sogand-core' ),
				'template' => esc_html__( 'A saved template', 'sogand-core' ),
			),
		) );
		$this->add_control( 'card_tpl', array( 'label' => esc_html__( 'Card template', 'sogand-core' ), 'type' => Controls_Manager::SELECT, 'options' => Kit_Layout::template_options( array( 'section', 'container', 'loop-item' ) ), 'default' => '', 'condition' => array( 'card_mode' => 'template' ) ) );
		$this->add_control( 'show_cat', array( 'label' => esc_html__( 'Show collection name', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'condition' => array( 'card_mode' => 'builtin' ) ) );
		$this->add_control( 'halo', array( 'label' => esc_html__( 'Coloured halo', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'condition' => array( 'card_mode' => 'builtin' ) ) );
		$this->add_control( 'btn', array( 'label' => esc_html__( 'Button text', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'discover', 'condition' => array( 'card_mode' => 'builtin' ) ) );
		$this->add_control( 'img_size', array( 'label' => esc_html__( 'Picture size', 'sogand-core' ), 'type' => Controls_Manager::SELECT, 'default' => 'sogand-square', 'options' => array( 'sogand-square' => '1024 × 1024', 'large' => esc_html__( 'Large', 'sogand-core' ), 'medium_large' => esc_html__( 'Medium', 'sogand-core' ) ), 'condition' => array( 'card_mode' => 'builtin' ) ) );
		$this->end_controls_section();

		$this->start_controls_section( 'style', array( 'label' => esc_html__( 'Grid', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_responsive_control( 'cols', array( 'label' => esc_html__( 'Columns', 'sogand-core' ), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 6, 'default' => 3, 'tablet_default' => 2, 'mobile_default' => 1, 'selectors' => array( '{{WRAPPER}} .sg-cg-grid' => 'grid-template-columns: repeat({{VALUE}}, minmax(0, 1fr));' ) ) );
		$this->add_responsive_control( 'gap', array(
			'label'      => esc_html__( 'Gap', 'sogand-core' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => array( 'px', 'rem' ),
			'range'      => array( 'px' => array( 'min' => 0, 'max' => 80 ) ),
			'selectors'  => array( '{{WRAPPER}} .sg-cg-grid' => 'gap: {{SIZE}}{{UNIT}};' ),
		) );
		$this->add_control( 'radius', array( 'label' => esc_html__( 'Picture corner radius', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 80 ) ), 'selectors' => array( '{{WRAPPER}}' => '--sg-card-r: {{SIZE}}px;' ) ) );
		$this->end_controls_section();
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$id    = sgc_current_work_id();
		$count = max( 1, min( 12, (int) $s['count'] ) );
		$ids   = array();
		$order = array( 'rand' => array( 'orderby' => 'rand' ), 'date' => array( 'orderby' => 'date', 'order' => 'DESC' ), 'menu' => array() );
		$ord   = isset( $order[ $s['order'] ] ) ? $order[ $s['order'] ] : array();
		if ( $id ) {
			$terms = get_the_terms( $id, 'sg_collection' );
			if ( $terms && ! is_wp_error( $terms ) ) {
				$ids = get_posts( sgc_works_query_args( array_merge( $ord, array(
					'posts_per_page' => $count,
					'fields'         => 'ids',
					'post__not_in'   => array( $id ), // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams
					'tax_query'      => array( array( 'taxonomy' => 'sg_collection', 'field' => 'term_id', 'terms' => wp_list_pluck( $terms, 'term_id' ) ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
				) ) ) );
			}
		}
		if ( 'yes' === $s['fill'] && count( $ids ) < $count ) {
			$more = get_posts( sgc_works_query_args( array(
				'posts_per_page' => $count - count( $ids ),
				'fields'         => 'ids',
				'post__not_in'   => array_merge( array( (int) $id ), $ids ), // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams
				'orderby'        => 'date',
				'order'          => 'DESC',
			) ) );
			$ids = array_merge( $ids, $more );
		}
		if ( ! $ids ) {
			if ( $this->in_editor() ) {
				echo '<div class="sg-empty">' . esc_html__( 'Related works appear here once the portfolio has more than one piece.', 'sogand-core' ) . '</div>';
			}
			return;
		}
		$tpl  = 'template' === $s['card_mode'] ? absint( $s['card_tpl'] ) : 0;
		$grid = new Collection_Grid();
		echo '<div class="sg-cg sg-related"><div class="sg-cg-grid">';
		global $post;
		$saved = $post;
		foreach ( array_values( $ids ) as $i => $pid ) {
			$p = get_post( $pid );
			if ( ! $p ) {
				continue;
			}
			if ( $tpl && ! Bridge::is_rendering( $tpl ) ) {
				$post = $p; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
				setup_postdata( $p );
				$html = '<div class="sg-card-tpl" style="--tone:' . esc_attr( sgc_work_tone( $p->ID, $i ) ) . '">' . Bridge::render_template( $tpl ) . '</div>';
			} else {
				list( $html ) = $grid->card( $p, $i, $s );
			}
			echo '<div class="sg-cg-cell is-in">' . $html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		$post = $saved; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		if ( $saved ) {
			setup_postdata( $saved );
		}
		echo '</div></div>';
	}
}

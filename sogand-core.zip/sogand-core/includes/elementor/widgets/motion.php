<?php
/**
 * Sogand Motion — one widget for every service and process animation
 * (choose the motion from a list), including the new Digital Rendering piece.
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor\Widgets;

use Elementor\Controls_Manager;
use Sogand\Core\Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Motion extends Widget_Base {

	public function get_name() {
		return 'sogand-motion';
	}

	public function get_title() {
		return esc_html__( 'Motion', 'sogand-core' );
	}

	public function get_icon() {
		return 'eicon-animation';
	}

	public function get_keywords() {
		return array( 'sogand', 'motion', 'animation', 'illustration', 'process', 'service', 'rendering' );
	}

	public function get_style_depends(): array {
		return array( 'sgc-base', 'sgc-motion' );
	}

	public function get_script_depends(): array {
		return array( 'sgc-core', 'sgc-motion' );
	}

	public static function motions() {
		return array(
			'rendering' => esc_html__( 'Digital Rendering — line → material → light → final', 'sogand-core' ),
			'ideation'  => esc_html__( 'Design & Ideation — pencil sketch', 'sogand-core' ),
			'bespoke'   => esc_html__( 'Bespoke Jewelry — the finished solitaire', 'sogand-core' ),
			'modeling'  => esc_html__( '3D Modeling — wireframe ring', 'sogand-core' ),
			'studio'    => esc_html__( '3D Render — faceted brilliant in studio light', 'sogand-core' ),
			'brush'     => esc_html__( 'Procreate Brushes — pearl strand stroke', 'sogand-core' ),
			'talk'      => esc_html__( 'Process: Conversation — speech bubbles', 'sogand-core' ),
			'sketch'    => esc_html__( 'Process: Concept — drawing pencil', 'sogand-core' ),
			'gem'       => esc_html__( 'Process: Refinement — turning gem', 'sogand-core' ),
			'box'       => esc_html__( 'Process: Delivery — opening gift box', 'sogand-core' ),
			'icon-talk' => esc_html__( 'Icon: conversation', 'sogand-core' ),
			'icon-pen'  => esc_html__( 'Icon: pencil', 'sogand-core' ),
			'icon-gem'  => esc_html__( 'Icon: gem', 'sogand-core' ),
			'icon-gift' => esc_html__( 'Icon: gift', 'sogand-core' ),
		);
	}

	protected function register_controls() {
		$this->start_controls_section( 'content', array( 'label' => esc_html__( 'Motion', 'sogand-core' ) ) );
		$this->add_control( 'motion', array(
			'label'   => esc_html__( 'Motion', 'sogand-core' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'rendering',
			'options' => self::motions(),
		) );
		$this->add_control( 'label', array(
			'label'       => esc_html__( 'Description for screen readers', 'sogand-core' ),
			'type'        => Controls_Manager::TEXT,
			'default'     => '',
			'description' => esc_html__( 'Leave empty if a heading next to the motion already says the same; the motion is then decorative.', 'sogand-core' ),
		) );
		foreach ( array( 1 => 'Line', 2 => 'Material', 3 => 'Light', 4 => 'Final' ) as $i => $def ) {
			$this->add_control( 'stage' . $i, array(
				/* translators: %d: stage number */
				'label'     => sprintf( esc_html__( 'Stage %d label', 'sogand-core' ), $i ),
				'type'      => Controls_Manager::TEXT,
				'default'   => $def,
				'condition' => array( 'motion' => 'rendering' ),
			) );
		}
		$this->add_control( 'stages', array(
			'label'        => esc_html__( 'Show the stage bar', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'default'      => 'yes',
			'return_value' => 'yes',
			'condition'    => array( 'motion' => 'rendering' ),
		) );
		$this->end_controls_section();

		$this->start_controls_section( 'playback', array( 'label' => esc_html__( 'Playback', 'sogand-core' ) ) );
		$this->add_control( 'trigger', array(
			'label'   => esc_html__( 'Plays', 'sogand-core' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'view',
			'options' => array(
				'view'   => esc_html__( 'While visible on screen', 'sogand-core' ),
				'always' => esc_html__( 'Always', 'sogand-core' ),
				'hover'  => esc_html__( 'On hover / focus of its box', 'sogand-core' ),
			),
			'frontend_available' => true,
		) );
		$this->add_control( 'loop', array(
			'label'        => esc_html__( 'Loop', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'default'      => 'yes',
			'return_value' => 'yes',
			'prefix_class' => 'sg-mo-loop-',
			'frontend_available' => true,
			'description'  => esc_html__( 'Off = plays once and keeps its last frame.', 'sogand-core' ),
		) );
		$this->add_control( 'replay', array(
			'label'       => esc_html__( 'Redraw every (s) — drawing motions', 'sogand-core' ),
			'type'        => Controls_Manager::NUMBER,
			'min'         => 0,
			'max'         => 120,
			'default'     => 9,
			'description' => esc_html__( 'For the sketch-style illustrations that draw themselves. 0 = draw once.', 'sogand-core' ),
			'condition'   => array( 'loop' => 'yes', 'motion' => array( 'ideation', 'bespoke', 'modeling', 'studio', 'brush' ) ),
			'frontend_available' => true,
		) );
		$this->add_control( 'speed', array(
			'label'     => esc_html__( 'Speed', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0.25, 'max' => 3, 'step' => 0.05 ) ),
			'default'   => array( 'size' => 1 ),
			'selectors' => array( '{{WRAPPER}}' => '--sg-mo-speed: {{SIZE}};' ),
		) );
		$this->add_control( 'delay', array(
			'label'     => esc_html__( 'Delay (s)', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0, 'max' => 10, 'step' => 0.1 ) ),
			'selectors' => array( '{{WRAPPER}}' => '--sg-mo-delay: {{SIZE}}s;' ),
		) );
		$this->add_control( 'direction', array(
			'label'     => esc_html__( 'Direction', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'normal',
			'options'   => array(
				'normal'    => esc_html__( 'Forwards', 'sogand-core' ),
				'reverse'   => esc_html__( 'Backwards', 'sogand-core' ),
				'alternate' => esc_html__( 'Back and forth', 'sogand-core' ),
			),
			'selectors' => array( '{{WRAPPER}}' => '--sg-mo-dir: {{VALUE}};' ),
		) );
		$this->add_control( 'static', array(
			'label'        => esc_html__( 'Still frame (no motion)', 'sogand-core' ),
			'type'         => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'return_value' => 'yes',
			'prefix_class' => 'sg-mo-static-',
			'description'  => esc_html__( 'Shows the finished picture. Visitors who ask for reduced motion always see it.', 'sogand-core' ),
		) );
		$this->end_controls_section();

		/* ---------------- style ---------------- */
		$this->start_controls_section( 'style_box', array( 'label' => esc_html__( 'Box', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_responsive_control( 'w', array(
			'label'      => esc_html__( 'Width', 'sogand-core' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => array( '%', 'px', 'vw' ),
			'range'      => array( 'px' => array( 'min' => 40, 'max' => 900 ) ),
			'default'    => array( 'size' => 100, 'unit' => '%' ),
			'selectors'  => array( '{{WRAPPER}} .sg-motion' => 'width: {{SIZE}}{{UNIT}};' ),
		) );
		$this->add_responsive_control( 'h', array(
			'label'      => esc_html__( 'Height', 'sogand-core' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => array( 'px', 'vh', 'em' ),
			'range'      => array( 'px' => array( 'min' => 40, 'max' => 800 ) ),
			'selectors'  => array( '{{WRAPPER}} .sg-motion' => 'height: {{SIZE}}{{UNIT}}; aspect-ratio: auto;' ),
			'description' => esc_html__( 'Empty = from the aspect ratio.', 'sogand-core' ),
		) );
		$this->add_responsive_control( 'ratio', array(
			'label'     => esc_html__( 'Aspect ratio', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => '',
			'options'   => array(
				''     => esc_html__( 'Natural', 'sogand-core' ),
				'1/1'  => '1 : 1',
				'4/3'  => '4 : 3',
				'6/5'  => '6 : 5',
				'16/9' => '16 : 9',
				'3/4'  => '3 : 4',
			),
			'selectors' => array( '{{WRAPPER}} .sg-motion' => 'aspect-ratio: {{VALUE}};' ),
		) );
		$this->add_responsive_control( 'align', array(
			'label'     => esc_html__( 'Alignment', 'sogand-core' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => array(
				'flex-start' => array( 'title' => esc_html__( 'Start', 'sogand-core' ), 'icon' => 'eicon-text-align-left' ),
				'center'     => array( 'title' => esc_html__( 'Center', 'sogand-core' ), 'icon' => 'eicon-text-align-center' ),
				'flex-end'   => array( 'title' => esc_html__( 'End', 'sogand-core' ), 'icon' => 'eicon-text-align-right' ),
			),
			'default'   => 'center',
			'selectors' => array( '{{WRAPPER}}' => 'display: flex; justify-content: {{VALUE}};' ),
		) );
		$this->add_responsive_control( 'scale', array(
			'label'     => esc_html__( 'Drawing scale inside the box', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0.3, 'max' => 2, 'step' => 0.05 ) ),
			'selectors' => array( '{{WRAPPER}}' => '--sg-mo-scale: {{SIZE}};' ),
		) );
		$this->add_responsive_control( 'pad', array(
			'label'      => esc_html__( 'Inner padding', 'sogand-core' ),
			'type'       => Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', '%' ),
			'selectors'  => array( '{{WRAPPER}} .sg-motion' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );
		$this->add_control( 'bg', array(
			'label'     => esc_html__( 'Background', 'sogand-core' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .sg-motion' => 'background: {{VALUE}};' ),
		) );
		$this->add_control( 'radius', array(
			'label'     => esc_html__( 'Corner radius', 'sogand-core' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0, 'max' => 60 ) ),
			'selectors' => array( '{{WRAPPER}} .sg-motion' => 'border-radius: {{SIZE}}px;' ),
		) );
		$this->end_controls_section();

		$this->start_controls_section( 'style_colors', array( 'label' => esc_html__( 'Colours', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_control( 'c_line', array( 'label' => esc_html__( 'Lines', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-mo-line: {{VALUE}};' ) ) );
		$this->add_control( 'c_gold', array( 'label' => esc_html__( 'Gold', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-mo-gold: {{VALUE}};' ) ) );
		$this->add_control( 'c_stone', array( 'label' => esc_html__( 'Stone / accent', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-mo-stone: {{VALUE}};' ) ) );
		$this->add_control( 'c_deep', array( 'label' => esc_html__( 'Deep shade', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-mo-deep: {{VALUE}};' ) ) );
		$this->add_control( 'c_light', array( 'label' => esc_html__( 'Highlights', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-mo-light: {{VALUE}};' ) ) );
		$this->add_control( 'c_text', array( 'label' => esc_html__( 'Stage labels', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'condition' => array( 'motion' => 'rendering' ), 'selectors' => array( '{{WRAPPER}}' => '--sg-mo-text: {{VALUE}};' ) ) );
		$this->end_controls_section();
	}

	/* ---------------- markup per motion ---------------- */
	private function rendering( $s ) {
		$labels = array();
		for ( $i = 1; $i <= 4; $i++ ) {
			$labels[] = isset( $s[ 'stage' . $i ] ) ? $s[ 'stage' . $i ] : '';
		}
		ob_start();
		?>
		<svg class="mo-svg" viewBox="0 0 240 200" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">
			<defs>
				<radialGradient id="{{u}}ruby" cx=".38" cy=".32" r=".8"><stop offset="0" style="stop-color:var(--sg-mo-light,#f6e7c1)" stop-opacity=".85"/><stop offset=".22" style="stop-color:var(--sg-mo-stone,#b3263f)"/><stop offset=".7" style="stop-color:var(--sg-mo-deep,#4a1020)"/><stop offset="1" stop-color="#1c060b"/></radialGradient>
				<linearGradient id="{{u}}gold" x1="0" x2="1"><stop offset="0" stop-color="#f3e4bd"/><stop offset=".5" style="stop-color:var(--sg-mo-gold,#c9a35c)"/><stop offset="1" stop-color="#8d6b35"/></linearGradient>
				<radialGradient id="{{u}}key" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff" stop-opacity=".55"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>
				<radialGradient id="{{u}}floor" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#000" stop-opacity=".6"/><stop offset="1" stop-color="#000" stop-opacity="0"/></radialGradient>
				<clipPath id="{{u}}clip"><path d="M120 66c22 28 32 50 32 67a32 32 0 0 1-64 0c0-17 10-39 32-67z"/></clipPath>
			</defs>
			<g class="r-grid">
				<path d="M20 40h200M20 80h200M20 120h200M20 160h200M60 20v168M100 20v168M140 20v168M180 20v168"/>
				<circle cx="120" cy="133" r="44" stroke-dasharray="2 4"/>
				<path d="M120 22v170M66 133h108" stroke-dasharray="1 5"/>
			</g>
			<ellipse class="r-floor" cx="120" cy="182" rx="46" ry="6" fill="url(#{{u}}floor)" stroke="none"/>
			<g class="r-body">
				<g clip-path="url(#{{u}}clip)">
					<rect class="r-flood" x="80" y="60" width="80" height="110" fill="url(#{{u}}ruby)" stroke="none"/>
					<path class="r-facet" d="M120 66l-14 50 14 49 14-49z" fill="#fff" fill-opacity=".1" stroke="none"/>
					<circle class="r-key" cx="92" cy="96" r="40" fill="url(#{{u}}key)" stroke="none"/>
				</g>
				<path class="r-draw r-outline" pathLength="1" d="M120 66c22 28 32 50 32 67a32 32 0 0 1-64 0c0-17 10-39 32-67z"/>
				<path class="r-draw r-facets" pathLength="1" d="M120 66l-14 50 14 49 14-49zM88 133h64M106 116l-18 17M134 116l18 17M106 150l14 15 14-15"/>
				<path class="r-draw r-bail" pathLength="1" d="M120 24c0-11 15-11 15 0 0 9-11 13-15 22"/>
				<circle class="r-draw r-ring" pathLength="1" cx="120" cy="54" r="7"/>
				<path class="r-draw r-prongs" pathLength="1" d="M112 64l-3 10M128 64l3 10"/>
				<g class="r-metal">
					<path d="M120 24c0-11 15-11 15 0 0 9-11 13-15 22" stroke="url(#{{u}}gold)" stroke-width="2.4"/>
					<circle cx="120" cy="54" r="7" stroke="url(#{{u}}gold)" stroke-width="2.4"/>
					<path d="M112 64l-3 10M128 64l3 10" stroke="url(#{{u}}gold)" stroke-width="2.4"/>
					<path d="M120 66c22 28 32 50 32 67a32 32 0 0 1-64 0c0-17 10-39 32-67z" stroke="url(#{{u}}gold)" stroke-width="2"/>
				</g>
				<g class="r-spec">
					<path d="M101 108c-5 9-6 18-4 26" stroke-width="4.5"/>
					<path d="M106 98c-2 4-3 7-3 10" stroke-width="2.6"/>
					<path d="M136 152c5-4 8-9 9-15" stroke-width="3"/>
				</g>
			</g>
			<g class="r-swatch">
				<circle cx="30" cy="132" r="8" style="fill:var(--sg-mo-stone,#b3263f)" stroke="none"/>
				<circle cx="30" cy="154" r="8" fill="url(#{{u}}gold)" stroke="none"/>
				<circle cx="30" cy="176" r="8" fill="#e9ecf0" stroke="none"/>
			</g>
			<g class="r-lamp"><circle cx="208" cy="34" r="9"/><path d="M200 42l-60 56M216 42l-10 70" stroke-dasharray="2 5"/></g>
			<g class="r-spark"><path d="M160 84l2.4 7 7 2.4-7 2.4-2.4 7-2.4-7-7-2.4 7-2.4z"/><path d="M94 160l1.6 4.6 4.6 1.6-4.6 1.6-1.6 4.6-1.6-4.6-4.6-1.6 4.6-1.6z"/><path d="M146 50l1.4 4 4 1.4-4 1.4-1.4 4-1.4-4-4-1.4 4-1.4z"/></g>
			<g class="r-frame"><path d="M14 30V16h14M226 30V16h-14M14 170v14h14M226 170v14h-14"/></g>
		</svg>
		<?php if ( 'yes' === $s['stages'] ) : ?>
		<div class="mo-stages" aria-hidden="true">
			<?php foreach ( $labels as $i => $l ) : ?>
				<span class="mo-stage" style="--i:<?php echo (int) $i; ?>"><i></i><?php echo esc_html( $l ); ?></span>
			<?php endforeach; ?>
		</div>
		<?php endif; ?>
		<?php
		return ob_get_clean();
	}

	private function svg_ideation() {
		return '<svg class="mo-svg ill" viewBox="0 0 240 200" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'
			. '<g class="fi" opacity=".35" stroke-width=".6"><circle cx="120" cy="122" r="62" stroke-dasharray="2 4"/><path d="M44 122h152M120 50v146" stroke-dasharray="1 5"/><path d="M66 82l108 80M66 162l108-80" stroke-dasharray="1 6"/></g>'
			. '<g stroke-width="1.1"><ellipse class="dr" pathLength="1" style="--o:0ms" cx="120" cy="134" rx="52" ry="18"/><ellipse class="dr" pathLength="1" style="--o:150ms" cx="121" cy="135" rx="50" ry="17" opacity=".45"/><ellipse class="dr" pathLength="1" style="--o:300ms" cx="120" cy="134" rx="39" ry="11.5"/>'
			. '<path class="dr" pathLength="1" style="--o:450ms" d="M68 134v10M172 134v10M68 144c0 10 23 18 52 18s52-8 52-18"/><path class="dr" pathLength="1" style="--o:650ms" d="M98 98l22-28 22 28-22 30z"/><path class="dr" pathLength="1" style="--o:800ms" d="M103 92h34M120 70l-8 22 8 36 8-36z" opacity=".8"/><path class="dr" pathLength="1" style="--o:900ms" d="M104 116l-6 12M136 116l6 12"/></g>'
			. '<g class="fi mo-note" fill="currentColor" stroke="none" opacity=".6"><text x="186" y="66">Ø 17</text><text x="30" y="186">sketch nº 07</text></g>'
			. '<g stroke-width="1.1"><path class="dr" pathLength="1" style="--o:1100ms" d="M182 186l32-32-8-8-32 32zM174 178l-4 12 12-4M206 146l4-4 8 8-4 4"/><path class="dr" pathLength="1" style="--o:1250ms" d="M150 186c8-4 14-2 20 2" opacity=".6"/></g></svg>';
	}

	private function svg_bespoke() {
		return '<svg class="mo-svg ill" viewBox="0 0 240 200" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><defs>'
			. '<linearGradient id="{{u}}bm" x1="0" x2="1"><stop offset="0" stop-color="#f2efdc"/><stop offset=".35" stop-color="#b9c4a9"/><stop offset=".65" stop-color="#eef0dc"/><stop offset="1" stop-color="#8f9f8c"/></linearGradient>'
			. '<linearGradient id="{{u}}bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".95"/><stop offset=".5" stop-color="#dfe6dc" stop-opacity=".55"/><stop offset="1" stop-color="#9fb3aa" stop-opacity=".8"/></linearGradient>'
			. '<radialGradient id="{{u}}bw"><stop offset="0" stop-color="#dce0c3" stop-opacity=".35"/><stop offset="1" stop-color="#dce0c3" stop-opacity="0"/></radialGradient></defs>'
			. '<circle class="fi" cx="120" cy="84" r="60" fill="url(#{{u}}bw)"/>'
			. '<ellipse class="dr" pathLength="1" style="--o:0ms" cx="120" cy="138" rx="56" ry="22" stroke="url(#{{u}}bm)" stroke-width="7"/>'
			. '<ellipse class="dr" pathLength="1" style="--o:200ms" cx="120" cy="138" rx="56" ry="22" stroke="#fff" stroke-opacity=".35" stroke-width="1"/>'
			. '<path class="dr" pathLength="1" style="--o:500ms" d="M104 112l-4-26M136 112l4-26M112 114l-2-28M128 114l2-28" stroke="url(#{{u}}bm)" stroke-width="2.4"/>'
			. '<path class="fi" d="M92 80l14-16h28l14 16-28 34z" fill="url(#{{u}}bg)"/>'
			. '<g stroke="#fff" stroke-opacity=".9" stroke-width=".9"><path class="dr" pathLength="1" style="--o:700ms" d="M92 80l14-16h28l14 16-28 34z"/><path class="dr" pathLength="1" style="--o:850ms" d="M92 80h56M106 64l-4 16 18 34 18-34-4-16M120 64l-8 16h16z" stroke-opacity=".6"/></g>'
			. '<g class="fi mo-twinkle" fill="#fff" stroke="none"><path d="M156 54l2 6 6 2-6 2-2 6-2-6-6-2 6-2z"/><path d="M82 66l1.4 4 4 1.4-4 1.4-1.4 4-1.4-4-4-1.4 4-1.4z" opacity=".7"/></g></svg>';
	}

	private function svg_modeling() {
		$cx  = 120;
		$cy  = 132;
		$r   = 56;
		$ry  = 20;
		$out = '<svg class="mo-svg ill" viewBox="0 0 240 200" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><g stroke-width=".9">';
		$out .= '<ellipse class="dr" pathLength="1" style="--o:0ms" cx="120" cy="132" rx="65" ry="28"/><ellipse class="dr" pathLength="1" style="--o:150ms" cx="120" cy="132" rx="56" ry="20" stroke-opacity=".6"/><ellipse class="dr" pathLength="1" style="--o:300ms" cx="120" cy="132" rx="47" ry="12"/>';
		$dots = '';
		for ( $i = 0; $i < 12; $i++ ) {
			$t   = ( $i / 12 ) * M_PI * 2;
			$x   = $cx + $r * cos( $t );
			$y   = $cy + $ry * sin( $t );
			$w   = 3 + 7 * abs( sin( $t ) );
			$out .= sprintf( '<ellipse class="dr" pathLength="1" style="--o:%dms" cx="%.1f" cy="%.1f" rx="%.1f" ry="9" stroke-opacity=".55"/>', 420 + $i * 45, $x, $y, $w );
			$dots .= sprintf( '<circle cx="%.1f" cy="%.1f" r="1.6"/>', $x, $y - 9 );
		}
		$out .= '<path class="dr" pathLength="1" style="--o:1000ms" d="M104 110l16-44 16 44M96 104l24-38 24 38M104 110q16 8 32 0M98 102q22 10 44 0" stroke-opacity=".8"/></g>';
		$out .= '<g class="fi" fill="currentColor" stroke="none">' . $dots . '<circle cx="120" cy="66" r="2"/></g>';
		$out .= '<g class="fi" stroke-width="1.2"><path d="M24 182h26" stroke="#c97a87"/><path d="M24 182v-26" stroke="#88a99a"/><path d="M24 182l-12 10"/></g>';
		$out .= '<g class="fi mo-note" fill="currentColor" stroke="none" opacity=".55"><text x="168" y="186">MESH · 2,048 v</text></g></svg>';
		return $out;
	}

	private function svg_studio() {
		return '<svg class="mo-svg ill" viewBox="0 0 240 200" fill="none" stroke-linejoin="round" aria-hidden="true" focusable="false"><defs>'
			. '<linearGradient id="{{u}}sf" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff"/><stop offset="1" stop-color="#9fb4ab"/></linearGradient>'
			. '<radialGradient id="{{u}}sfl"><stop offset="0" stop-color="#000" stop-opacity=".55"/><stop offset="1" stop-color="#000" stop-opacity="0"/></radialGradient>'
			. '<radialGradient id="{{u}}sk"><stop offset="0" stop-color="#dce0c3" stop-opacity=".22"/><stop offset="1" stop-color="#dce0c3" stop-opacity="0"/></radialGradient></defs>'
			. '<circle class="fi" cx="70" cy="40" r="150" fill="url(#{{u}}sk)"/><ellipse class="fi" cx="120" cy="176" rx="64" ry="9" fill="url(#{{u}}sfl)"/>'
			. '<g class="fi"><polygon points="60,92 84,64 104,64 96,92" fill="url(#{{u}}sf)" fill-opacity=".55"/><polygon points="96,92 104,64 136,64 144,92" fill="url(#{{u}}sf)" fill-opacity=".9"/><polygon points="144,92 136,64 156,64 180,92" fill="url(#{{u}}sf)" fill-opacity=".4"/><polygon points="60,92 96,92 120,164" fill="url(#{{u}}sf)" fill-opacity=".35"/><polygon points="96,92 144,92 120,164" fill="url(#{{u}}sf)" fill-opacity=".75"/><polygon points="144,92 180,92 120,164" fill="url(#{{u}}sf)" fill-opacity=".22"/></g>'
			. '<g stroke="#fff" stroke-opacity=".85" stroke-width=".8"><path class="dr" pathLength="1" style="--o:0ms" d="M60 92l24-28h72l24 28-60 72z"/><path class="dr" pathLength="1" style="--o:300ms" d="M60 92h120M84 64l12 28 24 72 24-72 12-28M104 64l-8 28M136 64l8 28M96 92l24-28 24 28" stroke-opacity=".5"/></g>'
			. '<g class="fi mo-twinkle" fill="#fff"><path d="M150 66l2.6 8 8 2.6-8 2.6-2.6 8-2.6-8-8-2.6 8-2.6z"/></g>'
			. '<g class="fi" stroke="currentColor" stroke-opacity=".5" stroke-width="1"><path d="M18 34V20h14M222 34V20h-14M18 166v14h14M222 166v14h-14"/></g></svg>';
	}

	private function svg_brush() {
		$pearls = '';
		for ( $i = 0; $i < 11; $i++ ) {
			$t       = $i / 10;
			$x       = 44 + $t * 152;
			$y       = 120 + sin( $t * M_PI * 1.15 + 0.2 ) * -34;
			$r       = 7 + sin( $t * M_PI ) * 3;
			$pearls .= sprintf( '<circle class="fi" cx="%.1f" cy="%.1f" r="%.1f" fill="url(#{{u}}pp)" style="transition-delay:calc(var(--d,0ms) + %dms)"/>', $x, $y, $r, 700 + $i * 70 );
		}
		return '<svg class="mo-svg ill" viewBox="0 0 240 200" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><defs><radialGradient id="{{u}}pp" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="#fff"/><stop offset=".45" stop-color="#ece6da"/><stop offset=".85" stop-color="#a99a94"/><stop offset="1" stop-color="#6e5a5a"/></radialGradient></defs>'
			. '<path class="dr" pathLength="1" style="--o:0ms" d="M40 124C80 70 120 70 150 92s40 30 50 22" stroke="#6d2634" stroke-width="22" stroke-opacity=".55"/>'
			. '<path class="fi" d="M40 124C80 70 120 70 150 92s40 30 50 22" stroke="currentColor" stroke-width="1" stroke-dasharray="1 5" stroke-opacity=".6"/>'
			. '<g>' . $pearls . '</g>'
			. '<g stroke="currentColor" stroke-width="1.1"><path class="dr" pathLength="1" style="--o:900ms" d="M200 114l20-30M216 80l8 6M204 120c-6 6-14 6-18 2 6-2 10-6 12-10z"/></g>'
			. '<g class="fi"><path d="M34 168h40" stroke="currentColor" stroke-width="5" stroke-opacity=".5"/><path d="M86 168h40" stroke="currentColor" stroke-width="5" stroke-dasharray="1 6" stroke-opacity=".7"/><path d="M138 168h40" stroke="#88a99a" stroke-width="6" stroke-opacity=".5"/><path d="M190 168h18" stroke="#e07a8c" stroke-width="4" stroke-opacity=".45"/></g></svg>';
	}

	private function icon_motion( $k ) {
		$p = array(
			'icon-talk' => 'M4 6h16v10H9l-5 4zM8 10h8M8 13h5',
			'icon-pen'  => 'M5 19l3-1 10-10-2-2L6 16zM14 6l2 2M4 21h16',
			'icon-gem'  => 'M12 3l8 6-8 12L4 9zM4 9h16M9 9l3 12 3-12',
			'icon-gift' => 'M4 9h16v11H4zM2 6h20v3H2zM12 6v14M12 6c-2-4-6-3-5 0M12 6c2-4 6-3 5 0',
		);
		return '<span class="mo-icw"><svg class="mo-svg mo-ic" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path pathLength="1" d="' . esc_attr( $p[ $k ] ) . '"/></svg></span>';
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$type  = isset( $s['motion'] ) && array_key_exists( $s['motion'], self::motions() ) ? $s['motion'] : 'rendering';
		$uid   = 'sgm' . $this->get_id();
		$label = trim( (string) $s['label'] );
		$aria  = '' !== $label ? ' role="img" aria-label="' . esc_attr( $label ) . '"' : ' aria-hidden="true"';
		switch ( $type ) {
			case 'rendering':
				$inner = $this->rendering( $s );
				break;
			case 'ideation':
				$inner = $this->svg_ideation();
				break;
			case 'bespoke':
				$inner = $this->svg_bespoke();
				break;
			case 'modeling':
				$inner = $this->svg_modeling();
				break;
			case 'studio':
				$inner = $this->svg_studio();
				break;
			case 'brush':
				$inner = $this->svg_brush();
				break;
			case 'talk':
				$inner = '<span class="pm-bub b1"><i></i><i></i><i></i></span><span class="pm-bub b2"><i></i><i></i><i></i></span>';
				break;
			case 'sketch':
				$inner = '<svg class="mo-svg" viewBox="0 0 160 110" aria-hidden="true" focusable="false"><ellipse cx="80" cy="64" rx="44" ry="18" pathLength="1" class="d1"/><path d="M58 56 L80 22 L102 56 Z" pathLength="1" class="d2"/><path d="M70 56 L80 30 L90 56" pathLength="1" class="d3"/><g class="pm-pencil"><path d="M0 0 L26 -26 L32 -20 L6 6 Z"/><path d="M0 0 L6 6 L-3 9 Z" class="tip"/></g></svg>';
				break;
			case 'gem':
				$inner = '<svg class="mo-svg" viewBox="0 0 120 110" aria-hidden="true" focusable="false"><g class="pm-gem-g"><path d="M30 34 L60 14 L90 34 L60 96 Z" class="f1"/><path d="M30 34 L60 40 L60 96 Z" class="f2"/><path d="M90 34 L60 40 L60 96 Z" class="f3"/><path d="M30 34 L60 14 L60 40 Z" class="f4"/><path d="M90 34 L60 14 L60 40 Z" class="f5"/></g></svg><i class="s1"></i><i class="s2"></i><i class="s3"></i>';
				break;
			case 'box':
				$inner = '<span class="pm-box-glow"></span><span class="pm-box-body"><span class="pm-ribbon-v"></span></span><span class="pm-box-lid"><span class="pm-ribbon-v"></span></span><span class="pm-box-spark"><i></i><i></i><i></i><i></i></span>';
				break;
			default:
				$inner = $this->icon_motion( $type );
		}
		$inner = str_replace( '{{u}}', esc_attr( $uid ), $inner );
		echo '<div class="sg-motion sg-m-' . esc_attr( $type ) . '"' . $aria . '><div class="sg-motion-in">' . $inner . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}

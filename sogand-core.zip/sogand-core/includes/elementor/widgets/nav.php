<?php
/**
 * Sogand Navigation — reads a WordPress menu (Appearance → Menus): dropdowns,
 * Collections / Services mega panels and the full-screen mobile menu.
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Plugin;
use Sogand\Core\Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Nav extends Widget_Base {

	public function get_name() {
		return 'sogand-nav';
	}

	public function get_title() {
		return esc_html__( 'Navigation & Mega Menu', 'sogand-core' );
	}

	public function get_icon() {
		return 'eicon-nav-menu';
	}

	public function get_keywords() {
		return array( 'sogand', 'menu', 'nav', 'navigation', 'mega', 'burger', 'mobile' );
	}

	public function get_style_depends(): array {
		return array( 'sgc-base', 'sgc-nav' );
	}

	public function get_script_depends(): array {
		return array( 'sgc-core', 'sgc-nav' );
	}

	private function menus() {
		$out = array( '' => esc_html__( 'Menu in the “Primary” location', 'sogand-core' ) );
		foreach ( wp_get_nav_menus() as $m ) {
			$out[ (string) $m->term_id ] = $m->name;
		}
		return $out;
	}

	protected function register_controls() {
		$this->start_controls_section( 'content', array( 'label' => esc_html__( 'Menu', 'sogand-core' ) ) );
		$this->add_control( 'menu', array(
			'label'       => esc_html__( 'Menu', 'sogand-core' ),
			'type'        => Controls_Manager::SELECT,
			'default'     => '',
			'options'     => $this->menus(),
			'description' => sprintf(
				/* translators: %s: link to the menus screen */
				esc_html__( 'Items, order and sub-items are edited in %s. The panel type of each top item (dropdown / Collections / Services) is chosen there too.', 'sogand-core' ),
				'<a href="' . esc_url( admin_url( 'nav-menus.php' ) ) . '" target="_blank">' . esc_html__( 'Appearance → Menus', 'sogand-core' ) . '</a>'
			),
		) );
		$this->add_control( 'location', array(
			'label'     => esc_html__( 'Menu location (when no menu is chosen)', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'primary',
			'options'   => array(
				'primary' => esc_html__( 'Primary', 'sogand-core' ),
				'footer'  => esc_html__( 'Footer', 'sogand-core' ),
			),
			'condition' => array( 'menu' => '' ),
		) );
		$this->add_control( 'layout', array(
			'label'        => esc_html__( 'Display', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => 'bar',
			'options'      => array(
				'bar'  => esc_html__( 'Header menu (panels + mobile menu)', 'sogand-core' ),
				'list' => esc_html__( 'Simple list of links (footer)', 'sogand-core' ),
			),
			'prefix_class' => 'sg-nav-mode-',
		) );
		$this->add_control( 'list_children', array(
			'label'     => esc_html__( 'Show sub-items', 'sogand-core' ),
			'type'      => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ),
			'default'   => '',
			'condition' => array( 'layout' => 'list' ),
		) );
		$this->add_control( 'mobile_bp', array(
			'label'   => esc_html__( 'Switch to the mobile menu below', 'sogand-core' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'tablet',
			'options' => array(
				'tablet' => esc_html__( 'Tablet breakpoint', 'sogand-core' ),
				'mobile' => esc_html__( 'Mobile breakpoint', 'sogand-core' ),
				'custom' => esc_html__( 'Custom width', 'sogand-core' ),
				'never'  => esc_html__( 'Never', 'sogand-core' ),
			),
		) );
		$this->add_control( 'mobile_px', array(
			'label'     => esc_html__( 'Width (px)', 'sogand-core' ),
			'type'      => Controls_Manager::NUMBER,
			'default'   => 1040,
			'min'       => 320,
			'max'       => 1920,
			'condition' => array( 'mobile_bp' => 'custom' ),
		) );
		$this->add_control( 'hover_delay', array(
			'label'   => esc_html__( 'Panel close delay (ms)', 'sogand-core' ),
			'type'    => Controls_Manager::NUMBER,
			'default' => 180,
			'min'     => 0,
			'max'     => 1500,
			'step'    => 10,
		) );
		$this->add_control( 'chevron', array( 'label' => esc_html__( 'Arrow next to items with a panel', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'default' => 'yes', 'return_value' => 'yes' ) );
		$this->end_controls_section();

		$this->start_controls_section( 'mega', array( 'label' => esc_html__( 'Collections panel', 'sogand-core' ) ) );
		$this->add_control( 'mg_browse', array( 'label' => esc_html__( 'Label', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Browse' ) );
		$this->add_control( 'mg_all', array( 'label' => esc_html__( 'All works link text', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'All works' ) );
		$this->add_control( 'mg_cats', array( 'label' => esc_html__( 'List the collections', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes' ) );
		$this->add_control( 'mg_counts', array( 'label' => esc_html__( 'Show counts', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes' ) );
		$this->add_control( 'mg_works', array( 'label' => esc_html__( 'Number of works with pictures', 'sogand-core' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 9, 'default' => 3 ) );
		$this->add_control( 'mg_note', array( 'label' => esc_html__( 'Note link text', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Commission a bespoke piece' ) );
		$this->add_control( 'mg_note_url', array( 'label' => esc_html__( 'Note link', 'sogand-core' ), 'type' => Controls_Manager::URL, 'placeholder' => '/contact/' ) );
		$this->add_control( 'svc_text', array( 'label' => esc_html__( 'Services panel: show descriptions', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'separator' => 'before', 'description' => esc_html__( 'The description of each sub-item (Appearance → Menus → Description).', 'sogand-core' ) ) );
		$this->end_controls_section();

		$this->start_controls_section( 'mobile', array( 'label' => esc_html__( 'Mobile menu', 'sogand-core' ) ) );
		$this->add_control( 'm_cta', array( 'label' => esc_html__( 'Button text', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Book a consultation' ) );
		$this->add_control( 'm_cta_url', array( 'label' => esc_html__( 'Button link', 'sogand-core' ), 'type' => Controls_Manager::URL ) );
		$this->add_control( 'm_phone', array( 'label' => esc_html__( 'Show phone', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes' ) );
		$this->add_control( 'm_email', array( 'label' => esc_html__( 'Show email', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes' ) );
		$this->add_control( 'm_ig', array( 'label' => esc_html__( 'Show Instagram', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes' ) );
		$this->add_control( 'm_mark', array( 'label' => esc_html__( 'Watermark image', 'sogand-core' ), 'type' => Controls_Manager::MEDIA, 'description' => esc_html__( 'Empty = the dark Sogand mark.', 'sogand-core' ) ) );
		$this->add_control( 'burger_label', array( 'label' => esc_html__( 'Menu button name (screen readers)', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Menu' ) );
		$this->end_controls_section();

		/* ---------------- style: links ---------------- */
		$this->start_controls_section( 's_links', array( 'label' => esc_html__( 'Menu items', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'link_typo', 'selector' => '{{WRAPPER}} .sg-nav-link' ) );
		$this->add_control( 'link_c', array( 'label' => esc_html__( 'Colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-nav-c: {{VALUE}};' ) ) );
		$this->add_control( 'link_ch', array( 'label' => esc_html__( 'Hover colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-nav-ch: {{VALUE}};' ) ) );
		$this->add_control( 'link_ca', array( 'label' => esc_html__( 'Current page colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-nav-ca: {{VALUE}};' ) ) );
		$this->add_responsive_control( 'link_gap', array( 'label' => esc_html__( 'Space between items', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 60 ) ), 'selectors' => array( '{{WRAPPER}} .sg-nav-list' => 'gap: {{SIZE}}px;' ) ) );
		$this->add_responsive_control( 'link_pad', array( 'label' => esc_html__( 'Item padding', 'sogand-core' ), 'type' => Controls_Manager::DIMENSIONS, 'size_units' => array( 'px', 'em' ), 'selectors' => array( '{{WRAPPER}} .sg-nav-link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ) ) );
		$this->add_responsive_control( 'nav_align', array(
			'label'     => esc_html__( 'Alignment', 'sogand-core' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => array(
				'flex-start' => array( 'title' => esc_html__( 'Start', 'sogand-core' ), 'icon' => 'eicon-h-align-left' ),
				'center'     => array( 'title' => esc_html__( 'Center', 'sogand-core' ), 'icon' => 'eicon-h-align-center' ),
				'flex-end'   => array( 'title' => esc_html__( 'End', 'sogand-core' ), 'icon' => 'eicon-h-align-right' ),
			),
			'selectors' => array( '{{WRAPPER}} .sg-nav-list' => 'justify-content: {{VALUE}};', '{{WRAPPER}} .sg-nav-mob-bar' => 'justify-content: {{VALUE}};' ),
		) );
		$this->add_control( 'effect', array(
			'label'        => esc_html__( 'Hover effect', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => 'metal-line',
			'options'      => array(
				'metal-line' => esc_html__( 'Gold & silver underline', 'sogand-core' ),
				'solid-line' => esc_html__( 'Simple underline', 'sogand-core' ),
				'glow'       => esc_html__( 'Soft glow', 'sogand-core' ),
				'pill'       => esc_html__( 'Glass pill', 'sogand-core' ),
				'lift'       => esc_html__( 'Lift', 'sogand-core' ),
				'color'      => esc_html__( 'Colour only', 'sogand-core' ),
			),
			'prefix_class' => 'sg-nav-fx-',
		) );
		$this->add_control( 'indicator', array(
			'label'        => esc_html__( 'Current page mark', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => 'diamond',
			'options'      => array(
				'diamond' => esc_html__( 'Small gold diamond', 'sogand-core' ),
				'line'    => esc_html__( 'Underline', 'sogand-core' ),
				'none'    => esc_html__( 'None', 'sogand-core' ),
			),
			'prefix_class' => 'sg-nav-ind-',
		) );
		$this->end_controls_section();

		/* ---------------- style: panels ---------------- */
		$this->start_controls_section( 's_mega', array( 'label' => esc_html__( 'Dropdown & mega panels', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_control( 'mg_bg', array( 'label' => esc_html__( 'Background', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-mg-bg: {{VALUE}};' ) ) );
		$this->add_control( 'mg_blur', array( 'label' => esc_html__( 'Backdrop blur', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 60 ) ), 'selectors' => array( '{{WRAPPER}}' => '--sg-mg-blur: {{SIZE}}px;' ) ) );
		$this->add_control( 'mg_radius', array( 'label' => esc_html__( 'Corner radius', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 48 ) ), 'selectors' => array( '{{WRAPPER}}' => '--sg-mg-r: {{SIZE}}px;' ) ) );
		$this->add_control( 'mg_border', array( 'label' => esc_html__( 'Edge colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-mg-bd: {{VALUE}};' ) ) );
		$this->add_responsive_control( 'mg_width', array( 'label' => esc_html__( 'Mega panel width', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'size_units' => array( 'px', 'vw' ), 'range' => array( 'px' => array( 'min' => 320, 'max' => 1400 ) ), 'selectors' => array( '{{WRAPPER}}' => '--sg-mg-w: {{SIZE}}{{UNIT}};' ) ) );
		$this->add_group_control( Group_Control_Box_Shadow::get_type(), array( 'name' => 'mg_shadow', 'selector' => '{{WRAPPER}} .sg-mega' ) );
		$this->add_control( 'mg_anim', array(
			'label'        => esc_html__( 'Opening animation', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => 'unfold',
			'options'      => array(
				'unfold' => esc_html__( 'Unfold from the top', 'sogand-core' ),
				'fade'   => esc_html__( 'Fade', 'sogand-core' ),
				'rise'   => esc_html__( 'Rise', 'sogand-core' ),
			),
			'prefix_class' => 'sg-mg-anim-',
		) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'mg_typo', 'label' => esc_html__( 'Panel links', 'sogand-core' ), 'selector' => '{{WRAPPER}} .sg-mega-link, {{WRAPPER}} .sg-mega-svc-title, {{WRAPPER}} .sg-drop a' ) );
		$this->add_control( 'mg_hover', array( 'label' => esc_html__( 'Panel link hover colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-mg-hc: {{VALUE}};' ) ) );
		$this->end_controls_section();

		/* ---------------- style: mobile ---------------- */
		$this->start_controls_section( 's_mobile', array( 'label' => esc_html__( 'Mobile menu', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_control( 'mb_bg', array( 'label' => esc_html__( 'Background', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-mn-bg: {{VALUE}};' ) ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'mb_typo', 'selector' => '{{WRAPPER}} .sg-mnav-row > a' ) );
		$this->add_control( 'burger_c', array( 'label' => esc_html__( 'Menu button lines', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-burger-c: {{VALUE}};' ) ) );
		$this->add_control( 'burger_bg', array( 'label' => esc_html__( 'Menu button background', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}}' => '--sg-burger-bg: {{VALUE}};' ) ) );
		$this->add_responsive_control( 'burger_size', array( 'label' => esc_html__( 'Menu button size', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 32, 'max' => 72 ) ), 'selectors' => array( '{{WRAPPER}}' => '--sg-burger-s: {{SIZE}}px;' ) ) );
		$this->end_controls_section();
	}

	private function bp_px( $s ) {
		if ( 'never' === $s['mobile_bp'] ) {
			return 0;
		}
		if ( 'custom' === $s['mobile_bp'] ) {
			return max( 320, (int) $s['mobile_px'] );
		}
		$bp = Plugin::$instance->breakpoints->get_breakpoints( 'mobile' === $s['mobile_bp'] ? 'mobile' : 'tablet' );
		return $bp ? (int) $bp->get_value() : ( 'mobile' === $s['mobile_bp'] ? 767 : 1024 );
	}

	private function contact_url() {
		return sgc_page_url( 'contact' );
	}

	private function svg_icon( $name ) {
		return self::icon( $name ? $name : 'sparkle', 20 );
	}

	private function mega_collections( $s, $item ) {
		$cats  = sgc_collection_terms();
		$works = (int) $s['mg_works'];
		$base  = $item['url'] ? $item['url'] : sgc_collections_url();
		$total = (int) wp_count_posts( 'sg_work' )->publish;
		ob_start();
		echo '<div class="sg-mega sg-mega-wide' . ( $works ? '' : ' no-works' ) . '">';
		echo '<div class="sg-mega-col">';
		if ( $s['mg_browse'] ) {
			echo '<div class="sg-mega-label">' . esc_html( $s['mg_browse'] ) . '</div>';
		}
		echo '<a class="sg-mega-link" href="' . esc_url( $base ) . '">' . esc_html( $s['mg_all'] ) . ( 'yes' === $s['mg_counts'] ? ' <span>' . (int) $total . '</span>' : '' ) . '</a>';
		if ( 'yes' === $s['mg_cats'] ) {
			foreach ( $cats as $c ) {
				echo '<a class="sg-mega-link" href="' . esc_url( add_query_arg( 'cat', $c->slug, $base ) ) . '">' . esc_html( $c->name ) . ( 'yes' === $s['mg_counts'] ? ' <span>' . (int) $c->count . '</span>' : '' ) . '</a>';
			}
		}
		foreach ( $item['children'] as $ch ) {
			echo '<a class="sg-mega-link" href="' . esc_url( $ch['url'] ) . '"' . ( $ch['target'] ? ' target="' . esc_attr( $ch['target'] ) . '" rel="noopener"' : '' ) . '>' . esc_html( $ch['title'] ) . '</a>';
		}
		if ( $s['mg_note'] ) {
			$note = ! empty( $s['mg_note_url']['url'] ) ? $s['mg_note_url']['url'] : $this->contact_url();
			echo '<a class="sg-mega-note" href="' . esc_url( $note ) . '">' . esc_html( $s['mg_note'] ) . ' ' . self::icon( 'arrow-right', 14 ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</div>';
		if ( $works ) {
			echo '<div class="sg-mega-works">';
			$q = get_posts( sgc_works_query_args( array( 'posts_per_page' => $works ) ) );
			foreach ( $q as $i => $p ) {
				$terms = get_the_terms( $p, 'sg_collection' );
				echo '<a class="sg-mega-work" href="' . esc_url( get_permalink( $p ) ) . '" style="--tone:' . esc_attr( sgc_work_tone( $p->ID, $i ) ) . '">';
				echo '<span class="sg-mega-work-img">' . get_the_post_thumbnail( $p, 'medium_large', array( 'alt' => '', 'loading' => 'lazy' ) ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo '<span class="sg-mega-work-cat">' . esc_html( $terms && ! is_wp_error( $terms ) ? $terms[0]->name : __( 'Work', 'sogand-core' ) ) . '</span>';
				echo '<span class="sg-mega-work-title">' . esc_html( get_the_title( $p ) ) . '</span></a>';
			}
			echo '</div>';
		}
		echo '</div>';
		return ob_get_clean();
	}

	private function mega_services( $s, $item ) {
		ob_start();
		echo '<div class="sg-mega sg-mega-services">';
		foreach ( $item['children'] as $ch ) {
			echo '<a class="sg-mega-svc' . ( $ch['current'] ? ' is-current' : '' ) . '" href="' . esc_url( $ch['url'] ) . '"' . ( $ch['current'] ? ' aria-current="page"' : '' ) . '>';
			echo '<span class="sg-mega-svc-ico">' . $this->svg_icon( $ch['icon'] ) . '</span><span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '<span class="sg-mega-svc-title">' . esc_html( $ch['title'] ) . '</span>';
			if ( 'yes' === $s['svc_text'] && $ch['desc'] ) {
				echo '<span class="sg-mega-svc-text">' . esc_html( $ch['desc'] ) . '</span>';
			}
			echo '</span></a>';
		}
		echo '</div>';
		return ob_get_clean();
	}

	private function dropdown( $item ) {
		ob_start();
		echo '<div class="sg-mega sg-drop"><ul>';
		foreach ( $item['children'] as $ch ) {
			echo '<li><a href="' . esc_url( $ch['url'] ) . '"' . ( $ch['current'] ? ' aria-current="page" class="is-current"' : '' ) . ( $ch['target'] ? ' target="' . esc_attr( $ch['target'] ) . '" rel="noopener"' : '' ) . '>' . esc_html( $ch['title'] ) . '</a></li>';
		}
		echo '</ul></div>';
		return ob_get_clean();
	}

	/** Sub-links of an item for the mobile accordion. */
	private function sub_links( $item ) {
		$out = array();
		if ( 'collections' === $item['mega'] ) {
			$base  = $item['url'] ? $item['url'] : sgc_collections_url();
			$out[] = array( __( 'All works', 'sogand-core' ), $base );
			foreach ( sgc_collection_terms() as $c ) {
				$out[] = array( $c->name, add_query_arg( 'cat', $c->slug, $base ) );
			}
		}
		foreach ( $item['children'] as $ch ) {
			$out[] = array( $ch['title'], $ch['url'] );
		}
		return $out;
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$loc   = in_array( $s['location'], array( 'primary', 'footer' ), true ) ? $s['location'] : 'primary';
		$tree  = sgc_menu_tree( $s['menu'] ? (int) $s['menu'] : $loc );
		if ( ! $tree && 'footer' === $loc && ! $s['menu'] ) {
			$tree = sgc_menu_tree( 'primary' ); /* no footer menu yet: the primary menu keeps the footer useful */
		}
		$uid   = 'sgnav-' . $this->get_id();
		$bp    = $this->bp_px( $s );
		if ( ! $tree ) {
			if ( $this->in_editor() ) {
				echo '<div class="sg-empty">' . esc_html__( 'Create a menu in Appearance → Menus and assign it to the “Primary” location (or choose it here).', 'sogand-core' ) . '</div>';
			}
			return;
		}
		if ( 'list' === $s['layout'] ) {
			echo '<nav class="sg-nav-links" aria-label="' . esc_attr( 'footer' === $loc ? __( 'Footer', 'sogand-site' ) : __( 'Site', 'sogand-site' ) ) . '"><ul>';
			foreach ( $tree as $item ) {
				echo '<li><a href="' . esc_url( $item['url'] ) . '"' . ( $item['current'] ? ' aria-current="page"' : '' ) . ( $item['target'] ? ' target="' . esc_attr( $item['target'] ) . '" rel="noopener"' : '' ) . '>' . esc_html( $item['title'] ) . '</a>';
				if ( 'yes' === $s['list_children'] && $item['children'] ) {
					echo '<ul>';
					foreach ( $item['children'] as $c ) {
						echo '<li><a href="' . esc_url( $c['url'] ) . '">' . esc_html( $c['title'] ) . '</a></li>';
					}
					echo '</ul>';
				}
				echo '</li>';
			}
			echo '</ul></nav>';
			return;
		}
		if ( $bp ) {
			$sel = '.elementor-element-' . esc_attr( $this->get_id() );
			echo '<style>@media (max-width:' . (int) $bp . 'px){' . $sel . ' .sg-nav-desk{display:none}' . $sel . ' .sg-nav-mob-bar{display:flex}}@media (min-width:' . ( (int) $bp + 1 ) . 'px){' . $sel . ' .sg-mnav{display:none}}</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '<div class="sg-nav" data-delay="' . (int) $s['hover_delay'] . '">';

		/* desktop */
		echo '<nav class="sg-nav-desk" aria-label="' . esc_attr__( 'Primary', 'sogand-site' ) . '"><ul class="sg-nav-list">';
		foreach ( $tree as $i => $item ) {
			$has   = $item['mega'] || $item['children'];
			$panel = '';
			if ( 'collections' === $item['mega'] ) {
				$panel = $this->mega_collections( $s, $item );
			} elseif ( 'services' === $item['mega'] && $item['children'] ) {
				$panel = $this->mega_services( $s, $item );
			} elseif ( $item['children'] ) {
				$panel = $this->dropdown( $item );
			}
			$has   = '' !== $panel;
			$cls   = 'sg-nav-item' . ( $has ? ' has-panel' : '' ) . ( $item['mega'] ? ' is-mega' : '' );
			$lcls  = 'sg-nav-link' . ( $item['current'] ? ' is-active' : '' ) . ( $item['ancestor'] ? ' is-parent' : '' );
			$pid   = $uid . '-p' . $i;
			echo '<li class="' . esc_attr( $cls ) . '">';
			echo '<a class="' . esc_attr( $lcls ) . '" href="' . esc_url( $item['url'] ) . '"' . ( $item['current'] ? ' aria-current="page"' : '' ) . ( $item['target'] ? ' target="' . esc_attr( $item['target'] ) . '" rel="noopener"' : '' ) . '>' . esc_html( $item['title'] ) . '</a>';
			if ( $has ) {
				echo '<button type="button" class="sg-nav-toggle" aria-expanded="false" aria-controls="' . esc_attr( $pid ) . '"><span class="elementor-screen-only">' . esc_html( sprintf( /* translators: %s: menu item */ __( 'Show %s', 'sogand-site' ), $item['title'] ) ) . '</span>' . ( 'yes' === $s['chevron'] ? self::icon( 'chevron', 12 ) : '' ) . '</button>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo '<div class="sg-mega-shell" id="' . esc_attr( $pid ) . '">' . $panel . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '</li>';
		}
		echo '</ul></nav>';

		/* mobile bar + panel */
		$label = $s['burger_label'] ? $s['burger_label'] : __( 'Menu', 'sogand-site' );
		echo '<div class="sg-nav-mob-bar"><button type="button" class="sg-burger" aria-expanded="false" aria-controls="' . esc_attr( $uid ) . '-m"><span class="elementor-screen-only">' . esc_html( $label ) . '</span><i></i><i></i><i></i></button></div>';
		$mark = ! empty( $s['m_mark']['url'] ) ? $s['m_mark']['url'] : sgc_asset( 'img/mark-dark.webp' );
		echo '<div class="sg-mnav" id="' . esc_attr( $uid ) . '-m" role="dialog" aria-modal="true" aria-label="' . esc_attr( $label ) . '" hidden>';
		echo '<img src="' . esc_url( $mark ) . '" alt="" class="sg-mnav-mark" loading="lazy">';
		echo '<div class="sg-mnav-inner"><button type="button" class="sg-mnav-close"><span class="elementor-screen-only">' . esc_html__( 'Close menu', 'sogand-site' ) . '</span>' . self::icon( 'close', 20 ) . '</button>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		foreach ( $tree as $i => $item ) {
			$subs = $this->sub_links( $item );
			echo '<div class="sg-mnav-item" style="--d:' . (int) ( 80 + $i * 60 ) . 'ms"><div class="sg-mnav-row">';
			echo '<a href="' . esc_url( $item['url'] ) . '"' . ( $item['current'] ? ' aria-current="page"' : '' ) . '>' . esc_html( $item['title'] ) . '</a>';
			if ( $subs ) {
				$sid = $uid . '-s' . $i;
				echo '<button type="button" class="sg-mnav-toggle" aria-expanded="false" aria-controls="' . esc_attr( $sid ) . '"><span class="elementor-screen-only">' . esc_html( sprintf( /* translators: %s: menu item */ __( 'Show %s', 'sogand-site' ), $item['title'] ) ) . '</span>' . self::icon( 'chevron', 14 ) . '</button></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo '<div class="sg-mnav-sub" id="' . esc_attr( $sid ) . '"><div>';
				foreach ( $subs as $sub ) {
					echo '<a href="' . esc_url( $sub[1] ) . '">' . esc_html( $sub[0] ) . '</a>';
				}
				echo '</div></div>';
			} else {
				echo '</div>';
			}
			echo '</div>';
		}
		echo '<div class="sg-mnav-foot" style="--d:' . (int) ( 120 + count( $tree ) * 60 ) . 'ms">';
		if ( $s['m_cta'] ) {
			$cta = ! empty( $s['m_cta_url']['url'] ) ? $s['m_cta_url']['url'] : $this->contact_url();
			echo '<a class="sg-btn sg-btn-light" href="' . esc_url( $cta ) . '">' . esc_html( $s['m_cta'] ) . '</a>';
		}
		$phone = sgc_setting( 'phone' );
		if ( 'yes' === $s['m_phone'] && $phone ) {
			echo '<a class="sg-mnav-line" href="tel:' . esc_attr( sgc_phone_link( $phone ) ) . '">' . self::icon( 'phone', 16 ) . ' <span dir="ltr">' . esc_html( $phone ) . '</span></a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		$email = sgc_setting( 'site_email' );
		if ( 'yes' === $s['m_email'] && $email ) {
			echo '<a class="sg-mnav-line" href="mailto:' . esc_attr( $email ) . '">' . self::icon( 'mail', 16 ) . ' ' . esc_html( $email ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		$ig = sgc_setting( 'instagram_url' );
		if ( 'yes' === $s['m_ig'] && $ig ) {
			echo '<a class="sg-mnav-line" href="' . esc_url( $ig ) . '" target="_blank" rel="noopener">' . self::icon( 'instagram', 16 ) . ' @' . esc_html( sgc_setting( 'instagram_handle' ) ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</div></div></div>';
		echo '</div>';
	}
}

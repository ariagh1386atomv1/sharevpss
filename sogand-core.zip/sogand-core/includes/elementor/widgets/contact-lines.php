<?php
/**
 * Sogand Contact Details — phone, email, Instagram and WhatsApp taken from
 * Settings → Sogand Settings, so they are changed in one place.
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Sogand\Core\Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Contact_Lines extends Widget_Base {

	public function get_name() {
		return 'sogand-contact-lines';
	}

	public function get_title() {
		return esc_html__( 'Contact Details', 'sogand-core' );
	}

	public function get_icon() {
		return 'eicon-envelope';
	}

	public function get_keywords() {
		return array( 'sogand', 'contact', 'phone', 'email', 'instagram', 'whatsapp', 'footer' );
	}

	public function get_style_depends(): array {
		return array( 'sgc-base', 'sgc-forms' );
	}

	protected function register_controls() {
		$this->start_controls_section( 'content', array( 'label' => esc_html__( 'Details', 'sogand-core' ) ) );
		$this->add_control( 'note', array(
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => esc_html__( 'The phone number, email, Instagram and WhatsApp come from Settings → Sogand Settings.', 'sogand-core' ),
			'content_classes' => 'elementor-descriptor',
		) );
		$this->add_control( 'look', array(
			'label'        => esc_html__( 'Look', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => 'lines',
			'options'      => array(
				'lines' => esc_html__( 'Lines with small label', 'sogand-core' ),
				'icons' => esc_html__( 'Round icon and text', 'sogand-core' ),
				'only'  => esc_html__( 'Round icons only', 'sogand-core' ),
			),
			'prefix_class' => 'sg-cl-',
		) );
		$this->add_control( 'direction', array(
			'label'        => esc_html__( 'Direction', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => 'column',
			'options'      => array(
				'column' => esc_html__( 'Stacked', 'sogand-core' ),
				'row'    => esc_html__( 'In a row', 'sogand-core' ),
			),
			'selectors'    => array( '{{WRAPPER}} .sg-cl' => 'flex-direction: {{VALUE}};' ),
		) );
		foreach ( array(
			'phone'     => array( __( 'Phone', 'sogand-core' ), 'Phone' ),
			'email'     => array( __( 'Email', 'sogand-core' ), 'Email' ),
			'instagram' => array( __( 'Instagram', 'sogand-core' ), 'Instagram' ),
			'whatsapp'  => array( __( 'WhatsApp', 'sogand-core' ), 'WhatsApp' ),
		) as $k => $l ) {
			$this->add_control( 'show_' . $k, array( 'label' => sprintf( /* translators: %s: Phone/Email/… */ esc_html__( 'Show %s', 'sogand-core' ), $l[0] ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'whatsapp' === $k ? '' : 'yes', 'separator' => 'before' ) );
			$this->add_control( 'label_' . $k, array( 'label' => esc_html__( 'Small label', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => $l[1], 'condition' => array( 'show_' . $k => 'yes', 'look' => 'lines' ) ) );
		}
		$this->add_control( 'wa_text', array( 'label' => esc_html__( 'WhatsApp text', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Message me', 'condition' => array( 'show_whatsapp' => 'yes' ) ) );
		$this->end_controls_section();

		$this->start_controls_section( 's_style', array( 'label' => esc_html__( 'Details', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_responsive_control( 'gap', array( 'label' => esc_html__( 'Gap', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 60 ) ), 'selectors' => array( '{{WRAPPER}} .sg-cl' => 'gap: {{SIZE}}px;' ) ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'v_t', 'label' => esc_html__( 'Text', 'sogand-core' ), 'selector' => '{{WRAPPER}} .sg-cl-v' ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'l_t', 'label' => esc_html__( 'Small label', 'sogand-core' ), 'selector' => '{{WRAPPER}} .sg-cl small' ) );
		$this->add_control( 'c', array( 'label' => esc_html__( 'Colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-cl a' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'ch', array( 'label' => esc_html__( 'Hover colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-cl a:hover' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'ic_bg', array( 'label' => esc_html__( 'Icon circle', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-cl-ic' => 'background: {{VALUE}};' ) ) );
		$this->add_control( 'ic_c', array( 'label' => esc_html__( 'Icon colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-cl-ic' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'ic_size', array( 'label' => esc_html__( 'Icon circle size', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 24, 'max' => 72 ) ), 'selectors' => array( '{{WRAPPER}} .sg-cl-ic' => 'width: {{SIZE}}px; height: {{SIZE}}px;' ) ) );
		$this->end_controls_section();
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$items = array();
		$phone = trim( (string) sgc_setting( 'phone' ) );
		$email = sanitize_email( (string) sgc_setting( 'site_email' ) );
		$ig    = esc_url_raw( (string) sgc_setting( 'instagram_url' ) );
		$wa    = sgc_whatsapp_url();
		if ( 'yes' === $s['show_phone'] && '' !== $phone ) {
			$items[] = array( 'phone', 'tel:' . sgc_phone_link( $phone ), $s['label_phone'], '<span class="sg-cl-v" dir="ltr">' . esc_html( $phone ) . '</span>', false );
		}
		if ( 'yes' === $s['show_email'] && $email ) {
			$items[] = array( 'mail', 'mailto:' . $email, $s['label_email'], '<span class="sg-cl-v">' . esc_html( $email ) . '</span>', false );
		}
		if ( 'yes' === $s['show_instagram'] && $ig ) {
			$items[] = array( 'instagram', $ig, $s['label_instagram'], '<span class="sg-cl-v">@' . esc_html( ltrim( (string) sgc_setting( 'instagram_handle' ), '@' ) ) . '</span>', true );
		}
		if ( 'yes' === $s['show_whatsapp'] && $wa ) {
			$items[] = array( 'whatsapp', $wa, $s['label_whatsapp'], '<span class="sg-cl-v">' . esc_html( $s['wa_text'] ) . '</span>', true );
		}
		if ( ! $items ) {
			if ( $this->in_editor() ) {
				echo '<div class="sg-empty">' . esc_html__( 'Add contact details under Settings → Sogand Settings.', 'sogand-core' ) . '</div>';
			}
			return;
		}
		$look = $s['look'];
		echo '<div class="sg-cl">';
		foreach ( $items as $it ) {
			list( $icon, $href, $label, $value, $ext ) = $it;
			$aria = 'only' === $look ? ' aria-label="' . esc_attr( wp_strip_all_tags( $value ) ) . '"' : '';
			echo '<a class="sg-cl-item sg-cl-' . esc_attr( $icon ) . '" href="' . esc_url( $href, array( 'http', 'https', 'mailto', 'tel' ) ) . '"' . ( $ext ? ' target="_blank" rel="noopener"' : '' ) . $aria . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			if ( 'lines' !== $look ) {
				echo '<span class="sg-cl-ic" aria-hidden="true">' . self::icon( $icon, 16 ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			if ( 'lines' === $look ) {
				echo '<small>' . esc_html( $label ) . '</small>';
			}
			if ( 'only' !== $look ) {
				echo $value; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '</a>';
		}
		echo '</div>';
	}
}

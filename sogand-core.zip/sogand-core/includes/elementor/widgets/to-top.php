<?php
/**
 * Sogand Back to Top — a text button (footer style) or a floating round button
 * that appears after scrolling, with an optional reading-progress ring.
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Sogand\Core\Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class To_Top extends Widget_Base {

	public function get_name() {
		return 'sogand-to-top';
	}

	public function get_title() {
		return esc_html__( 'Back to Top', 'sogand-core' );
	}

	public function get_icon() {
		return 'eicon-arrow-up';
	}

	public function get_keywords() {
		return array( 'sogand', 'top', 'scroll', 'back', 'up', 'footer' );
	}

	protected function register_controls() {
		$this->start_controls_section( 'content', array( 'label' => esc_html__( 'Button', 'sogand-core' ) ) );
		$this->add_control( 'mode', array(
			'label'        => esc_html__( 'Type', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => 'inline',
			'options'      => array(
				'inline'   => esc_html__( 'Text button where it is placed', 'sogand-core' ),
				'floating' => esc_html__( 'Floating round button', 'sogand-core' ),
			),
			'prefix_class' => 'sg-totop-',
		) );
		$this->add_control( 'text', array( 'label' => esc_html__( 'Text', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Back to top', 'description' => esc_html__( 'The floating button shows only the arrow; this text becomes its accessible name.', 'sogand-core' ) ) );
		$this->add_control( 'after', array( 'label' => esc_html__( 'Appear after scrolling (px)', 'sogand-core' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 4000, 'default' => 600, 'condition' => array( 'mode' => 'floating' ) ) );
		$this->add_control( 'ring', array( 'label' => esc_html__( 'Progress ring', 'sogand-core' ), 'type' => Controls_Manager::SWITCHER, 'label_on' => esc_html__( 'Yes', 'sogand-core' ), 'label_off' => esc_html__( 'No', 'sogand-core' ), 'return_value' => 'yes', 'default' => 'yes', 'condition' => array( 'mode' => 'floating' ) ) );
		$this->add_control( 'side', array(
			'label'     => esc_html__( 'Side', 'sogand-core' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'right',
			'options'   => array( 'right' => esc_html__( 'Right', 'sogand-core' ), 'left' => esc_html__( 'Left', 'sogand-core' ) ),
			'selectors_dictionary' => array( 'right' => 'right: var(--sg-top-x, 24px); left: auto;', 'left' => 'left: var(--sg-top-x, 24px); right: auto;' ),
			'selectors' => array( '{{WRAPPER}}.sg-totop-floating .sg-totop' => '{{VALUE}}' ),
			'condition' => array( 'mode' => 'floating' ),
		) );
		$this->end_controls_section();

		$this->start_controls_section( 's_style', array( 'label' => esc_html__( 'Button', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 't', 'selector' => '{{WRAPPER}} .sg-totop', 'condition' => array( 'mode' => 'inline' ) ) );
		$this->add_control( 'c', array( 'label' => esc_html__( 'Colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-totop' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'ch', array( 'label' => esc_html__( 'Hover colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-totop:hover' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'bg', array( 'label' => esc_html__( 'Background', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-totop' => 'background: {{VALUE}};' ) ) );
		$this->add_control( 'ring_c', array( 'label' => esc_html__( 'Ring colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-totop' => '--sg-top-ring: {{VALUE}};' ), 'condition' => array( 'mode' => 'floating', 'ring' => 'yes' ) ) );
		$this->add_control( 'size', array( 'label' => esc_html__( 'Size', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 36, 'max' => 80 ) ), 'selectors' => array( '{{WRAPPER}} .sg-totop' => '--sg-top-s: {{SIZE}}px;' ), 'condition' => array( 'mode' => 'floating' ) ) );
		$this->add_responsive_control( 'x', array( 'label' => esc_html__( 'Distance from the side', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 120 ) ), 'selectors' => array( '{{WRAPPER}} .sg-totop' => '--sg-top-x: {{SIZE}}px;' ), 'condition' => array( 'mode' => 'floating' ) ) );
		$this->add_responsive_control( 'y', array( 'label' => esc_html__( 'Distance from the bottom', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 160 ) ), 'selectors' => array( '{{WRAPPER}} .sg-totop' => '--sg-top-y: {{SIZE}}px;' ), 'condition' => array( 'mode' => 'floating' ) ) );
		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		if ( 'floating' === $s['mode'] ) {
			$after = $this->in_editor() ? 0 : max( 0, (int) $s['after'] );
			echo '<button type="button" class="sg-totop sg-totop-float' . ( $this->in_editor() ? ' is-shown' : '' ) . '" data-sg-top data-after="' . (int) $after . '" aria-label="' . esc_attr( $s['text'] ) . '">';
			if ( 'yes' === $s['ring'] ) {
				echo '<svg class="sg-totop-ring" viewBox="0 0 48 48" aria-hidden="true"><circle cx="24" cy="24" r="22" pathLength="1"/></svg>';
			}
			echo self::icon( 'arrow-up', 18 ) . '</button>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			return;
		}
		echo '<button type="button" class="sg-totop" data-sg-top><span>' . esc_html( $s['text'] ) . '</span>' . self::icon( 'arrow-up', 14 ) . '</button>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}

<?php
/**
 * Sogand Join the Journey — email sign-up. Subscribers are stored under Inquiries
 * (type “newsletter”, duplicates ignored) and the studio is notified by email.
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Sogand\Core\Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Newsletter extends Widget_Base {

	public function get_name() {
		return 'sogand-newsletter';
	}

	public function get_title() {
		return esc_html__( 'Join the Journey (sign-up)', 'sogand-core' );
	}

	public function get_icon() {
		return 'eicon-mail';
	}

	public function get_keywords() {
		return array( 'sogand', 'newsletter', 'subscribe', 'email', 'journey', 'sign up' );
	}

	public function get_style_depends(): array {
		return array( 'sgc-base', 'sgc-forms' );
	}

	public function get_script_depends(): array {
		return array( 'sgc-core', 'sgc-forms' );
	}

	protected function register_controls() {
		$this->start_controls_section( 'content', array( 'label' => esc_html__( 'Sign-up', 'sogand-core' ) ) );
		$this->add_control( 'style', array(
			'label'        => esc_html__( 'Look', 'sogand-core' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => 'pill',
			'options'      => array(
				'pill'  => esc_html__( 'Glass pill with button', 'sogand-core' ),
				'line'  => esc_html__( 'Underline with round arrow', 'sogand-core' ),
				'stack' => esc_html__( 'Field above full-width button', 'sogand-core' ),
			),
			'prefix_class' => 'sg-nl-',
		) );
		$this->add_control( 'label', array( 'label' => esc_html__( 'Field label (for screen readers)', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Email' ) );
		$this->add_control( 'placeholder', array( 'label' => esc_html__( 'Placeholder', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Your email' ) );
		$this->add_control( 'btn', array( 'label' => esc_html__( 'Button text', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Join', 'description' => esc_html__( 'The underline look shows an arrow; this text becomes its accessible name.', 'sogand-core' ) ) );
		$this->add_control( 'source', array( 'label' => esc_html__( 'Source label (stored with the subscriber)', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'journey' ) );
		$this->add_control( 'm_email', array( 'label' => esc_html__( 'Invalid email', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Please enter a valid email.', 'separator' => 'before' ) );
		$this->add_control( 'm_ok', array( 'label' => esc_html__( 'Success', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'Welcome to the journey.' ) );
		$this->add_control( 'm_already', array( 'label' => esc_html__( 'Already subscribed', 'sogand-core' ), 'type' => Controls_Manager::TEXT, 'default' => 'You are already on the list — thank you.' ) );
		$this->end_controls_section();

		$this->start_controls_section( 's_style', array( 'label' => esc_html__( 'Sign-up', 'sogand-core' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_responsive_control( 'max', array( 'label' => esc_html__( 'Max width', 'sogand-core' ), 'type' => Controls_Manager::SLIDER, 'size_units' => array( 'px', '%' ), 'range' => array( 'px' => array( 'min' => 200, 'max' => 900 ) ), 'selectors' => array( '{{WRAPPER}} .sg-nl' => 'max-width: {{SIZE}}{{UNIT}};' ) ) );
		$this->add_responsive_control( 'align', array(
			'label'     => esc_html__( 'Alignment', 'sogand-core' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => array(
				'0 auto 0 0' => array( 'title' => esc_html__( 'Start', 'sogand-core' ), 'icon' => 'eicon-h-align-left' ),
				'0 auto'     => array( 'title' => esc_html__( 'Center', 'sogand-core' ), 'icon' => 'eicon-h-align-center' ),
				'0 0 0 auto' => array( 'title' => esc_html__( 'End', 'sogand-core' ), 'icon' => 'eicon-h-align-right' ),
			),
			'selectors' => array( '{{WRAPPER}} .sg-nl' => 'margin: {{VALUE}};' ),
		) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'in_t', 'selector' => '{{WRAPPER}} .sg-nl input[type=email]' ) );
		$this->add_control( 'in_c', array( 'label' => esc_html__( 'Text colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-nl input[type=email]' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'in_bg', array( 'label' => esc_html__( 'Background', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-nl-row' => 'background: {{VALUE}};' ) ) );
		$this->add_group_control( Group_Control_Border::get_type(), array( 'name' => 'in_b', 'selector' => '{{WRAPPER}} .sg-nl-row' ) );
		$this->add_control( 'btn_c', array( 'label' => esc_html__( 'Button text colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'separator' => 'before', 'selectors' => array( '{{WRAPPER}} .sg-nl button' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'btn_bg', array( 'label' => esc_html__( 'Button background', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-nl button' => 'background: {{VALUE}};' ) ) );
		$this->add_control( 'msg_c', array( 'label' => esc_html__( 'Message colour', 'sogand-core' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .sg-nl-msg' => 'color: {{VALUE}};' ) ) );
		$this->end_controls_section();
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$id   = 'sgnl' . $this->get_id();
		$msgs = array(
			'email'   => $s['m_email'],
			'ok'      => $s['m_ok'],
			'already' => $s['m_already'],
		);
		$line = 'line' === $s['style'];
		echo '<form class="sg-nl" data-sg-form="newsletter" data-msgs="' . esc_attr( wp_json_encode( $msgs ) ) . '" novalidate>';
		echo '<input type="text" name="website" tabindex="-1" autocomplete="off" class="sg-hp" aria-hidden="true">';
		echo '<input type="hidden" name="_sgt" value="' . esc_attr( sgc_form_token() ) . '">';
		echo '<input type="hidden" name="type" value="newsletter">';
		echo '<input type="hidden" name="source" value="' . esc_attr( $s['source'] ) . '">';
		echo '<label class="sg-sr" for="' . esc_attr( $id ) . '">' . esc_html( $s['label'] ) . '</label>';
		echo '<div class="sg-nl-row"><input id="' . esc_attr( $id ) . '" name="email" type="email" autocomplete="email" placeholder="' . esc_attr( $s['placeholder'] ) . '" data-required="1" aria-describedby="' . esc_attr( $id ) . '-msg">';
		if ( $line ) {
			echo '<button type="submit" aria-label="' . esc_attr( $s['btn'] ) . '">' . self::icon( 'arrow-right', 16 ) . '</button>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} else {
			echo '<button type="submit"><span class="sg-btn-t">' . esc_html( $s['btn'] ) . '</span></button>';
		}
		echo '</div><p class="sg-nl-msg" id="' . esc_attr( $id ) . '-msg" role="status" aria-live="polite"></p></form>';
	}
}

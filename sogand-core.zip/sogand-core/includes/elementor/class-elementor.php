<?php
/**
 * Elementor integration: widget category, widgets, shared control extensions,
 * the "Sogand" Site Settings tab, local fonts and frontend assets.
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor;

use Elementor\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Integration {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/** Widget slug => class file (relative to widgets/) and class name. */
	public static function widgets() {
		return array(
			'logo'              => 'Logo',
			'signature'         => 'Signature',
			'nav'               => 'Nav',
			'motion'            => 'Motion',
			'ornament'          => 'Ornament',
			'marquee'           => 'Marquee',
			'collection-slider' => 'Collection_Slider',
			'collection-grid'   => 'Collection_Grid',
			'work-gallery'      => 'Work_Gallery',
			'work-field'        => 'Work_Field',
			'work-specs'        => 'Work_Specs',
			'work-nav'          => 'Work_Nav',
			'related'           => 'Related',
			'template'          => 'Template_Ref',
			'contact-form'      => 'Contact_Form',
			'newsletter'        => 'Newsletter',
			'faq-search'        => 'Faq_Search',
			'contact-lines'     => 'Contact_Lines',
			'to-top'            => 'To_Top',
		);
	}

	private function __construct() {
		require_once __DIR__ . '/class-widget-base.php';
		require_once __DIR__ . '/controls/class-fx.php';
		require_once __DIR__ . '/kit/class-kit-sogand.php';
		require_once __DIR__ . '/class-bridge.php';
		require_once __DIR__ . '/class-transitions.php';

		add_action( 'elementor/elements/categories_registered', array( $this, 'category' ) );
		add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );
		add_action( 'elementor/kit/register_tabs', array( $this, 'kit_tabs' ) );
		add_action( 'elementor/frontend/after_register_styles', array( $this, 'register_styles' ) );
		add_action( 'elementor/frontend/after_register_scripts', array( $this, 'register_scripts' ) );
		add_action( 'elementor/frontend/after_enqueue_styles', array( $this, 'enqueue_base' ) );
		add_action( 'elementor/editor/after_enqueue_styles', array( $this, 'editor_styles' ) );
		add_action( 'elementor/preview/enqueue_styles', array( $this, 'preview_styles' ) );
		add_filter( 'elementor/fonts/groups', array( $this, 'font_groups' ) );
		add_filter( 'elementor/fonts/additional_fonts', array( $this, 'fonts' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_fonts' ), 5 );

		FX::instance();
		Bridge::instance();
		Transitions::instance();
	}

	public function category( $manager ) {
		$manager->add_category( 'sogand', array(
			'title' => esc_html__( 'Sogand', 'sogand-core' ),
			'icon'  => 'eicon-star',
		) );
	}

	public function register_widgets( $widgets_manager ) {
		foreach ( self::widgets() as $file => $class ) {
			$path = __DIR__ . '/widgets/' . $file . '.php';
			if ( ! file_exists( $path ) ) {
				continue;
			}
			require_once $path;
			$fqcn = __NAMESPACE__ . '\\Widgets\\' . $class;
			if ( class_exists( $fqcn ) ) {
				$widgets_manager->register( new $fqcn() );
			}
		}
	}

	public function kit_tabs( $kit ) {
		$kit->register_tab( 'sogand-effects', Kit_Sogand::class );
		$kit->register_tab( 'sogand-transitions', Kit_Transitions::class );
		$kit->register_tab( 'sogand-layout', Kit_Layout::class );
	}

	/** One stylesheet per feature, so a page only loads what its widgets need. */
	public static function styles() {
		return array(
			'sgc-base'       => array( 'base.css', array() ),
			'sgc-fx'         => array( 'fx.css', array( 'sgc-base' ) ),
			'sgc-layouts'    => array( 'layouts.css', array( 'sgc-base' ) ),
			'sgc-nav'        => array( 'nav.css', array( 'sgc-base' ) ),
			'sgc-motion'     => array( 'motion.css', array( 'sgc-base' ) ),
			'sgc-ornament'   => array( 'ornament.css', array( 'sgc-base' ) ),
			'sgc-marquee'    => array( 'marquee.css', array( 'sgc-base' ) ),
			'sgc-collection' => array( 'collection.css', array( 'sgc-base' ) ),
			'sgc-gallery'    => array( 'gallery.css', array( 'sgc-base' ) ),
			'sgc-forms'      => array( 'forms.css', array( 'sgc-base' ) ),
			'sgc-transition' => array( 'transitions.css', array() ),
		);
	}

	public static function scripts() {
		return array(
			'sgc-core'       => array( 'core.js', array( 'elementor-frontend' ) ),
			'sgc-fx'         => array( 'fx.js', array( 'sgc-core' ) ),
			'sgc-nav'        => array( 'nav.js', array( 'sgc-core' ) ),
			'sgc-motion'     => array( 'motion.js', array( 'sgc-core' ) ),
			'sgc-marquee'    => array( 'marquee.js', array( 'sgc-core' ) ),
			'sgc-collection' => array( 'collection.js', array( 'sgc-core' ) ),
			'sgc-gallery'    => array( 'gallery.js', array( 'sgc-core' ) ),
			'sgc-forms'      => array( 'forms.js', array( 'sgc-core' ) ),
			'sgc-transition' => array( 'transitions.js', array() ),
		);
	}

	public function register_styles() {
		foreach ( self::styles() as $handle => $s ) {
			wp_register_style( $handle, SGC_URL . 'assets/css/' . $s[0], $s[1], SGC_VERSION );
		}
	}

	public function register_scripts() {
		foreach ( self::scripts() as $handle => $s ) {
			wp_register_script( $handle, SGC_URL . 'assets/js/' . $s[0], $s[1], SGC_VERSION, true );
		}
		wp_localize_script( 'sgc-core', 'sgcConfig', array(
			'rest'   => esc_url_raw( rest_url( 'sogand/v1/' ) ),
			'reduce' => Kit_Sogand::val( 'sg_reduce_motion', 'system' ),
			'i18n'   => array(
				'sending' => __( 'Sending…', 'sogand-site' ),
				'error'   => __( 'Something went wrong — please try again or email me directly.', 'sogand-site' ),
			),
		) );
	}

	/** Base styles + the shared FX runtime are used by nearly every Sogand page. */
	public function enqueue_base() {
		wp_enqueue_style( 'sgc-base' );
		wp_enqueue_style( 'sgc-fx' );
		wp_enqueue_style( 'sgc-layouts' );
		wp_enqueue_script( 'sgc-fx' );
	}

	public function editor_styles() {
		wp_enqueue_style( 'sgc-editor', SGC_URL . 'assets/css/editor.css', array(), SGC_VERSION );
	}

	public function preview_styles() {
		wp_enqueue_style( 'sgc-preview', SGC_URL . 'assets/css/preview.css', array(), SGC_VERSION );
	}

	/* ---- local font (Poppins, OFL) offered in every Elementor typography control ---- */
	public function font_groups( $groups ) {
		return array_merge( array( 'sogand' => esc_html__( 'Sogand (local)', 'sogand-core' ) ), $groups );
	}

	public function fonts( $fonts ) {
		$fonts['Sogand Sans'] = 'sogand';
		return $fonts;
	}

	public function enqueue_fonts() {
		wp_enqueue_style( 'sgc-fonts', SGC_URL . 'assets/css/fonts.css', array(), SGC_VERSION );
	}
}

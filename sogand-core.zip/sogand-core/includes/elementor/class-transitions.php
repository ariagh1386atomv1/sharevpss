<?php
/**
 * Page-transition curtain around normal WordPress page loads (20 presets).
 * Configured in Site Settings → Sogand Page Transitions.
 *
 * @package SogandCore
 */

namespace Sogand\Core\Elementor;

use Elementor\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Transitions {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_head', array( $this, 'head' ), 2 );
		add_action( 'wp_body_open', array( $this, 'markup' ), 2 );
		add_action( 'wp_enqueue_scripts', array( $this, 'assets' ) );
	}

	/** Off inside the editor / preview, for logged-in previews of customizer, feeds, etc. */
	private function active() {
		if ( is_admin() || is_feed() || is_embed() || wp_doing_ajax() ) {
			return false;
		}
		if ( isset( $_GET['elementor-preview'] ) || isset( $_GET['preview_id'] ) || isset( $_GET['customize_changeset_uuid'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return false;
		}
		if ( 'yes' !== Kit_Sogand::get( 'sgk_ct_on', 'yes' ) ) {
			return false;
		}
		/* Elementor Pro page transitions active on this page → step aside */
		if ( defined( 'ELEMENTOR_PRO_VERSION' ) && is_singular() ) {
			$doc = Plugin::$instance->documents->get( get_queried_object_id() );
			if ( $doc && $doc->get_settings( 'page_transitions_entrance_animation' ) ) {
				return false;
			}
			$kit_pt = Kit_Sogand::val( 'page_transitions_entrance_animation', '' );
			if ( $kit_pt ) {
				return false;
			}
		}
		return true;
	}

	private function cfg() {
		$logo = Kit_Sogand::get( 'sgk_ct_logo_img', array() );
		$url  = is_array( $logo ) && ! empty( $logo['url'] ) ? $logo['url'] : sgc_asset( 'img/mark-gold.webp' );
		return array(
			'preset'   => sanitize_key( Kit_Sogand::val( 'sgk_ct_preset', 'split-v' ) ),
			'c1'       => sgc_sanitize_color( Kit_Sogand::val( 'sgk_ct_c1', '#4b292c' ), '#4b292c' ),
			'c2'       => sgc_sanitize_color( Kit_Sogand::val( 'sgk_ct_c2', '#3b2b2b' ), '#3b2b2b' ),
			'dur'      => max( 150, min( 3000, (int) Kit_Sogand::size( 'sgk_ct_dur', 420 ) ) ),
			'ease'     => preg_match( '/^(linear|cubic-bezier\([\d.,\s-]+\))$/', (string) Kit_Sogand::val( 'sgk_ct_ease', '' ) ) ? Kit_Sogand::val( 'sgk_ct_ease', 'cubic-bezier(.7,0,.2,1)' ) : 'cubic-bezier(.7,0,.2,1)',
			'logo'     => 'yes' === Kit_Sogand::get( 'sgk_ct_logo', 'yes' ) ? esc_url_raw( $url ) : '',
			'logoSize' => max( 40, min( 480, (int) Kit_Sogand::size( 'sgk_ct_logo_size', 300 ) ) ),
			'spin'     => 'yes' === Kit_Sogand::get( 'sgk_ct_spin', 'yes' ),
			'pulse'    => 'yes' === Kit_Sogand::get( 'sgk_ct_pulse', '' ),
			'name'     => 'yes' === Kit_Sogand::get( 'sgk_ct_name', 'yes' ) ? trim( (string) Kit_Sogand::get( 'sgk_ct_name_text', 'SOGAND ANDALIBAZAR' ) ) : '',
			'pattern'  => 'yes' === Kit_Sogand::get( 'sgk_ct_pattern', '' ),
			'line'     => 'yes' === Kit_Sogand::get( 'sgk_ct_line', 'yes' ) ? sgc_sanitize_color( Kit_Sogand::val( 'sgk_ct_line_c', '#E3C88F' ), '#E3C88F' ) : '',
			'progress' => 'yes' === Kit_Sogand::get( 'sgk_ct_progress', '' ),
		);
	}

	public function assets() {
		if ( ! $this->active() ) {
			return;
		}
		wp_enqueue_style( 'sgc-transition', SGC_URL . 'assets/css/transitions.css', array(), SGC_VERSION );
		wp_enqueue_script( 'sgc-transition', SGC_URL . 'assets/js/transitions.js', array(), SGC_VERSION, true );
		wp_localize_script( 'sgc-transition', 'sgcCurtain', $this->cfg() );
	}

	/** Arriving from a curtain navigation: start covered before the first paint, with a safety timer. */
	public function head() {
		if ( ! $this->active() ) {
			return;
		}
		echo "<script>(function(){try{var t=+sessionStorage.getItem('sg-ct')||0;sessionStorage.removeItem('sg-ct');if(t&&Date.now()-t<8000&&!(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches)){var h=document.documentElement;h.classList.add('sg-ct-arrive');setTimeout(function(){h.classList.remove('sg-ct-arrive')},3000)}}catch(e){}})();</script>\n";
	}

	public function markup() {
		if ( ! $this->active() ) {
			return;
		}
		$c = $this->cfg();
		$style = sprintf(
			'--ct-1:%1$s;--ct-2:%2$s;--ct-dur:%3$dms;--ct-ease:%4$s;--ct-logo:%5$dpx;--ct-line:%6$s',
			$c['c1'],
			$c['c2'],
			$c['dur'],
			$c['ease'],
			$c['logoSize'],
			$c['line'] ? $c['line'] : 'transparent'
		);
		$cls = 'sg-curtain is-idle' . ( $c['spin'] ? ' ct-spin-on' : '' ) . ( $c['pulse'] ? ' ct-pulse-on' : '' ) . ( $c['pattern'] ? ' ct-pattern-on' : '' ) . ( $c['line'] ? '' : ' ct-noline' );
		echo '<div class="' . esc_attr( $cls ) . '" data-preset="' . esc_attr( $c['preset'] ) . '" style="' . esc_attr( $style ) . '" aria-hidden="true">';
		echo '<div class="ct-a"></div><div class="ct-b"></div><div class="ct-s">';
		for ( $i = 0; $i < 6; $i++ ) {
			echo '<i style="--i:' . (int) $i . '"></i>';
		}
		echo '</div><i class="ct-line"></i>';
		if ( $c['progress'] ) {
			echo '<i class="ct-progress"></i>';
		}
		echo '<div class="ct-center">';
		if ( $c['logo'] ) {
			echo '<span class="ct-spin"><img src="' . esc_url( $c['logo'] ) . '" alt="" class="ct-mark" width="' . (int) $c['logoSize'] . '" height="' . (int) round( $c['logoSize'] * 738 / 900 ) . '" decoding="async"></span>';
		}
		if ( $c['name'] ) {
			echo '<span class="ct-name">' . esc_html( $c['name'] ) . '</span>';
		}
		echo '</div></div>';
		/* arriving covered: continue the logo motion from the same angle as on the previous page (before the first paint) */
		echo "<script>(function(){var c=document.querySelector('.sg-curtain');if(!c||!document.documentElement.classList.contains('sg-ct-arrive'))return;c.querySelectorAll('.ct-spin,.ct-mark').forEach(function(n){if(!n.getAnimations)return;n.getAnimations().forEach(function(a){var d=a.effect&&a.effect.getTiming?Number(a.effect.getTiming().duration):0;if(d>0){var t=performance.now(),o=performance.timeOrigin||(Date.now()-t);a.startTime=t-((o+t)%d);}});});})();</script>\n";
	}
}

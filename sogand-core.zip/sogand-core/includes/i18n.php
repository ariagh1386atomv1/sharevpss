<?php
/**
 * Languages.
 *
 * - The website is English and left-to-right, whatever language the WordPress admin uses
 *   (Settings → Sogand Settings → Language).
 * - Sogand’s own admin screens, widgets, controls and Site Settings tabs are Persian
 *   (“Sogand admin in Persian”), also when the WordPress admin itself is English.
 * - Text a visitor can see uses the separate text domain `sogand-site`, which is never
 *   loaded in Persian, so it stays English even while the editor is in Persian.
 *
 * @package SogandCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** A language setting from `sogand_settings` ('1' = on). Read directly: this runs before WordPress is fully loaded. */
function sgc_lang_opt( $key ) {
	$o = get_option( 'sogand_settings', array() );
	return ! is_array( $o ) || ! isset( $o[ $key ] ) || '1' === (string) $o[ $key ];
}

/** True for requests that produce pages visitors see (and Sogand’s own REST route used by the forms). */
function sgc_is_site_request() {
	static $site = null;
	if ( null !== $site ) {
		return $site;
	}
	$site = false;
	if ( is_admin() || ( defined( 'WP_CLI' ) && WP_CLI ) || wp_doing_cron() || ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) ) {
		return $site;
	}
	if ( isset( $GLOBALS['pagenow'] ) && in_array( $GLOBALS['pagenow'], array( 'wp-login.php', 'wp-signup.php', 'wp-activate.php' ), true ) ) {
		return $site;
	}
	$uri    = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	$route  = isset( $_GET['rest_route'] ) ? (string) wp_unslash( $_GET['rest_route'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	$prefix = function_exists( 'rest_get_url_prefix' ) ? rest_get_url_prefix() : 'wp-json';
	if ( '' !== $route || false !== strpos( $uri, '/' . $prefix . '/' ) ) {
		/* REST: only the Sogand forms route is “site”; the block editor and Elementor keep the user’s language */
		$site = false !== strpos( $route . $uri, 'sogand/v1' );
		return $site;
	}
	$site = true;
	return $site;
}

/** Website always English (en_US, left-to-right). */
function sgc_site_locale( $locale ) {
	if ( sgc_is_site_request() && sgc_lang_opt( 'site_en' ) ) {
		return 'en_US';
	}
	return $locale;
}
add_filter( 'locale', 'sgc_site_locale', 1 );

/** Show Sogand’s admin screens, widgets and settings in Persian? */
function sgc_admin_persian() {
	if ( sgc_is_site_request() ) {
		return false;
	}
	return sgc_lang_opt( 'admin_fa' ) || 0 === strpos( (string) get_user_locale(), 'fa' );
}

/** Persian strings shown inside a left-to-right admin need right-to-left text direction. */
function sgc_admin_rtl_text() {
	return sgc_admin_persian() && ! is_rtl();
}

add_action( 'after_setup_theme', function () {
	if ( sgc_admin_persian() ) {
		/* registered for the current locale, so it is used even when the WordPress admin is English */
		load_textdomain( 'sogand-core', SGC_DIR . 'languages/sogand-core-fa_IR.mo' );
	} elseif ( ! sgc_is_site_request() ) {
		load_plugin_textdomain( 'sogand-core', false, dirname( plugin_basename( SGC_FILE ) ) . '/languages' );
	}
}, 0 );

/* Persian labels inside an English (left-to-right) Elementor editor read right-to-left */
add_action( 'elementor/editor/after_enqueue_styles', function () {
	if ( ! sgc_admin_rtl_text() ) {
		return;
	}
	wp_add_inline_style( 'elementor-editor', '.elementor-control-title,.elementor-control-field-description,.elementor-descriptor,.elementor-panel-heading-title,.elementor-control-raw-html,.elementor-element .title,.elementor-panel-category-title,.elementor-control-type-section .elementor-panel-heading-title{unicode-bidi:plaintext;text-align:start}.elementor-control-field-description,.elementor-control-raw-html{direction:rtl;text-align:right}' );
} );

/* Plugin header (Plugins screen) — listed here so the translation tools pick it up. */
if ( false ) {
	__( 'Sogand Core', 'sogand-core' );
	__( 'Portfolio content, Elementor widgets, shared style and motion controls, page transitions, forms and the template library for the Sogand theme.', 'sogand-core' );
	__( 'Sogand Andalibazar', 'sogand-core' );
}

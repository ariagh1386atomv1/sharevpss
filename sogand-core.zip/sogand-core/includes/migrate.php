<?php
/**
 * Moving a Sogand 7 site (Studio) to Sogand 8 (Elementor).
 *
 * Nothing of Sogand 7 is deleted or changed in place: its options stay untouched, an
 * extra inert copy is stored once in the option `sgc_v7_backup` (not autoloaded), and
 * every page the importer fills keeps a snapshot of its previous content. Restoring
 * puts the pages, the front page and Site Settings back the way they were.
 *
 * What carries over automatically: portfolio entries, collections and their URLs
 * (same post type / taxonomy / slugs), inquiries, the contact & mail settings, the
 * logo / signature pictures, and the wording edited in the Studio or the Customizer
 * wherever the new templates contain the same default sentence.
 *
 * @package SogandCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Is Sogand 7 data present? */
function sgc_legacy_detect() {
	$studio = get_option( 'sogand_studio', array() );
	$mods   = get_option( 'theme_mods_sogand', array() );
	$pages  = get_posts( array(
		'post_type'   => 'page',
		'post_status' => 'any',
		'numberposts' => 20,
		'fields'      => 'ids',
		'meta_key'    => '_sogand_view', // phpcs:ignore WordPress.DB.SlowDBQuery
	) );
	$works  = (int) wp_count_posts( 'sg_work' )->publish;
	return array(
		'studio'    => is_array( $studio ) && ! empty( $studio ),
		'mods'      => is_array( $mods ) && ! empty( $mods ),
		'pages'     => $pages,
		'works'     => $works,
		'any'       => ( is_array( $studio ) && ! empty( $studio ) ) || ! empty( $pages ) || ( is_array( $mods ) && ! empty( $mods['sogand_hero_title'] ) ),
		'backed_up' => (bool) get_option( 'sgc_v7_backup' ),
	);
}

/** One inert copy of everything Sogand 7 kept in options (taken once, never overwritten). */
function sgc_legacy_backup() {
	if ( get_option( 'sgc_v7_backup' ) ) {
		return false;
	}
	$copy = array( 'time' => time(), 'options' => array() );
	foreach ( array( 'sogand_studio', 'sogand_studio_rev', 'sogand_settings', 'sogand_perf', 'theme_mods_sogand', 'show_on_front', 'page_on_front', 'page_for_posts', 'template', 'stylesheet' ) as $k ) {
		$v = get_option( $k, null );
		if ( null !== $v ) {
			$copy['options'][ $k ] = $v;
		}
	}
	/* history can be large: keep only its size, the live option itself is untouched */
	$hist = get_option( 'sogand_studio_history', null );
	if ( null !== $hist ) {
		$copy['history_entries'] = is_array( $hist ) ? count( $hist ) : 0;
	}
	return add_option( 'sgc_v7_backup', $copy, '', false );
}

/** Default wording of Sogand 7 for each Customizer field (theme_mods_sogand). */
function sgc_legacy_mod_defaults() {
	return array(
		'hero_eyebrow'     => 'Sogand Andalibazar — Jewelry Designer',
		'hero_title'       => 'Jewelry, imagined beyond the ordinary',
		'services_eyebrow' => 'What I do',
		'services_title'   => 'From first spark to finished piece',
		'services_text'    => 'A considered process that carries an idea from a fleeting sketch to a piece ready for the bench — or a visual ready for the world.',
		'service_1_title'  => 'Design & Ideation',
		'service_1_text'   => 'From a fleeting thought to a refined concept — sketches, moodboards and design directions shaped around a story.',
		'service_2_title'  => 'Bespoke Jewelry',
		'service_2_text'   => 'One-of-a-kind pieces designed with you, around your story, your stones and the way you live.',
		'service_3_title'  => 'Digital Rendering',
		'service_3_text'   => 'Hand-crafted digital illustrations that present a design with the warmth and nuance of traditional gouache.',
		'service_4_title'  => '3D Modeling',
		'service_4_text'   => 'Precise, production-ready models and photorealistic visuals of metal, light and stone — for casting, presentations and campaigns.',
		'service_5_title'  => 'Custom Procreate Brush Creation',
		'service_5_text'   => 'Bespoke Procreate brushes for jewelry artists — metals, gems and textures that render beautifully.',
		'about_eyebrow'    => 'About',
		'about_name'       => 'Sogand Andalibazar',
		'about_role'       => 'Jewelry Designer & Creative Artist',
		'about_quote'      => 'The most compelling creations are not simply beautiful; they have a point of view.',
		'cta_eyebrow'      => 'Stay inspired',
		'cta_title'        => 'Join the Journey',
		'cta_text'         => 'Be the first to know about new collections, collaborations and private viewing dates. Leave your email and step inside the world of Sogand Jewelry.',
		'cta_note'         => 'Receive design notes, launch previews and limited edition announcements.',
		'topbar'           => 'Bespoke commissions by private appointment',
	);
}

/** Default wording of the texts that could be typed on the page in the Studio (key => default). */
function sgc_legacy_text_defaults() {
	return array(
		'services.btn'      => 'All services',
		'svc.more'          => 'Explore',
		'journey.title'     => 'Join the Journey',
		'journey.eyebrow'   => 'Stay inspired',
		'journey.text'      => 'Be the first to know about new collections, collaborations and private viewing dates. Leave your email and step inside the world of Sogand Jewelry.',
		'journey.note'      => 'Receive design notes, launch previews and limited edition announcements.',
		'journey.btn'       => 'Subscribe',
		'journey.label'     => 'Enter your email',
		'journey.contact'   => 'Contact form',
		'process.eyebrow'   => 'How we work together',
		'process.title'     => 'A quiet, considered process',
		'work.btn1'         => 'Inquire about this piece',
		'work.btn2'         => 'Commission something similar',
		'contact.eyebrow2'  => 'Studio',
		'contact.h2'        => 'Write to me',
		'contact.body'      => 'Private viewings and consultations are by appointment, in person or online.',
		'footer.ctaEyebrow' => 'Commissions',
		'footer.ctaBtn'     => 'Start a commission',
		'footer.h1'         => 'Explore',
		'footer.h2'         => 'Services',
		'footer.h3'         => 'Studio',
		'footer.h4'         => 'Join the Journey',
		'footer.note'       => 'Private viewing by appointment',
		'footer.nlText'     => 'Design notes, new collections and private viewing dates — rarely, and beautifully.',
		'header.cta'        => 'Book a consultation',
		'coll.empty'        => 'New pieces are on their way.',
		'coll.all'          => 'All works',
		'404.home'          => 'Return home',
		'form.send'         => 'Send message',
		'form.thanks'       => 'Thank you',
		'form.browse'       => 'Browse collections',
		'form.again'        => 'Send another',
		'mega.browse'       => 'Browse',
		'mega.note'         => 'Commission a bespoke piece',
		'topbar.text'       => 'Bespoke commissions by private appointment',
	);
}

/**
 * Wording changed in Sogand 7, as default sentence => the owner's sentence.
 * Used by the importer to replace exact matches inside the new templates.
 */
function sgc_legacy_text_map() {
	$map  = array();
	$mods = get_option( 'theme_mods_sogand', array() );
	$mods = is_array( $mods ) ? $mods : array();
	foreach ( sgc_legacy_mod_defaults() as $k => $default ) {
		if ( isset( $mods[ 'sogand_' . $k ] ) ) {
			$v = trim( wp_strip_all_tags( (string) $mods[ 'sogand_' . $k ] ) );
			if ( '' !== $v && $v !== $default ) {
				$map[ $default ] = $v;
			}
		}
	}
	$studio = get_option( 'sogand_studio', array() );
	$tx     = ( is_array( $studio ) && isset( $studio['tx'] ) && is_array( $studio['tx'] ) ) ? $studio['tx'] : array();
	foreach ( sgc_legacy_text_defaults() as $k => $default ) {
		if ( isset( $tx[ $k ] ) && is_scalar( $tx[ $k ] ) ) {
			$v = trim( wp_strip_all_tags( (string) $tx[ $k ] ) );
			if ( '' !== $v && $v !== $default ) {
				$map[ $default ] = $v;
			}
		}
	}
	/* builder pages: hero / services header / about texts typed in the Studio */
	$pages = ( is_array( $studio ) && isset( $studio['pages'] ) && is_array( $studio['pages'] ) ) ? $studio['pages'] : array();
	$defaults = array(
		'hero'    => array( 'eyebrow' => 'Sogand Andalibazar — Jewelry Designer', 'title' => 'Jewelry, imagined beyond the ordinary', 'btn1' => 'Explore collections', 'btn2' => 'Services' ),
		'svchero' => array( 'eyebrow' => 'Services', 'title' => 'From first spark to finished piece', 'text' => 'A considered process that carries an idea from a fleeting sketch to a piece ready for the bench — or a visual ready for the world.' ),
	);
	foreach ( $pages as $doc ) {
		foreach ( sgc_legacy_widgets( isset( $doc['els'] ) ? $doc['els'] : array() ) as $w ) {
			if ( ! isset( $defaults[ $w['t'] ] ) ) {
				continue;
			}
			foreach ( $defaults[ $w['t'] ] as $f => $default ) {
				if ( isset( $w['s'][ $f ] ) && is_scalar( $w['s'][ $f ] ) ) {
					$v = trim( wp_strip_all_tags( (string) $w['s'][ $f ] ) );
					if ( '' !== $v && $v !== $default && ! isset( $map[ $default ] ) ) {
						$map[ $default ] = $v;
					}
				}
			}
		}
	}
	/* the removed hero sentence must never come back */
	foreach ( $map as $k => $v ) {
		if ( 'conceptdesignbespokepiecesanddigitalartistryeverydesignshapedbyartarchitectureandfeeling' === strtolower( preg_replace( '/[^a-z]+/i', '', $v ) ) ) {
			unset( $map[ $k ] );
		}
	}
	return $map;
}

/** Flatten Studio builder elements to widgets. */
function sgc_legacy_widgets( $els ) {
	$out = array();
	foreach ( (array) $els as $el ) {
		if ( ! is_array( $el ) || empty( $el['t'] ) ) {
			continue;
		}
		if ( 'container' !== $el['t'] ) {
			$out[] = array( 't' => $el['t'], 's' => isset( $el['s'] ) && is_array( $el['s'] ) ? $el['s'] : array() );
		}
		if ( ! empty( $el['c'] ) ) {
			$out = array_merge( $out, sgc_legacy_widgets( $el['c'] ) );
		}
	}
	return $out;
}

/**
 * The layouts chosen in Sogand 7, translated to the matching Sogand 8 presets.
 *
 * @return array role => preset id (only roles with a known choice).
 */
function sgc_legacy_presets() {
	$studio = get_option( 'sogand_studio', array() );
	$pages  = ( is_array( $studio ) && isset( $studio['pages'] ) && is_array( $studio['pages'] ) ) ? $studio['pages'] : array();
	$heroes = array( 'split-fade', 'classic', 'fullbleed', 'centered', 'editorial', 'arch', 'circle', 'diagonal', 'marquee', 'stack', 'spotlight', 'lines', 'mosaic', 'video', 'slider', 'orbs', 'frame', 'halves', 'magazine', 'layers', 'aurora', 'vault', 'blinds', 'slices', 'glasscard', 'ticker', 'constellation', 'pedestal', 'portal', 'ribbon', 'cascade', 'monogram', 'prism', 'hourglass', 'velvet', 'panorama', 'gallerywall', 'kaleido', 'neon', 'curtainrise' );
	$out    = array();
	$find   = function ( $page, $type ) use ( $pages ) {
		if ( empty( $pages[ $page ]['els'] ) ) {
			return null;
		}
		foreach ( sgc_legacy_widgets( $pages[ $page ]['els'] ) as $w ) {
			if ( $w['t'] === $type ) {
				return $w['s'];
			}
		}
		return null;
	};
	$h = $find( 'home', 'hero' );
	if ( $h && ! empty( $h['variant'] ) ) {
		$i = array_search( $h['variant'], $heroes, true );
		if ( false !== $i ) {
			$out['home'] = sprintf( 'home-%02d', $i + 1 );
		}
	}
	$s = $find( 'services', 'svchero' );
	if ( $s && ! empty( $s['layout'] ) && preg_match( '/^([ni])(\d+)$/', $s['layout'], $m ) ) {
		$n = (int) $m[2] + ( 'i' === $m[1] ? 20 : 0 );
		if ( $n >= 1 && $n <= 40 ) {
			$out['services'] = sprintf( 'services-%02d', $n );
		}
	}
	$a = $find( 'about', 'aboutdemo' );
	if ( $a && ! empty( $a['demo'] ) && preg_match( '/^a(\d+)$/', $a['demo'], $m ) && (int) $m[1] >= 1 && (int) $m[1] <= 40 ) {
		$out['about'] = sprintf( 'about-%02d', (int) $m[1] );
	}
	return $out;
}

/** Studio changes that cannot be carried into Elementor automatically (shown on the setup screen). */
function sgc_legacy_leftovers() {
	$studio = get_option( 'sogand_studio', array() );
	if ( ! is_array( $studio ) ) {
		return array();
	}
	$out = array();
	if ( ! empty( $studio['el'] ) ) {
		$out[] = sprintf( /* translators: %d: count */ __( '%d element style changes made in the Studio (colours, spacing, sizes of single elements). Re-apply the ones you want with the Elementor controls.', 'sogand-core' ), count( (array) $studio['el'] ) );
	}
	if ( ! empty( $studio['v']['ex.css'] ) ) {
		$out[] = __( 'Custom CSS from the Studio. It targeted Sogand 7 class names, so it is not applied; it is kept in the backup.', 'sogand-core' );
	}
	if ( ! empty( $studio['v']['ex.head'] ) || ! empty( $studio['v']['ex.foot'] ) ) {
		$out[] = __( 'Extra code for <head> / before </body> (for example analytics) was copied to Sogand → Setup → Extra code. Check it there.', 'sogand-core' );
	}
	if ( ! empty( $studio['hide'] ) ) {
		$out[] = sprintf( __( '%d hidden elements. Sections are now separate Elementor elements: delete or hide the ones you do not want.', 'sogand-core' ), count( (array) $studio['hide'] ) );
	}
	if ( ! empty( $studio['dup'] ) ) {
		$out[] = __( 'Duplicated widgets from the Studio. Duplicate the matching Elementor elements again where you need them.', 'sogand-core' );
	}
	return $out;
}

/** Carry the extra head / footer code over (kept inactive until saved by an administrator). */
function sgc_legacy_copy_code() {
	$studio = get_option( 'sogand_studio', array() );
	if ( ! is_array( $studio ) || get_option( 'sgc_code' ) ) {
		return;
	}
	$head = isset( $studio['v']['ex.head'] ) ? (string) $studio['v']['ex.head'] : '';
	$foot = isset( $studio['v']['ex.foot'] ) ? (string) $studio['v']['ex.foot'] : '';
	if ( '' !== $head || '' !== $foot ) {
		add_option( 'sgc_code', array( 'head' => $head, 'foot' => $foot, 'on' => '0' ), '', false );
	}
}

/** Put the site back: pages to their first snapshot, front page and Site Settings as before. */
function sgc_restore_all() {
	$n = 0;
	foreach ( array_keys( sgc_page_roles() ) as $role ) {
		$pid = (int) get_option( 'sgc_page_' . $role );
		if ( $pid && sgc_restore_page( $pid, 'first' ) ) {
			$n++;
		}
	}
	$b = get_option( 'sgc_v7_backup' );
	if ( is_array( $b ) && isset( $b['options'] ) ) {
		foreach ( array( 'show_on_front', 'page_on_front', 'page_for_posts' ) as $k ) {
			if ( isset( $b['options'][ $k ] ) ) {
				update_option( $k, $b['options'][ $k ] );
			}
		}
	}
	$ml = get_option( 'sgc_v7_menu_locations' );
	if ( is_array( $ml ) ) {
		set_theme_mod( 'nav_menu_locations', array_merge( (array) get_theme_mod( 'nav_menu_locations', array() ), $ml ) );
		delete_option( 'sgc_v7_menu_locations' );
	}
	$kb = get_option( 'sgc_kit_backup' );
	if ( is_array( $kb ) && ! empty( $kb['kit'] ) && class_exists( '\Elementor\Plugin' ) ) {
		update_post_meta( (int) $kb['kit'], '_elementor_page_settings', $kb['settings'] );
		\Elementor\Plugin::$instance->files_manager->clear_cache();
	}
	return $n;
}

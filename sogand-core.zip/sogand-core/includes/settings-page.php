<?php
/**
 * Settings → Sogand Settings: language, the site's contact details (used by the contact
 * widgets as their default values) and how form messages are delivered.
 * This is a standard WordPress settings screen — design lives in Elementor.
 *
 * @package SogandCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_menu', function () {
	add_options_page(
		__( 'Sogand Settings', 'sogand-core' ),
		__( 'Sogand Settings', 'sogand-core' ),
		'manage_options',
		'sgc-contact',
		'sgc_settings_page'
	);
} );

add_action( 'admin_init', function () {
	register_setting( 'sogand_settings', 'sogand_settings', array(
		'type'              => 'array',
		'sanitize_callback' => 'sgc_sanitize_settings',
		'default'           => array(),
	) );
} );

function sgc_sanitize_settings( $in ) {
	$in  = is_array( $in ) ? $in : array();
	$old = get_option( 'sogand_settings', array() );
	$old = is_array( $old ) ? $old : array();
	$out = array();
	foreach ( sgc_setting_defaults() as $k => $v ) {
		$val = isset( $in[ $k ] ) ? wp_unslash( $in[ $k ] ) : '';
		if ( in_array( $k, array( 'site_email', 'inbox_email', 'from_email' ), true ) ) {
			$val = sanitize_email( $val );
		} elseif ( 'smtp_user' === $k ) {
			$val = sanitize_text_field( $val );
		} elseif ( in_array( $k, array( 'phone', 'whatsapp' ), true ) ) {
			$val = trim( preg_replace( '/[^0-9+()\-\s]/', '', (string) $val ) );
		} elseif ( 'instagram_url' === $k ) {
			$val = esc_url_raw( $val );
		} elseif ( in_array( $k, array( 'smtp_on', 'autoreply_on', 'site_en', 'admin_fa' ), true ) ) {
			$val = empty( $in[ $k ] ) ? '0' : '1';
		} elseif ( in_array( $k, array( 'smtp_pass', 'turnstile_secret' ), true ) ) {
			/* secrets: an empty field keeps the saved value */
			$val = ( '' === $val && isset( $old[ $k ] ) ) ? $old[ $k ] : (string) $val;
		} elseif ( 'smtp_port' === $k ) {
			$val = (string) absint( $val );
		} elseif ( 'smtp_secure' === $k ) {
			$val = in_array( $val, array( 'ssl', 'tls', '' ), true ) ? $val : 'ssl';
		} else {
			$val = sanitize_text_field( $val );
		}
		if ( 'instagram_handle' === $k ) {
			$val = ltrim( $val, '@' );
		}
		$out[ $k ] = $val;
	}
	return $out;
}

function sgc_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$s = wp_parse_args( get_option( 'sogand_settings', array() ), sgc_setting_defaults() );
	$f = function ( $k, $label, $type = 'text', $help = '' ) use ( $s ) {
		$secret = in_array( $k, array( 'smtp_pass', 'turnstile_secret' ), true );
		$v      = $secret ? '' : $s[ $k ];
		echo '<tr><th scope="row"><label for="sgc-' . esc_attr( $k ) . '">' . esc_html( $label ) . '</label></th><td>';
		if ( 'checkbox' === $type ) {
			echo '<label><input type="checkbox" id="sgc-' . esc_attr( $k ) . '" name="sogand_settings[' . esc_attr( $k ) . ']" value="1" ' . checked( $s[ $k ], '1', false ) . '> ' . esc_html( $help ) . '</label>';
		} elseif ( 'secure' === $type ) {
			echo '<select id="sgc-' . esc_attr( $k ) . '" name="sogand_settings[' . esc_attr( $k ) . ']">';
			foreach ( array( 'ssl' => 'SSL', 'tls' => 'TLS (STARTTLS)', '' => __( 'None', 'sogand-core' ) ) as $ov => $ol ) {
				echo '<option value="' . esc_attr( $ov ) . '" ' . selected( $s[ $k ], $ov, false ) . '>' . esc_html( $ol ) . '</option>';
			}
			echo '</select>';
		} else {
			$ph = $secret && ! empty( $s[ $k ] ) ? __( '•••••••• (saved — leave empty to keep)', 'sogand-core' ) : '';
			echo '<input class="regular-text" type="' . esc_attr( $type ) . '" id="sgc-' . esc_attr( $k ) . '" name="sogand_settings[' . esc_attr( $k ) . ']" value="' . esc_attr( $v ) . '"' . ( 'from_name' === $k ? '' : ' dir="ltr"' ) . ( $secret ? ' autocomplete="new-password" placeholder="' . esc_attr( $ph ) . '"' : '' ) . '>';
			if ( $help ) {
				echo '<p class="description">' . esc_html( $help ) . '</p>';
			}
		}
		echo '</td></tr>';
	};
	$test = isset( $_GET['sgc_test'] ) ? sanitize_key( wp_unslash( $_GET['sgc_test'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	?>
	<div class="wrap"<?php echo sgc_admin_rtl_text() ? ' dir="rtl"' : ''; ?>>
		<h1><?php esc_html_e( 'Sogand Settings', 'sogand-core' ); ?></h1>
		<?php if ( $test ) : ?>
			<div class="notice <?php echo 'ok' === $test ? 'notice-success' : 'notice-error'; ?>"><p>
				<?php
				if ( 'ok' === $test ) {
					esc_html_e( 'The test email was accepted by the mail server. Check the inbox (and spam folder) to confirm it was delivered.', 'sogand-core' );
				} else {
					$err = get_transient( 'sgc_mail_error' );
					echo esc_html( $err ? $err : __( 'The test email could not be handed to the mail server.', 'sogand-core' ) );
				}
				?>
			</p></div>
		<?php endif; ?>
		<form method="post" action="options.php">
			<?php settings_fields( 'sogand_settings' ); ?>
			<h2><?php esc_html_e( 'Language', 'sogand-core' ); ?></h2>
			<table class="form-table" role="presentation"><tbody>
				<?php
				$f( 'site_en', __( 'Website language', 'sogand-core' ), 'checkbox', __( 'Always show the website in English, left to right — even when the WordPress admin is in Persian', 'sogand-core' ) );
				$f( 'admin_fa', __( 'Sogand admin language', 'sogand-core' ), 'checkbox', __( 'Show the Sogand screens, Elementor widgets, their settings and Site Settings in Persian', 'sogand-core' ) );
				?>
			</tbody></table>
			<h2><?php esc_html_e( 'Contact details', 'sogand-core' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Used as default values by the Sogand contact, footer and header elements. Every element can still override its own text in Elementor.', 'sogand-core' ); ?></p>
			<table class="form-table" role="presentation"><tbody>
				<?php
				$f( 'site_email', __( 'Email shown on the site', 'sogand-core' ), 'email' );
				$f( 'phone', __( 'Phone', 'sogand-core' ), 'tel', __( 'e.g. +968 99161823 — leave empty to hide.', 'sogand-core' ) );
				$f( 'whatsapp', __( 'WhatsApp number', 'sogand-core' ), 'tel', __( 'Optional, with country code.', 'sogand-core' ) );
				$f( 'instagram_handle', __( 'Instagram handle', 'sogand-core' ), 'text', 'JEWELYBYSOGAND' );
				$f( 'instagram_url', __( 'Instagram link', 'sogand-core' ), 'url' );
				?>
			</tbody></table>
			<h2><?php esc_html_e( 'Form messages', 'sogand-core' ); ?></h2>
			<p class="description">
				<?php
				printf(
					/* translators: %s: primary email address */
					esc_html__( 'Every inquiry and newsletter request is saved under Inquiries and emailed to %s. Recipients are set here on the server — never by the visitor’s browser.', 'sogand-core' ),
					'<code>' . esc_html( SGC_PRIMARY_EMAIL ) . '</code>'
				);
				?>
			</p>
			<table class="form-table" role="presentation"><tbody>
				<?php
				$f( 'inbox_email', __( 'Also send a copy to (optional)', 'sogand-core' ), 'email' );
				$f( 'autoreply_on', __( 'Auto-reply', 'sogand-core' ), 'checkbox', __( 'Send the visitor a short “your message has arrived” email', 'sogand-core' ) );
				$f( 'turnstile_site', __( 'Cloudflare Turnstile site key (optional)', 'sogand-core' ), 'text', __( 'Adds an invisible spam check to the Sogand forms. The honeypot, timing check and rate limit always stay on.', 'sogand-core' ) );
				$f( 'turnstile_secret', __( 'Cloudflare Turnstile secret key', 'sogand-core' ), 'password' );
				?>
			</tbody></table>
			<h2><?php esc_html_e( 'Sending email', 'sogand-core' ); ?></h2>
			<p class="description"><?php esc_html_e( 'For reliable delivery to your cPanel mailbox, switch on SMTP and enter the account details from cPanel → Email Accounts → Connect Devices. Leave off if another plugin already handles SMTP.', 'sogand-core' ); ?></p>
			<table class="form-table" role="presentation"><tbody>
				<?php
				$f( 'from_name', __( 'From name', 'sogand-core' ) );
				$f( 'from_email', __( 'From email', 'sogand-core' ), 'email', __( 'Use an address on your own domain so messages are not marked as spam.', 'sogand-core' ) );
				$f( 'smtp_on', __( 'Use SMTP', 'sogand-core' ), 'checkbox', __( 'Send through your mail server', 'sogand-core' ) );
				$f( 'smtp_host', __( 'SMTP host', 'sogand-core' ), 'text', 'mail.sogandjewel.com' );
				$f( 'smtp_port', __( 'SMTP port', 'sogand-core' ), 'number', __( '465 (SSL) or 587 (TLS)', 'sogand-core' ) );
				$f( 'smtp_secure', __( 'Encryption', 'sogand-core' ), 'secure' );
				$f( 'smtp_user', __( 'SMTP username', 'sogand-core' ) );
				$f( 'smtp_pass', __( 'SMTP password', 'sogand-core' ), 'password' );
				?>
			</tbody></table>
			<?php submit_button(); ?>
		</form>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="sgc_test_mail">
			<?php wp_nonce_field( 'sgc_test_mail' ); ?>
			<?php submit_button( __( 'Send a test email', 'sogand-core' ), 'secondary' ); ?>
		</form>
	</div>
	<?php
}

/* SMTP + From headers for every wp_mail (only when configured here) */
add_action( 'phpmailer_init', function ( $mailer ) {
	$from = sanitize_email( sgc_setting( 'from_email' ) );
	if ( is_email( $from ) ) {
		$mailer->setFrom( $from, sgc_setting( 'from_name' ), false );
		$mailer->Sender = $from; // phpcs:ignore WordPress.NamingConventions.ValidVariableName
	}
	if ( '1' !== sgc_setting( 'smtp_on' ) || ! sgc_setting( 'smtp_host' ) ) {
		return;
	}
	$mailer->isSMTP();
	// phpcs:disable WordPress.NamingConventions.ValidVariableName
	$mailer->Host       = sgc_setting( 'smtp_host' );
	$mailer->Port       = (int) sgc_setting( 'smtp_port' );
	$mailer->SMTPSecure = in_array( sgc_setting( 'smtp_secure' ), array( 'ssl', 'tls' ), true ) ? sgc_setting( 'smtp_secure' ) : '';
	$mailer->SMTPAuth   = true;
	$mailer->Username   = sgc_setting( 'smtp_user' );
	$mailer->Password   = sgc_setting( 'smtp_pass' );
	$mailer->Timeout    = 15;
	// phpcs:enable
} );

add_action( 'wp_mail_failed', function ( $err ) {
	set_transient( 'sgc_mail_error', $err->get_error_message(), 10 * MINUTE_IN_SECONDS );
} );

add_action( 'admin_post_sgc_test_mail', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'sgc_test_mail' ) ) {
		wp_die( esc_html__( 'You are not allowed to do this.', 'sogand-core' ) );
	}
	$ok = wp_mail( sgc_inquiry_recipients(), '[' . wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) . '] Test email', "This is a test from Settings → Sogand Settings.\nIf you can read this in your inbox, form messages will arrive here too." );
	wp_safe_redirect( admin_url( 'options-general.php?page=sgc-contact&sgc_test=' . ( $ok ? 'ok' : 'fail' ) ) );
	exit;
} );

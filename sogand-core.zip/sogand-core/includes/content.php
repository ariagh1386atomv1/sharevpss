<?php
/**
 * Portfolio (sg_work), collections taxonomy (sg_collection), inquiries (sg_inquiry)
 * and the work details box. Identifiers are kept from earlier Sogand versions so
 * existing content, URLs and metadata stay as they are.
 *
 * @package SogandCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function sgc_register_content() {
	register_post_type( 'sg_work', array(
		'labels'        => array(
			'name'               => __( 'Works', 'sogand-core' ),
			'singular_name'      => __( 'Work', 'sogand-core' ),
			'add_new_item'       => __( 'Add new work', 'sogand-core' ),
			'edit_item'          => __( 'Edit work', 'sogand-core' ),
			'new_item'           => __( 'New work', 'sogand-core' ),
			'view_item'          => __( 'View work', 'sogand-core' ),
			'all_items'          => __( 'All works', 'sogand-core' ),
			'search_items'       => __( 'Search works', 'sogand-core' ),
			'not_found'          => __( 'No works found.', 'sogand-core' ),
			'menu_name'          => __( 'Works', 'sogand-core' ),
			'featured_image'     => __( 'Main image (1024 × 1024 recommended)', 'sogand-core' ),
			'set_featured_image' => __( 'Set main image', 'sogand-core' ),
		),
		'public'        => true,
		'has_archive'   => false, /* the Collections page lists the works */
		'rewrite'       => array( 'slug' => 'collections', 'with_front' => false ),
		'menu_icon'     => 'dashicons-star-filled',
		'menu_position' => 5,
		'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes', 'elementor' ),
		'show_in_rest'  => true,
	) );

	register_taxonomy( 'sg_collection', 'sg_work', array(
		'labels'            => array(
			'name'          => __( 'Collections', 'sogand-core' ),
			'singular_name' => __( 'Collection', 'sogand-core' ),
			'add_new_item'  => __( 'Add new collection', 'sogand-core' ),
			'edit_item'     => __( 'Edit collection', 'sogand-core' ),
			'search_items'  => __( 'Search collections', 'sogand-core' ),
			'menu_name'     => __( 'Collections', 'sogand-core' ),
		),
		'hierarchical'      => true, /* checkbox list on the work screen, like WooCommerce product categories */
		'public'            => true,
		'show_admin_column' => true,
		'show_in_rest'      => true,
		'rewrite'           => array( 'slug' => 'collection' ),
	) );

	register_post_type( 'sg_inquiry', array(
		'labels'          => array(
			'name'          => __( 'Inquiries', 'sogand-core' ),
			'singular_name' => __( 'Inquiry', 'sogand-core' ),
			'menu_name'     => __( 'Inquiries', 'sogand-core' ),
		),
		'public'          => false,
		'show_ui'         => true,
		'menu_icon'       => 'dashicons-email-alt',
		'menu_position'   => 26,
		'supports'        => array( 'title', 'editor' ),
		'capability_type' => 'post',
		'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
		'map_meta_cap'    => true,
	) );

	foreach ( array( 'materials', 'gemstones', 'technique', 'year', 'tone', 'featured', 'gallery' ) as $k ) {
		register_post_meta( 'sg_work', '_sg_' . $k, array(
			'type'          => 'string',
			'single'        => true,
			'show_in_rest'  => false,
			'auth_callback' => function () {
				return current_user_can( 'edit_posts' );
			},
		) );
	}
}
add_action( 'init', 'sgc_register_content', 5 );

/* 1024 × 1024 card template (no crop: the whole piece is always visible) */
add_action( 'after_setup_theme', function () {
	add_image_size( 'sogand-square', 1024, 1024, false );
}, 20 );

/* -------------------------------------------------------------------------
 * Work details box
 * ---------------------------------------------------------------------- */
function sgc_work_fields() {
	return array(
		'materials' => __( 'Materials', 'sogand-core' ),
		'gemstones' => __( 'Gemstones', 'sogand-core' ),
		'technique' => __( 'Technique (e.g. 3D Modeling)', 'sogand-core' ),
		'year'      => __( 'Year', 'sogand-core' ),
	);
}

function sgc_work_specs( $post_id ) {
	$raw = json_decode( (string) get_post_meta( $post_id, '_sg_specs', true ), true );
	$out = array();
	if ( is_array( $raw ) ) {
		foreach ( $raw as $sp ) {
			if ( is_array( $sp ) && ( ! empty( $sp['title'] ) || ! empty( $sp['value'] ) ) ) {
				$out[] = array(
					'title' => (string) ( isset( $sp['title'] ) ? $sp['title'] : '' ),
					'value' => (string) ( isset( $sp['value'] ) ? $sp['value'] : '' ),
				);
			}
		}
	}
	return $out;
}

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'sgc_work', __( 'Work details', 'sogand-core' ), 'sgc_work_box', 'sg_work', 'normal', 'high' );
} );

function sgc_work_box( $post ) {
	wp_nonce_field( 'sgc_work', 'sgc_work_nonce' );
	echo '<table class="form-table" role="presentation"><tbody>';
	foreach ( sgc_work_fields() as $key => $label ) {
		$v = get_post_meta( $post->ID, '_sg_' . $key, true );
		printf(
			'<tr><th><label for="sg_%1$s">%2$s</label></th><td><input type="text" class="regular-text" id="sg_%1$s" name="sg_%1$s" value="%3$s"></td></tr>',
			esc_attr( $key ),
			esc_html( $label ),
			esc_attr( $v )
		);
	}
	$tone = (string) get_post_meta( $post->ID, '_sg_tone', true );
	printf(
		'<tr><th><label for="sg_tone">%1$s</label></th><td><input type="text" id="sg_tone" name="sg_tone" value="%2$s" class="sgc-color" data-default-color=""><p class="description">%3$s</p></td></tr>',
		esc_html__( 'Halo colour', 'sogand-core' ),
		esc_attr( $tone ),
		esc_html__( 'The coloured light behind this piece in cards, sliders and the gallery. Leave empty for the automatic colour.', 'sogand-core' )
	);
	$featured = get_post_meta( $post->ID, '_sg_featured', true );
	printf(
		'<tr><th>%1$s</th><td><label><input type="checkbox" name="sg_featured" value="1" %2$s> %3$s</label></td></tr>',
		esc_html__( 'Featured', 'sogand-core' ),
		checked( $featured, '1', false ),
		esc_html__( 'Offer this piece first in sliders that show featured works', 'sogand-core' )
	);
	$gallery = get_post_meta( $post->ID, '_sg_gallery', true );
	echo '<tr><th>' . esc_html__( 'Gallery', 'sogand-core' ) . '</th><td>';
	echo '<input type="hidden" id="sg_gallery" name="sg_gallery" value="' . esc_attr( $gallery ) . '">';
	echo '<div id="sg_gallery_preview" class="sgc-gallery-preview">';
	foreach ( sgc_work_gallery_ids( $post->ID ) as $id ) {
		echo wp_get_attachment_image( $id, array( 70, 70 ) );
	}
	echo '</div><button type="button" class="button" id="sg_gallery_btn">' . esc_html__( 'Choose gallery images', 'sogand-core' ) . '</button> ';
	echo '<button type="button" class="button-link" id="sg_gallery_clear">' . esc_html__( 'Clear', 'sogand-core' ) . '</button>';
	echo '<p class="description">' . esc_html__( 'Extra images for the gallery on the work page (the main image is always first). Drag in the media window to reorder.', 'sogand-core' ) . '</p></td></tr>';

	echo '<tr><th>' . esc_html__( 'More details', 'sogand-core' ) . '</th><td><div id="sg_specs">';
	$row = function ( $i, $t, $v ) {
		return '<div class="sg-spec">'
			. '<input type="text" placeholder="' . esc_attr__( 'Title (e.g. Carat)', 'sogand-core' ) . '" name="sg_specs[' . $i . '][title]" value="' . esc_attr( $t ) . '">'
			. '<input type="text" placeholder="' . esc_attr__( 'Value (e.g. 2.4 ct)', 'sogand-core' ) . '" name="sg_specs[' . $i . '][value]" value="' . esc_attr( $v ) . '">'
			. '<button type="button" class="button sg-spec-up" aria-label="' . esc_attr__( 'Move up', 'sogand-core' ) . '">↑</button><button type="button" class="button sg-spec-del" aria-label="' . esc_attr__( 'Remove', 'sogand-core' ) . '">✕</button></div>';
	};
	foreach ( sgc_work_specs( $post->ID ) as $i => $sp ) {
		echo $row( (int) $i, $sp['title'], $sp['value'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
	echo '</div><button type="button" class="button" id="sg_spec_add">+ ' . esc_html__( 'Add detail', 'sogand-core' ) . '</button>';
	echo '<p class="description">' . esc_html__( 'Shown in the details table after materials, gemstones, technique and year.', 'sogand-core' ) . '</p>';
	echo '<script type="text/template" id="sg_spec_tpl">' . $row( 9999, '', '' ) . '</script></td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '</tbody></table>';
}

add_action( 'admin_enqueue_scripts', function () {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || 'sg_work' !== $screen->post_type || 'post' !== $screen->base ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_script( 'sgc-work-admin', SGC_URL . 'assets/js/admin-work.js', array( 'jquery', 'wp-color-picker' ), SGC_VERSION, true );
	wp_enqueue_style( 'sgc-admin', SGC_URL . 'assets/css/admin.css', array(), SGC_VERSION );
	wp_localize_script( 'sgc-work-admin', 'sgcWork', array( 'title' => __( 'Gallery', 'sogand-core' ), 'button' => __( 'Use these images', 'sogand-core' ) ) );
} );

add_action( 'save_post_sg_work', function ( $post_id ) {
	if ( ! isset( $_POST['sgc_work_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['sgc_work_nonce'] ) ), 'sgc_work' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	foreach ( array_keys( sgc_work_fields() ) as $key ) {
		$v = isset( $_POST[ 'sg_' . $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ 'sg_' . $key ] ) ) : '';
		update_post_meta( $post_id, '_sg_' . $key, $v );
	}
	$tone = isset( $_POST['sg_tone'] ) ? sanitize_hex_color( wp_unslash( $_POST['sg_tone'] ) ) : '';
	update_post_meta( $post_id, '_sg_tone', $tone ? $tone : '' );
	update_post_meta( $post_id, '_sg_featured', empty( $_POST['sg_featured'] ) ? '' : '1' );
	$gallery = isset( $_POST['sg_gallery'] ) ? implode( ',', array_filter( array_map( 'absint', explode( ',', sanitize_text_field( wp_unslash( $_POST['sg_gallery'] ) ) ) ) ) ) : '';
	update_post_meta( $post_id, '_sg_gallery', $gallery );
	$specs = array();
	if ( isset( $_POST['sg_specs'] ) && is_array( $_POST['sg_specs'] ) ) {
		foreach ( wp_unslash( $_POST['sg_specs'] ) as $sp ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$t = isset( $sp['title'] ) ? sanitize_text_field( $sp['title'] ) : '';
			$v = isset( $sp['value'] ) ? sanitize_text_field( $sp['value'] ) : '';
			if ( '' !== $t || '' !== $v ) {
				$specs[] = array( 'title' => $t, 'value' => $v );
			}
		}
	}
	update_post_meta( $post_id, '_sg_specs', wp_slash( wp_json_encode( array_slice( $specs, 0, 40 ) ) ) );
} );

/* -------------------------------------------------------------------------
 * Collection order (shown as "Display order" on the collection screens)
 * ---------------------------------------------------------------------- */
add_action( 'sg_collection_add_form_fields', function () {
	echo '<div class="form-field"><label for="sg_order">' . esc_html__( 'Display order', 'sogand-core' ) . '</label><input type="number" name="sg_order" id="sg_order" value="0" min="0"><p>' . esc_html__( 'Filters on the Collections page follow this order (lower first).', 'sogand-core' ) . '</p></div>';
} );
add_action( 'sg_collection_edit_form_fields', function ( $term ) {
	$v = (int) get_term_meta( $term->term_id, '_sg_order', true );
	echo '<tr class="form-field"><th><label for="sg_order">' . esc_html__( 'Display order', 'sogand-core' ) . '</label></th><td><input type="number" name="sg_order" id="sg_order" value="' . esc_attr( $v ) . '" min="0"><p class="description">' . esc_html__( 'Filters on the Collections page follow this order (lower first).', 'sogand-core' ) . '</p></td></tr>';
} );
$sgc_save_term_order = function ( $term_id ) {
	if ( isset( $_POST['sg_order'] ) && current_user_can( 'manage_categories' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- core term screens verify their own nonce
		update_term_meta( $term_id, '_sg_order', absint( wp_unslash( $_POST['sg_order'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
	}
};
add_action( 'created_sg_collection', $sgc_save_term_order );
add_action( 'edited_sg_collection', $sgc_save_term_order );
add_filter( 'manage_edit-sg_collection_columns', function ( $cols ) {
	$cols['sg_order'] = __( 'Order', 'sogand-core' );
	return $cols;
} );
add_filter( 'manage_sg_collection_custom_column', function ( $out, $col, $term_id ) {
	return 'sg_order' === $col ? (string) (int) get_term_meta( $term_id, '_sg_order', true ) : $out;
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Inquiries list
 * ---------------------------------------------------------------------- */
add_filter( 'manage_sg_inquiry_posts_columns', function ( $cols ) {
	return array(
		'cb'         => $cols['cb'],
		'title'      => __( 'Inquiry', 'sogand-core' ),
		'sg_type'    => __( 'Type', 'sogand-core' ),
		'sg_email'   => __( 'Email', 'sogand-core' ),
		'sg_service' => __( 'Service', 'sogand-core' ),
		'sg_mailed'  => __( 'Email accepted by server', 'sogand-core' ),
		'date'       => __( 'Date', 'sogand-core' ),
	);
} );
add_action( 'manage_sg_inquiry_posts_custom_column', function ( $col, $id ) {
	$map = array( 'sg_type' => '_sg_type', 'sg_email' => '_sg_email', 'sg_service' => '_sg_service', 'sg_mailed' => '_sg_mailed' );
	if ( isset( $map[ $col ] ) ) {
		$v = get_post_meta( $id, $map[ $col ], true );
		echo 'sg_email' === $col ? '<a href="mailto:' . esc_attr( $v ) . '">' . esc_html( $v ) . '</a>' : esc_html( $v );
	}
}, 10, 2 );

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'sgc_inquiry', __( 'Details', 'sogand-core' ), function ( $post ) {
		echo '<table class="form-table" role="presentation"><tbody>';
		foreach ( array( 'type', 'name', 'email', 'phone', 'service', 'piece', 'source', 'mailed' ) as $k ) {
			$v = get_post_meta( $post->ID, '_sg_' . $k, true );
			if ( '' === $v ) {
				continue;
			}
			echo '<tr><th>' . esc_html( ucfirst( $k ) ) . '</th><td>' . ( 'email' === $k ? '<a href="mailto:' . esc_attr( $v ) . '">' . esc_html( $v ) . '</a>' : esc_html( $v ) ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}, 'sg_inquiry', 'normal', 'high' );
} );

add_action( 'admin_menu', function () {
	add_submenu_page( 'edit.php?post_type=sg_inquiry', __( 'Export subscribers', 'sogand-core' ), __( 'Export subscribers (CSV)', 'sogand-core' ), 'edit_posts', 'sgc-export', function () {
		echo '<div class="wrap"><h1>' . esc_html__( 'Export newsletter subscribers', 'sogand-core' ) . '</h1><p><a class="button button-primary" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=sgc_export' ), 'sgc_export' ) ) . '">' . esc_html__( 'Download CSV', 'sogand-core' ) . '</a></p></div>';
	} );
} );

add_action( 'admin_post_sgc_export', function () {
	if ( ! current_user_can( 'edit_posts' ) || ! check_admin_referer( 'sgc_export' ) ) {
		wp_die( esc_html__( 'You are not allowed to do this.', 'sogand-core' ) );
	}
	$q = get_posts( array( 'post_type' => 'sg_inquiry', 'post_status' => 'any', 'numberposts' => -1, 'meta_key' => '_sg_type', 'meta_value' => 'newsletter' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=sogand-subscribers.csv' );
	$out = fopen( 'php://output', 'w' );
	fputcsv( $out, array( 'email', 'date', 'source' ) );
	foreach ( $q as $p ) {
		$email = (string) get_post_meta( $p->ID, '_sg_email', true );
		/* neutralise spreadsheet formulas */
		if ( preg_match( '/^[=+\-@]/', $email ) ) {
			$email = "'" . $email;
		}
		fputcsv( $out, array( $email, $p->post_date, get_post_meta( $p->ID, '_sg_source', true ) ) );
	}
	fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
	exit;
} );

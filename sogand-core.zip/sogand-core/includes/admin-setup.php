<?php
/**
 * Sogand → Setup: checks, layout choice per page, build / migrate, restore, extra code.
 * Uses standard WordPress admin markup, so it follows the admin language and RTL.
 *
 * @package SogandCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_menu', function () {
	add_menu_page( __( 'Sogand', 'sogand-core' ), __( 'Sogand', 'sogand-core' ), 'manage_options', 'sgc-setup', 'sgc_setup_page', 'dashicons-star-filled', 3 );
	add_submenu_page( 'sgc-setup', __( 'Setup & layouts', 'sogand-core' ), __( 'Setup & layouts', 'sogand-core' ), 'manage_options', 'sgc-setup', 'sgc_setup_page' );
	if ( function_exists( 'sgc_settings_page' ) ) {
		add_submenu_page( 'sgc-setup', __( 'Settings', 'sogand-core' ), __( 'Settings', 'sogand-core' ), 'manage_options', 'options-general.php?page=sgc-contact' );
	}
}, 20 );

add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'manage_options' ) || ! get_option( 'sgc_needs_setup' ) ) {
		return;
	}
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( $screen && 'toplevel_page_sgc-setup' === $screen->id ) {
		return;
	}
	echo '<div class="notice notice-info"><p>' . esc_html__( 'Sogand Core is active. Open Sogand → Setup & layouts to build the pages from the Elementor templates (and, on a Sogand 7 site, to carry its content over safely).', 'sogand-core' ) . ' <a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=sgc-setup' ) ) . '">' . esc_html__( 'Open setup', 'sogand-core' ) . '</a></p></div>';
} );

/** Handle the forms (build, restore, code) — admin-post with nonces. */
add_action( 'admin_post_sgc_build', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Not allowed.', 'sogand-core' ) );
	}
	check_admin_referer( 'sgc_build' );
	if ( sgc_legacy_theme_active() || ! class_exists( 'Sogand\\Core\\Elementor\\Integration' ) ) {
		set_transient( 'sgc_build_log_' . get_current_user_id(), array( array( 'error', __( 'Activate the Sogand 8 theme and Elementor first — the pages need the Sogand widgets to be available while they are built.', 'sogand-core' ) ) ), 10 * MINUTE_IN_SECONDS );
		wp_safe_redirect( admin_url( 'admin.php?page=sgc-setup&done=1' ) );
		exit;
	}
	$roles   = array_keys( sgc_page_roles() );
	$presets = array();
	foreach ( $roles as $role ) {
		$v = isset( $_POST[ 'preset_' . $role ] ) ? sanitize_key( wp_unslash( $_POST[ 'preset_' . $role ] ) ) : '';
		if ( $v && sgc_manifest_item( $v ) ) {
			$presets[ $role ] = $v;
		}
	}
	$pages = isset( $_POST['pages'] ) ? array_values( array_intersect( $roles, array_map( 'sanitize_key', (array) wp_unslash( $_POST['pages'] ) ) ) ) : array();
	$o     = array(
		'presets'     => $presets,
		'pages'       => $pages,
		'globals'     => ! empty( $_POST['globals'] ),
		'menu'        => ! empty( $_POST['menu'] ),
		'library'     => ! empty( $_POST['library'] ),
		'samples'     => ! empty( $_POST['samples'] ),
		'replace_tpl' => ! empty( $_POST['replace_tpl'] ),
		'text_map'    => array(),
	);
	$legacy = sgc_legacy_detect();
	if ( $legacy['any'] && ! empty( $_POST['migrate'] ) ) {
		sgc_legacy_backup();
		sgc_legacy_copy_code();
		$o['text_map']    = sgc_legacy_text_map();
		$o['legacy_menu'] = true;
	}
	$log = sgc_build_site( $o );
	set_transient( 'sgc_build_log_' . get_current_user_id(), $log, 10 * MINUTE_IN_SECONDS );
	wp_safe_redirect( admin_url( 'admin.php?page=sgc-setup&done=1' ) );
	exit;
} );

add_action( 'admin_post_sgc_restore', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Not allowed.', 'sogand-core' ) );
	}
	check_admin_referer( 'sgc_restore' );
	$n = sgc_restore_all();
	set_transient( 'sgc_build_log_' . get_current_user_id(), array( array( 'ok', sprintf( /* translators: %d: pages */ __( 'Restored %d pages, the front page and Site Settings to their earlier state. If you are returning to Sogand 7, upload your Sogand 7 theme zip again (Appearance → Themes → Add New → Upload Theme, replace the current theme).', 'sogand-core' ), $n ) ) ), 10 * MINUTE_IN_SECONDS );
	wp_safe_redirect( admin_url( 'admin.php?page=sgc-setup&done=1' ) );
	exit;
} );

add_action( 'admin_post_sgc_code', function () {
	if ( ! current_user_can( 'unfiltered_html' ) ) {
		wp_die( esc_html__( 'Only administrators who may add unfiltered HTML can save this code.', 'sogand-core' ) );
	}
	check_admin_referer( 'sgc_code' );
	update_option( 'sgc_code', array(
		'head' => isset( $_POST['code_head'] ) ? (string) wp_unslash( $_POST['code_head'] ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- administrators with unfiltered_html only
		'foot' => isset( $_POST['code_foot'] ) ? (string) wp_unslash( $_POST['code_foot'] ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		'on'   => empty( $_POST['code_on'] ) ? '0' : '1',
	), false );
	wp_safe_redirect( admin_url( 'admin.php?page=sgc-setup&code=1#sgc-code' ) );
	exit;
} );

/* extra code output (only when switched on) */
add_action( 'wp_head', function () {
	$c = get_option( 'sgc_code' );
	if ( is_array( $c ) && '1' === $c['on'] && '' !== trim( $c['head'] ) ) {
		echo "\n" . $c['head'] . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- saved by administrators with unfiltered_html
	}
}, 99 );
add_action( 'wp_footer', function () {
	$c = get_option( 'sgc_code' );
	if ( is_array( $c ) && '1' === $c['on'] && '' !== trim( $c['foot'] ) ) {
		echo "\n" . $c['foot'] . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}, 99 );

function sgc_setup_checks() {
	$theme = wp_get_theme();
	$el    = defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '';
	return array(
		array( '' !== $el && version_compare( $el, SGC_MIN_ELEMENTOR, '>=' ), sprintf( /* translators: %s: version */ __( 'Elementor active (%s)', 'sogand-core' ), $el ? $el : __( 'missing', 'sogand-core' ) ), true ),
		array( defined( 'ELEMENTOR_PRO_VERSION' ), defined( 'ELEMENTOR_PRO_VERSION' ) ? sprintf( __( 'Elementor Pro %s — Theme Builder locations take priority where they have conditions', 'sogand-core' ), ELEMENTOR_PRO_VERSION ) : __( 'Elementor Pro not active (not required — header/footer come from Site Settings → Sogand Templates)', 'sogand-core' ), false ),
		array( 'sogand' === $theme->get_template() && version_compare( (string) $theme->get( 'Version' ), '8', '>=' ), sprintf( __( 'Theme: %1$s %2$s', 'sogand-core' ), $theme->get( 'Name' ), $theme->get( 'Version' ) ), true ),
		array( '' !== (string) get_option( 'permalink_structure' ), __( 'Pretty permalinks (keeps /collections/… URLs)', 'sogand-core' ), true ),
		array( (bool) sgc_manifest()['templates'], sprintf( __( '%d bundled templates found', 'sogand-core' ), count( sgc_manifest()['templates'] ) ), true ),
	);
}

function sgc_setup_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$legacy  = sgc_legacy_detect();
	$suggest = $legacy['any'] ? sgc_legacy_presets() : array();
	$built   = get_option( 'sgc_built' );
	echo '<div class="wrap sgc-setup"' . ( sgc_admin_rtl_text() ? ' dir="rtl"' : '' ) . '><h1>' . esc_html__( 'Sogand — Setup & layouts', 'sogand-core' ) . '</h1>';
	if ( sgc_legacy_theme_active() ) {
		echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'The active theme is Sogand 7. Upload the Sogand 8 theme first (it replaces Sogand 7); building is disabled until then. Restoring (below) works in both themes.', 'sogand-core' ) . '</p></div>';
	}

	$log = get_transient( 'sgc_build_log_' . get_current_user_id() );
	if ( ! empty( $_GET['done'] ) && $log ) { // phpcs:ignore WordPress.Security.NonceVerification
		delete_transient( 'sgc_build_log_' . get_current_user_id() );
		$errors = array_filter( $log, function ( $l ) { return 'error' === $l[0]; } );
		echo '<div class="notice ' . ( $errors ? 'notice-warning' : 'notice-success' ) . '"><ul>';
		foreach ( $log as $l ) {
			echo '<li>' . ( 'ok' === $l[0] ? '✓ ' : ( 'warn' === $l[0] ? '• ' : '✗ ' ) ) . esc_html( $l[1] ) . '</li>';
		}
		echo '</ul></div>';
	}
	if ( ! empty( $_GET['code'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		echo '<div class="notice notice-success"><p>' . esc_html__( 'Extra code saved.', 'sogand-core' ) . '</p></div>';
	}

	/* checks */
	echo '<h2>' . esc_html__( 'Checks', 'sogand-core' ) . '</h2><ul class="sgc-checks">';
	foreach ( sgc_setup_checks() as $c ) {
		echo '<li class="' . ( $c[0] ? 'is-ok' : ( $c[2] ? 'is-bad' : 'is-info' ) ) . '">' . ( $c[0] ? '✓' : ( $c[2] ? '✗' : 'i' ) ) . ' ' . esc_html( $c[1] ) . '</li>';
	}
	echo '</ul>';

	if ( $legacy['any'] ) {
		echo '<div class="notice notice-info inline"><p><strong>' . esc_html__( 'Sogand 7 content found.', 'sogand-core' ) . '</strong> ' . esc_html( sprintf( /* translators: %d: works */ __( '%d portfolio works and their collections stay exactly as they are. With “Carry over Sogand 7 wording” on, a backup copy is stored first and texts you changed in the Studio or the Customizer are written into the new pages wherever the same sentence exists.', 'sogand-core' ), $legacy['works'] ) ) . '</p>';
		$left = sgc_legacy_leftovers();
		if ( $left ) {
			echo '<p>' . esc_html__( 'Not carried over automatically:', 'sogand-core' ) . '</p><ul style="list-style:disc;padding-inline-start:20px">';
			foreach ( $left as $l ) {
				echo '<li>' . esc_html( $l ) . '</li>';
			}
			echo '</ul>';
		}
		echo '</div>';
	}

	/* build form */
	echo '<h2>' . esc_html__( 'Build or update the pages', 'sogand-core' ) . '</h2>';
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	wp_nonce_field( 'sgc_build' );
	echo '<input type="hidden" name="action" value="sgc_build">';
	echo '<table class="form-table" role="presentation"><tbody>';
	foreach ( sgc_page_roles() as $role => $r ) {
		$list    = sgc_manifest_group( $role );
		$current = '';
		$pid     = sgc_find_role_page( $role );
		if ( $pid ) {
			$current = (string) get_post_meta( $pid, '_sgc_preset', true );
		}
		$sel = $current ? $current : ( isset( $suggest[ $role ] ) ? $suggest[ $role ] : $role . '-01' );
		echo '<tr><th scope="row"><label><input type="checkbox" name="pages[]" value="' . esc_attr( $role ) . '"' . checked( ! $current, true, false ) . '> ' . esc_html( $r['label'] ) . '</label></th><td>';
		echo '<select name="preset_' . esc_attr( $role ) . '" class="sgc-preset" style="max-width:100%">';
		foreach ( $list as $t ) {
			echo '<option value="' . esc_attr( $t['id'] ) . '" data-desc="' . esc_attr( sgc_tpl_desc( $t ) ) . '"' . selected( $sel, $t['id'], false ) . '>' . esc_html( sgc_tpl_title( $t ) ) . '</option>';
		}
		echo '</select>';
		if ( $pid ) {
			echo ' <a href="' . esc_url( get_permalink( $pid ) ) . '" target="_blank">' . esc_html__( 'View', 'sogand-core' ) . '</a>';
			if ( $current ) {
				echo ' · <a href="' . esc_url( admin_url( 'post.php?post=' . $pid . '&action=elementor' ) ) . '">' . esc_html__( 'Edit with Elementor', 'sogand-core' ) . '</a>';
			}
		}
		$desc = '';
		foreach ( $list as $t ) {
			if ( $t['id'] === $sel ) {
				$desc = sgc_tpl_desc( $t );
			}
		}
		echo '<p class="description sgc-preset-desc">' . esc_html( $current ? __( 'Already built — tick the box only if you want to replace this page (its current content is kept as a snapshot you can restore).', 'sogand-core' ) : $desc ) . '</p></td></tr>';
	}
	$opts = array(
		'globals'     => array( ! $built, __( 'Write the Sogand colours, fonts and button style into Elementor Site Settings (your earlier settings are backed up)', 'sogand-core' ) ),
		'menu'        => array( true, __( 'Create the primary menu if none is assigned (existing menus are never changed)', 'sogand-core' ) ),
		'samples'     => array( 0 === $legacy['works'], __( 'Add three sample works when the portfolio is empty', 'sogand-core' ) ),
		'library'     => array( false, __( 'Also add all 240 layouts to Templates → Saved Templates (to insert any section later)', 'sogand-core' ) ),
		'replace_tpl' => array( false, __( 'Re-import header, footer and shared templates (the previous copy is kept as a draft)', 'sogand-core' ) ),
	);
	if ( $legacy['any'] ) {
		$opts = array( 'migrate' => array( true, __( 'Carry over Sogand 7 wording and layout choices (a backup is taken first)', 'sogand-core' ) ) ) + $opts;
	}
	echo '<tr><th scope="row">' . esc_html__( 'Options', 'sogand-core' ) . '</th><td><fieldset>';
	foreach ( $opts as $k => $o ) {
		echo '<label style="display:block;margin:0 0 8px"><input type="checkbox" name="' . esc_attr( $k ) . '" value="1"' . checked( $o[0], true, false ) . '> ' . esc_html( $o[1] ) . '</label>';
	}
	echo '</fieldset></td></tr></tbody></table>';
	$can_build = ! sgc_legacy_theme_active() && class_exists( 'Sogand\\Core\\Elementor\\Integration' );
	submit_button( $built ? __( 'Update selected pages', 'sogand-core' ) : __( 'Build the site', 'sogand-core' ), 'primary', 'submit', true, $can_build ? array() : array( 'disabled' => 'disabled' ) );
	echo '</form>';

	/* restore */
	echo '<h2>' . esc_html__( 'Restore', 'sogand-core' ) . '</h2><p>' . esc_html__( 'Puts the five pages back to the content they had before Sogand 8 first changed them, restores the front page settings and the previous Elementor Site Settings. Portfolio works, menus and templates are not touched.', 'sogand-core' ) . '</p>';
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="return confirm(\'' . esc_js( __( 'Restore the earlier pages and settings?', 'sogand-core' ) ) . '\');">';
	wp_nonce_field( 'sgc_restore' );
	echo '<input type="hidden" name="action" value="sgc_restore">';
	submit_button( __( 'Restore earlier pages', 'sogand-core' ), 'secondary' );
	echo '</form>';

	/* extra code */
	$code = get_option( 'sgc_code', array( 'head' => '', 'foot' => '', 'on' => '0' ) );
	echo '<h2 id="sgc-code">' . esc_html__( 'Extra code', 'sogand-core' ) . '</h2><p>' . esc_html__( 'Code printed in <head> and before </body> on every page (analytics, site verification). Only administrators who may add unfiltered HTML can save it.', 'sogand-core' ) . '</p>';
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	wp_nonce_field( 'sgc_code' );
	echo '<input type="hidden" name="action" value="sgc_code">';
	echo '<p><label><input type="checkbox" name="code_on" value="1"' . checked( '1', $code['on'], false ) . '> ' . esc_html__( 'Print this code on the site', 'sogand-core' ) . '</label></p>';
	echo '<p><label for="sgc-head">&lt;head&gt;</label><br><textarea id="sgc-head" name="code_head" rows="5" class="large-text code" dir="ltr">' . esc_textarea( $code['head'] ) . '</textarea></p>';
	echo '<p><label for="sgc-foot">&lt;/body&gt;</label><br><textarea id="sgc-foot" name="code_foot" rows="5" class="large-text code" dir="ltr">' . esc_textarea( $code['foot'] ) . '</textarea></p>';
	submit_button( __( 'Save code', 'sogand-core' ), 'secondary', 'submit', true, current_user_can( 'unfiltered_html' ) ? array() : array( 'disabled' => 'disabled' ) );
	echo '</form>';

	echo '<style>.sgc-checks li{margin:0 0 6px}.sgc-checks .is-ok{color:#1a7f37}.sgc-checks .is-bad{color:#b32d2e}.sgc-checks .is-info{color:#50575e}</style>';
	/* the description under each layout list follows the chosen layout */
	echo "<script>document.querySelectorAll('.sgc-preset').forEach(function(s){s.addEventListener('change',function(){var p=s.parentNode.querySelector('.sgc-preset-desc'),o=s.options[s.selectedIndex];if(p&&o){p.textContent=o.getAttribute('data-desc')||'';}});});</script>";
	echo '</div>';
}

<?php
/**
 * Site builder: creates (or re-uses) the five pages, imports the shared templates,
 * fills the pages with the chosen layout presets, sets the Site Settings defaults
 * (global colours, fonts, buttons, header/footer slots) and the primary menu.
 *
 * Safe to run again: pages and templates are found by role, earlier content is kept
 * as a snapshot that can be restored, menus that already exist are left alone and
 * portfolio entries, collections and their URLs are never touched.
 *
 * @package SogandCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Page roles with their default title and slug. */
function sgc_page_roles() {
	return array(
		/* title = the page title visitors see (English); label = admin wording */
		'home'        => array( 'title' => 'Home', 'slug' => 'home', 'label' => __( 'Home page', 'sogand-core' ) ),
		'collections' => array( 'title' => 'Collections', 'slug' => 'collections', 'label' => __( 'Collections page', 'sogand-core' ) ),
		'services'    => array( 'title' => 'Services', 'slug' => 'services', 'label' => __( 'Services page', 'sogand-core' ) ),
		'about'       => array( 'title' => 'About', 'slug' => 'about', 'label' => __( 'About page', 'sogand-core' ) ),
		'contact'     => array( 'title' => 'Contact', 'slug' => 'contact', 'label' => __( 'Contact page', 'sogand-core' ) ),
	);
}

/** Templates every site needs, in import order (later ones may reference earlier ones). */
function sgc_site_templates() {
	return array( 'collections-slider', 'collections-archive', 'header', 'footer', 'work-single', '404', 'collection-archive' );
}

/**
 * Find the page that plays a role: remembered id → Sogand 7 page → front page → slug.
 *
 * @param string $role   Role.
 * @param bool   $create Create it when missing.
 */
function sgc_find_role_page( $role, $create = false ) {
	$pid = (int) get_option( 'sgc_page_' . $role );
	if ( $pid && 'page' === get_post_type( $pid ) && 'trash' !== get_post_status( $pid ) ) {
		return $pid;
	}
	$pid = 0;
	if ( 'home' === $role ) {
		if ( 'page' === get_option( 'show_on_front' ) ) {
			$pid = (int) get_option( 'page_on_front' );
		}
	} else {
		$found = get_posts( array(
			'post_type'   => 'page',
			'post_status' => array( 'publish', 'draft', 'private' ),
			'numberposts' => 1,
			'fields'      => 'ids',
			'meta_key'    => '_sogand_view', // phpcs:ignore WordPress.DB.SlowDBQuery -- page made by Sogand 7
			'meta_value'  => $role, // phpcs:ignore WordPress.DB.SlowDBQuery
		) );
		$pid = $found ? (int) $found[0] : 0;
	}
	$roles = sgc_page_roles();
	if ( ! $pid ) {
		$p   = get_page_by_path( $roles[ $role ]['slug'] );
		$pid = $p ? (int) $p->ID : 0;
	}
	if ( ! $pid && $create ) {
		$pid = wp_insert_post( array(
			'post_type'   => 'page',
			'post_status' => 'publish',
			'post_title'  => $roles[ $role ]['title'],
			'post_name'   => $roles[ $role ]['slug'],
		), true );
		$pid = is_wp_error( $pid ) ? 0 : (int) $pid;
	}
	if ( $pid ) {
		update_option( 'sgc_page_' . $role, $pid, false );
	}
	return $pid;
}

/** Sogand defaults for Site Settings (global colours, fonts, theme style, buttons, layout). */
function sgc_kit_defaults() {
	$font = 'Sogand Sans';
	$typo = function ( $weight, $size = null, $extra = array() ) use ( $font ) {
		$t = array(
			'typography_typography'  => 'custom',
			'typography_font_family' => $font,
			'typography_font_weight' => (string) $weight,
		);
		if ( $size ) {
			$t['typography_font_size'] = array( 'unit' => 'rem', 'size' => $size, 'sizes' => array() );
		}
		return array_merge( $t, $extra );
	};
	return array(
		'system_colors'           => array(
			array( '_id' => 'primary', 'title' => __( 'Gold', 'sogand-core' ), 'color' => '#E3C88F' ),
			array( '_id' => 'secondary', 'title' => __( 'Celadon Light', 'sogand-core' ), 'color' => '#DCE0C3' ),
			array( '_id' => 'text', 'title' => __( 'Ivory', 'sogand-core' ), 'color' => '#F6F1EB' ),
			array( '_id' => 'accent', 'title' => __( 'Champagne', 'sogand-core' ), 'color' => '#C8B68E' ),
		),
		'custom_colors'           => array(
			array( '_id' => 'sgbg', 'title' => __( 'Oxblood Night', 'sogand-core' ), 'color' => '#1D0F11' ),
			array( '_id' => 'sgdeep', 'title' => __( 'Deep Night', 'sogand-core' ), 'color' => '#160A0C' ),
			array( '_id' => 'sgox', 'title' => __( 'Oxblood', 'sogand-core' ), 'color' => '#6D2634' ),
			array( '_id' => 'sgox2', 'title' => __( 'Oxblood Dark', 'sogand-core' ), 'color' => '#5B2029' ),
			array( '_id' => 'sgceladon', 'title' => __( 'Celadon', 'sogand-core' ), 'color' => '#88A99A' ),
			array( '_id' => 'sggold2', 'title' => __( 'Antique Gold', 'sogand-core' ), 'color' => '#C9A35C' ),
			array( '_id' => 'sgsilver', 'title' => __( 'Silver', 'sogand-core' ), 'color' => '#D9DDE3' ),
			array( '_id' => 'sgmuted', 'title' => __( 'Ivory Muted', 'sogand-core' ), 'color' => 'rgba(246,241,235,0.74)' ),
			array( '_id' => 'sgfaint', 'title' => __( 'Ivory Faint', 'sogand-core' ), 'color' => 'rgba(246,241,235,0.56)' ),
		),
		'system_typography'       => array(
			array_merge( array( '_id' => 'primary', 'title' => __( 'Display', 'sogand-core' ) ), $typo( 300, null, array( 'typography_line_height' => array( 'unit' => 'em', 'size' => 1.08, 'sizes' => array() ), 'typography_letter_spacing' => array( 'unit' => 'em', 'size' => -0.02, 'sizes' => array() ) ) ) ),
			array_merge( array( '_id' => 'secondary', 'title' => __( 'Subtitle', 'sogand-core' ) ), $typo( 400, 1.2 ) ),
			array_merge( array( '_id' => 'text', 'title' => __( 'Body', 'sogand-core' ) ), $typo( 300, 1.02, array( 'typography_line_height' => array( 'unit' => 'em', 'size' => 1.75, 'sizes' => array() ) ) ) ),
			array_merge( array( '_id' => 'accent', 'title' => __( 'Eyebrow', 'sogand-core' ) ), $typo( 500, 0.72, array( 'typography_text_transform' => 'uppercase', 'typography_letter_spacing' => array( 'unit' => 'em', 'size' => 0.28, 'sizes' => array() ) ) ) ),
		),
		'custom_typography'       => array(
			array_merge( array( '_id' => 'sgh1', 'title' => __( 'Hero Title', 'sogand-core' ) ), $typo( 300, 4.6, array( 'typography_font_size_tablet' => array( 'unit' => 'rem', 'size' => 3.4, 'sizes' => array() ), 'typography_font_size_mobile' => array( 'unit' => 'rem', 'size' => 2.5, 'sizes' => array() ), 'typography_line_height' => array( 'unit' => 'em', 'size' => 1.04, 'sizes' => array() ), 'typography_letter_spacing' => array( 'unit' => 'em', 'size' => -0.03, 'sizes' => array() ) ) ) ),
			array_merge( array( '_id' => 'sgh2', 'title' => __( 'Section Title', 'sogand-core' ) ), $typo( 300, 2.9, array( 'typography_font_size_tablet' => array( 'unit' => 'rem', 'size' => 2.4, 'sizes' => array() ), 'typography_font_size_mobile' => array( 'unit' => 'rem', 'size' => 1.95, 'sizes' => array() ), 'typography_line_height' => array( 'unit' => 'em', 'size' => 1.12, 'sizes' => array() ) ) ) ),
			array_merge( array( '_id' => 'sglead', 'title' => __( 'Lead', 'sogand-core' ) ), $typo( 300, 1.18, array( 'typography_line_height' => array( 'unit' => 'em', 'size' => 1.7, 'sizes' => array() ) ) ) ),
			array_merge( array( '_id' => 'sgbtn', 'title' => __( 'Button', 'sogand-core' ) ), $typo( 500, 0.82, array( 'typography_letter_spacing' => array( 'unit' => 'em', 'size' => 0.08, 'sizes' => array() ) ) ) ),
		),
		'body_color'              => '#F6F1EB',
		'body_typography_typography'  => 'custom',
		'body_typography_font_family' => $font,
		'body_typography_font_weight' => '300',
		'link_normal_color'       => '#E3C88F',
		'link_hover_color'        => '#F6F1EB',
		'h1_color'                => '#F6F1EB',
		'h2_color'                => '#F6F1EB',
		'h3_color'                => '#F6F1EB',
		'h1_typography_typography'  => 'custom',
		'h1_typography_font_family' => $font,
		'h1_typography_font_weight' => '300',
		'h2_typography_typography'  => 'custom',
		'h2_typography_font_family' => $font,
		'h2_typography_font_weight' => '300',
		'h3_typography_typography'  => 'custom',
		'h3_typography_font_family' => $font,
		'h3_typography_font_weight' => '400',
		'body_background_background' => 'classic',
		'body_background_color'   => '#1D0F11',
		'button_typography_typography'  => 'custom',
		'button_typography_font_family' => $font,
		'button_typography_font_weight' => '500',
		'button_text_color'       => '#1D0F11',
		'button_background_background' => 'classic',
		'button_background_color' => '#C8B68E',
		'button_hover_text_color' => '#1D0F11',
		'button_hover_background_background' => 'classic',
		'button_hover_background_color' => '#D5C5A0',
		'button_border_radius'    => array( 'unit' => 'px', 'top' => '999', 'right' => '999', 'bottom' => '999', 'left' => '999', 'isLinked' => true ),
		'button_padding'          => array( 'unit' => 'px', 'top' => '15', 'right' => '28', 'bottom' => '15', 'left' => '28', 'isLinked' => false ),
		'container_width'         => array( 'unit' => 'px', 'size' => 1240, 'sizes' => array() ),
	);
}

/**
 * Write Site Settings: Sogand defaults merged over the current ones (current kept in a backup).
 *
 * @param array $slots   sg_tpl_* => template post id.
 * @param bool  $globals Also write colours / fonts / theme style.
 */
function sgc_apply_kit( $slots, $globals ) {
	$kit = \Elementor\Plugin::$instance->kits_manager->get_active_kit();
	if ( ! $kit || ! $kit->get_id() ) {
		return new WP_Error( 'sgc_kit', __( 'Elementor Site Settings were not found.', 'sogand-core' ) );
	}
	$current = $kit->get_meta( '_elementor_page_settings' );
	$current = is_array( $current ) ? $current : array();
	if ( ! get_option( 'sgc_kit_backup' ) ) {
		add_option( 'sgc_kit_backup', array( 'time' => time(), 'kit' => $kit->get_id(), 'settings' => $current ), '', false );
	}
	$new = $slots;
	if ( $globals ) {
		$new = array_merge( sgc_kit_defaults(), $new );
		/* keep colours / fonts the owner added that are not ours */
		foreach ( array( 'custom_colors', 'custom_typography' ) as $list ) {
			$ours = wp_list_pluck( $new[ $list ], '_id' );
			if ( ! empty( $current[ $list ] ) && is_array( $current[ $list ] ) ) {
				foreach ( $current[ $list ] as $item ) {
					if ( isset( $item['_id'] ) && ! in_array( $item['_id'], $ours, true ) ) {
						$new[ $list ][] = $item;
					}
				}
			}
		}
	}
	$settings = array_merge( $current, $new );
	$kit->save( array( 'settings' => $settings ) );
	return true;
}

/** Create the primary menu (only when the theme location has no menu yet). */
function sgc_ensure_menu( $legacy = false ) {
	$locations = get_nav_menu_locations();
	$extra     = array();
	if ( ! empty( $locations['primary'] ) && wp_get_nav_menu_object( $locations['primary'] ) ) {
		/* Sogand 7 used the "primary" location only for a few extra links beside its built-in
		   pages. When migrating, those links join a full menu; the old menu stays untouched. */
		if ( ! $legacy || false !== get_option( 'sgc_v7_menu_locations' ) ) {
			return 0;
		}
		update_option( 'sgc_v7_menu_locations', $locations, false );
		$extra = (array) wp_get_nav_menu_items( $locations['primary'] );
	}
	$menu = wp_get_nav_menu_object( 'Sogand Primary' );
	$mid  = $menu ? (int) $menu->term_id : (int) wp_create_nav_menu( 'Sogand Primary' );
	if ( ! $mid || is_wp_error( $mid ) ) {
		return 0;
	}
	if ( ! wp_get_nav_menu_items( $mid ) ) {
		$add = function ( $page_id, $title, $mega = '', $parent = 0, $url = '' ) use ( $mid ) {
			$args = array(
				'menu-item-title'     => $title,
				'menu-item-status'    => 'publish',
				'menu-item-parent-id' => $parent,
			);
			if ( $page_id ) {
				$args['menu-item-object-id'] = $page_id;
				$args['menu-item-object']    = 'page';
				$args['menu-item-type']      = 'post_type';
			} else {
				$args['menu-item-type'] = 'custom';
				$args['menu-item-url']  = $url;
			}
			$item = wp_update_nav_menu_item( $mid, 0, $args );
			if ( $item && ! is_wp_error( $item ) && $mega ) {
				update_post_meta( $item, '_sgc_mega', $mega );
			}
			return is_wp_error( $item ) ? 0 : (int) $item;
		};
		$add( sgc_find_role_page( 'home' ), 'Home' );
		$add( sgc_find_role_page( 'collections' ), 'Collections', 'collections' );
		$svc   = sgc_find_role_page( 'services' );
		$s_top = $add( $svc, 'Services', 'services' );
		$surl  = $svc ? get_permalink( $svc ) : home_url( '/services/' );
		foreach ( array(
			'design-ideation'   => array( 'Design & Ideation', 'sketch', 'Sketches, moodboards and design directions' ),
			'bespoke-jewelry'   => array( 'Bespoke Jewelry', 'gem', 'One-of-a-kind pieces designed with you' ),
			'digital-rendering' => array( 'Digital Rendering', 'brush', 'Hand-painted digital presentations' ),
			'3d-modeling'       => array( '3D Modeling', 'cube', 'Production-ready models and visuals' ),
			'procreate-brushes' => array( 'Custom Procreate Brush Creation', 'pen', 'Brushes for jewelry artists' ),
		) as $slug => $d ) {
			$it = $add( 0, $d[0], '', $s_top, $surl . '#' . $slug );
			if ( $it ) {
				update_post_meta( $it, '_sgc_icon', $d[1] );
				wp_update_post( array( 'ID' => $it, 'post_content' => $d[2] ) );
			}
		}
		$add( sgc_find_role_page( 'about' ), 'About' );
		$journal = (int) get_option( 'page_for_posts' );
		$have    = array();
		foreach ( array( 'home', 'collections', 'services', 'about', 'contact' ) as $r ) {
			$have[] = untrailingslashit( (string) get_permalink( sgc_find_role_page( $r ) ) );
		}
		if ( $journal ) {
			$add( $journal, 'Journal' );
			$have[] = untrailingslashit( (string) get_permalink( $journal ) );
		}
		foreach ( $extra as $it ) {
			if ( ! empty( $it->menu_item_parent ) || empty( $it->url ) || in_array( untrailingslashit( $it->url ), $have, true ) ) {
				continue;
			}
			if ( 'post_type' === $it->type && $it->object_id ) {
				$add( (int) $it->object_id, $it->title );
			} else {
				$add( 0, $it->title, '', 0, $it->url );
			}
			$have[] = untrailingslashit( $it->url );
		}
		$add( sgc_find_role_page( 'contact' ), 'Contact' );
	}
	$locations['primary'] = $mid;
	set_theme_mod( 'nav_menu_locations', $locations );
	return $mid;
}

/** Add the bundled sample works when the portfolio is empty (fresh installs only). */
function sgc_seed_sample_works() {
	$has = get_posts( array( 'post_type' => 'sg_work', 'post_status' => 'any', 'numberposts' => 1, 'fields' => 'ids' ) );
	if ( $has ) {
		return 0;
	}
	$terms = array();
	foreach ( array( 'earrings' => array( 'Earrings', 1 ), 'sets' => array( 'Sets', 2 ) ) as $slug => $t ) {
		$term = term_exists( $slug, 'sg_collection' );
		if ( ! $term ) {
			$term = wp_insert_term( $t[0], 'sg_collection', array( 'slug' => $slug ) );
		}
		if ( ! is_wp_error( $term ) ) {
			$terms[ $slug ] = (int) $term['term_id'];
			update_term_meta( $terms[ $slug ], '_sg_order', $t[1] );
		}
	}
	$works = array(
		array( 'Blue Bow Set', 'sets', 'blue-bow-set', 'A playful bow in two-tone gold, crowned with round blue gemstones — necklace, earrings and bracelet.', 'Yellow gold, brushed white gold', 'Round blue gemstones', '3D Modeling', '#4f6fd6' ),
		array( 'Ruby Ribbon Set', 'sets', 'ruby-ribbon-set', 'Ruby blossoms and cascading marquise stones, tied with a satin ribbon.', 'White gold', 'Ruby, diamond', 'Digital Rendering', '#b3263f' ),
		array( 'Emerald Kite Earrings', 'earrings', 'emerald-kite-earrings', 'A kite-cut green stone suspended beneath an emerald-cut white stone.', 'White gold', 'Green kite-cut stone, emerald-cut white stone', 'Digital Rendering', '#1f9e86' ),
	);
	$n = 0;
	foreach ( $works as $i => $w ) {
		$id = wp_insert_post( array(
			'post_type'    => 'sg_work',
			'post_status'  => 'publish',
			'post_title'   => $w[0],
			'post_name'    => $w[2],
			'post_excerpt' => $w[3],
			'menu_order'   => $i,
		), true );
		if ( is_wp_error( $id ) ) {
			continue;
		}
		if ( isset( $terms[ $w[1] ] ) ) {
			wp_set_object_terms( $id, array( $terms[ $w[1] ] ), 'sg_collection' );
		}
		update_post_meta( $id, '_sg_materials', $w[4] );
		update_post_meta( $id, '_sg_gemstones', $w[5] );
		update_post_meta( $id, '_sg_technique', $w[6] );
		update_post_meta( $id, '_sg_year', '2026' );
		update_post_meta( $id, '_sg_tone', $w[7] );
		update_post_meta( $id, '_sg_featured', '1' );
		$img = sgc_asset_attachment( 'img/works/' . $w[2] . '.webp' );
		if ( $img ) {
			set_post_thumbnail( $id, $img );
		}
		$n++;
	}
	return $n;
}

/**
 * Build or update the site.
 *
 * @param array $o {
 *   presets  array role => manifest id (e.g. 'home' => 'home-07');
 *   pages    array roles to (re)fill (default: all five);
 *   globals  bool  write colours / fonts / theme style;
 *   menu     bool  create the primary menu when none is assigned;
 *   library  bool  also import every preset into Saved Templates;
 *   samples  bool  add sample works when the portfolio is empty;
 *   replace_tpl bool re-import the shared templates (header, footer, …) over earlier copies;
 *   text_map array default wording => migrated wording.
 * }
 * @return array Log lines (each: [ 'ok'|'warn'|'error', message ]).
 */
function sgc_build_site( $o ) {
	$log = array();
	if ( ! class_exists( '\Elementor\Plugin' ) ) {
		return array( array( 'error', __( 'Elementor is not active.', 'sogand-core' ) ) );
	}
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	}
	$o = wp_parse_args( $o, array(
		'presets'     => array(),
		'pages'       => array_keys( sgc_page_roles() ),
		'globals'     => true,
		'menu'        => true,
		'library'     => false,
		'samples'     => false,
		'replace_tpl' => false,
		'text_map'    => array(),
		'legacy_menu' => false,
	) );

	/* 1. pages exist (found or created) before anything links to them */
	foreach ( array_keys( sgc_page_roles() ) as $role ) {
		$pid = sgc_find_role_page( $role, true );
		$log[] = $pid ? array( 'ok', sprintf( /* translators: 1: role 2: id */ __( 'Page “%1$s” ready (#%2$d).', 'sogand-core' ), sgc_page_roles()[ $role ]['label'], $pid ) ) : array( 'error', sprintf( __( 'Could not create the %s page.', 'sogand-core' ), $role ) );
	}
	if ( 'page' !== get_option( 'show_on_front' ) || (int) get_option( 'page_on_front' ) !== (int) get_option( 'sgc_page_home' ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', (int) get_option( 'sgc_page_home' ) );
		$log[] = array( 'ok', __( 'Home page set as the front page.', 'sogand-core' ) );
	}

	if ( $o['samples'] ) {
		$n = sgc_seed_sample_works();
		if ( $n ) {
			$log[] = array( 'ok', sprintf( __( '%d sample works added.', 'sogand-core' ), $n ) );
		}
	}

	/* 2. shared templates */
	$slots = array();
	foreach ( sgc_site_templates() as $tid ) {
		if ( ! sgc_manifest_item( $tid ) ) {
			continue;
		}
		$r = sgc_import_library_template( $tid, $o['replace_tpl'] );
		if ( is_wp_error( $r ) ) {
			$log[] = array( 'error', $tid . ': ' . $r->get_error_message() );
			continue;
		}
		$log[] = array( 'ok', sprintf( __( 'Template “%1$s” ready (#%2$d).', 'sogand-core' ), sgc_tpl_title( sgc_manifest_item( $tid ) ), $r ) );
		$slot = array( 'header' => 'header', 'footer' => 'footer', 'work-single' => 'work', '404' => '404', 'collection-archive' => 'archive' );
		if ( isset( $slot[ $tid ] ) ) {
			$slots[ 'sg_tpl_' . $slot[ $tid ] ] = (string) $r;
		}
	}

	/* 3. Site Settings */
	$k = sgc_apply_kit( $slots, (bool) $o['globals'] );
	$log[] = is_wp_error( $k ) ? array( 'error', $k->get_error_message() ) : array( 'ok', $o['globals'] ? __( 'Site Settings updated: colours, fonts, buttons, header and footer.', 'sogand-core' ) : __( 'Header and footer assigned in Site Settings.', 'sogand-core' ) );

	/* 4. page layouts */
	foreach ( (array) $o['pages'] as $role ) {
		if ( ! isset( sgc_page_roles()[ $role ] ) ) {
			continue;
		}
		$preset = isset( $o['presets'][ $role ] ) ? $o['presets'][ $role ] : $role . '-01';
		$item   = sgc_manifest_item( $preset );
		if ( ! $item || $item['group'] !== $role ) {
			$log[] = array( 'warn', sprintf( __( 'Unknown layout %s — skipped.', 'sogand-core' ), $preset ) );
			continue;
		}
		$r = sgc_apply_page_preset( (int) get_option( 'sgc_page_' . $role ), $preset, $o['text_map'] );
		$log[] = is_wp_error( $r ) ? array( 'error', $role . ': ' . $r->get_error_message() ) : array( 'ok', sprintf( __( '%1$s: filled with “%2$s”.', 'sogand-core' ), sgc_page_roles()[ $role ]['label'], sgc_tpl_title( $item ) ) );
	}

	/* 5. menu */
	if ( $o['menu'] ) {
		$mid = sgc_ensure_menu( (bool) $o['legacy_menu'] );
		if ( $mid && $o['legacy_menu'] && get_option( 'sgc_v7_menu_locations' ) ) {
			$log[] = array( 'ok', __( 'Primary menu “Sogand Primary” created with the main pages plus your Sogand 7 extra header links; the Sogand 7 menu itself is kept unchanged (Appearance → Menus).', 'sogand-core' ) );
		} else {
			$log[] = $mid ? array( 'ok', __( 'Primary menu created (Appearance → Menus).', 'sogand-core' ) ) : array( 'ok', __( 'Existing primary menu kept.', 'sogand-core' ) );
		}
	}

	/* 6. optional: every preset into Saved Templates */
	if ( $o['library'] ) {
		$n = 0;
		foreach ( sgc_manifest()['templates'] as $t ) {
			if ( in_array( $t['id'], sgc_site_templates(), true ) ) {
				continue;
			}
			$r = sgc_import_library_template( $t['id'], false );
			if ( ! is_wp_error( $r ) ) {
				$n++;
			}
		}
		$log[] = array( 'ok', sprintf( __( '%d layouts available under Templates → Saved Templates.', 'sogand-core' ), $n ) );
	}

	flush_rewrite_rules( false );
	\Elementor\Plugin::$instance->files_manager->clear_cache();
	delete_post_meta_by_key( '_elementor_element_cache' ); /* rendered widget HTML cached by Elementor */
	update_option( 'sgc_built', array( 'time' => time(), 'version' => SGC_VERSION, 'presets' => $o['presets'] ), false );
	delete_option( 'sgc_needs_setup' );
	return $log;
}

<?php
/**
 * Inquiry + newsletter processing (REST: POST /wp-json/sogand/v1/inquiry).
 * Same route as earlier Sogand versions. Spam protection: honeypot, signed timing
 * token, per-IP rate limit and optional Cloudflare Turnstile.
 *
 * @package SogandCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Recipients come from server settings only. */
function sgc_inquiry_recipients() {
	$to    = array( SGC_PRIMARY_EMAIL );
	$inbox = sanitize_email( (string) sgc_setting( 'inbox_email' ) );
	if ( is_email( $inbox ) && strtolower( $inbox ) !== strtolower( SGC_PRIMARY_EMAIL ) ) {
		$to[] = $inbox;
	}
	return $to;
}

/** Timing token printed into each form: "<time>.<signature>". */
function sgc_form_token() {
	$t = (string) time();
	return $t . '.' . substr( hash_hmac( 'sha256', $t, wp_salt( 'nonce' ) ), 0, 20 );
}

function sgc_form_token_ok( $token ) {
	$parts = explode( '.', (string) $token );
	if ( 2 !== count( $parts ) || ! ctype_digit( $parts[0] ) ) {
		return false;
	}
	$sig = substr( hash_hmac( 'sha256', $parts[0], wp_salt( 'nonce' ) ), 0, 20 );
	if ( ! hash_equals( $sig, $parts[1] ) ) {
		return false;
	}
	/* a person needs a moment to fill the form; cached pages may carry older tokens, which is fine */
	return ( time() - (int) $parts[0] ) >= 2;
}

function sgc_client_ip() {
	return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'x';
}

function sgc_turnstile_ok( $response ) {
	$secret = (string) sgc_setting( 'turnstile_secret' );
	if ( '' === $secret || '' === (string) sgc_setting( 'turnstile_site' ) ) {
		return true;
	}
	if ( '' === (string) $response ) {
		return false;
	}
	$r = wp_remote_post( 'https://challenges.cloudflare.com/turnstile/v0/siteverify', array(
		'timeout' => 8,
		'body'    => array( 'secret' => $secret, 'response' => (string) $response, 'remoteip' => sgc_client_ip() ),
	) );
	if ( is_wp_error( $r ) ) {
		return true; /* never lose a real message because the verification service is unreachable */
	}
	$j = json_decode( wp_remote_retrieve_body( $r ), true );
	return ! empty( $j['success'] );
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'sogand/v1', '/inquiry', array(
		'methods'             => 'POST',
		'permission_callback' => '__return_true',
		'callback'            => 'sgc_rest_inquiry',
	) );
} );

function sgc_rest_inquiry( WP_REST_Request $req ) {
	$p = $req->get_json_params();
	if ( ! is_array( $p ) ) {
		$p = $req->get_params();
	}
	$get = function ( $k ) use ( $p ) {
		return isset( $p[ $k ] ) && is_scalar( $p[ $k ] ) ? (string) $p[ $k ] : '';
	};

	if ( '' !== $get( 'website' ) ) { /* honeypot: pretend success */
		return array( 'ok' => true );
	}
	if ( ! sgc_form_token_ok( $get( '_sgt' ) ) ) {
		return new WP_Error( 'sogand_token', __( 'Please wait a moment and send again.', 'sogand-site' ), array( 'status' => 400 ) );
	}
	if ( ! sgc_turnstile_ok( $get( 'cf-turnstile-response' ) ) ) {
		return new WP_Error( 'sogand_spam', __( 'The spam check did not pass — please try again.', 'sogand-site' ), array( 'status' => 400 ) );
	}

	$key = 'sgc_rl_' . md5( sgc_client_ip() );
	$n   = (int) get_transient( $key );
	if ( $n >= 8 ) {
		return new WP_Error( 'sogand_rate', __( 'Too many messages — please try again a little later.', 'sogand-site' ), array( 'status' => 429 ) );
	}
	set_transient( $key, $n + 1, HOUR_IN_SECONDS );

	$type    = 'newsletter' === $get( 'type' ) ? 'newsletter' : 'contact';
	$email   = sanitize_email( $get( 'email' ) );
	$name    = sanitize_text_field( $get( 'name' ) );
	$message = sanitize_textarea_field( $get( 'message' ) );
	$service = sanitize_text_field( $get( 'service' ) );
	$piece   = sanitize_text_field( $get( 'piece' ) );
	$phone   = sanitize_text_field( $get( 'phone' ) );
	$source  = esc_url_raw( $get( 'source' ) );

	if ( ! is_email( $email ) ) {
		return new WP_Error( 'sogand_email', __( 'Please enter a valid email address.', 'sogand-site' ), array( 'status' => 400 ) );
	}
	if ( 'contact' === $type && ( mb_strlen( $name ) < 2 || mb_strlen( $message ) < 10 ) ) {
		return new WP_Error( 'sogand_fields', __( 'Please add your name and a few words about your project.', 'sogand-site' ), array( 'status' => 400 ) );
	}
	if ( mb_strlen( $message ) > 8000 ) {
		$message = mb_substr( $message, 0, 8000 );
	}

	if ( 'newsletter' === $type ) {
		$dupe = get_posts( array(
			'post_type'   => 'sg_inquiry',
			'post_status' => 'any',
			'numberposts' => 1,
			'fields'      => 'ids',
			'meta_query'  => array( // phpcs:ignore WordPress.DB.SlowDBQuery
				array( 'key' => '_sg_type', 'value' => 'newsletter' ),
				array( 'key' => '_sg_email', 'value' => $email ),
			),
		) );
		if ( $dupe ) {
			return array( 'ok' => true, 'already' => true );
		}
	}

	$title = ( 'newsletter' === $type ? 'Newsletter — ' : 'Inquiry — ' ) . ( $name ? $name : $email );
	$id    = wp_insert_post( array(
		'post_type'    => 'sg_inquiry',
		'post_status'  => 'private',
		'post_title'   => $title,
		'post_content' => $message,
	), true );
	if ( is_wp_error( $id ) ) {
		return new WP_Error( 'sogand_save', __( 'Something went wrong — please email me directly.', 'sogand-site' ), array( 'status' => 500 ) );
	}
	foreach ( compact( 'type', 'email', 'name', 'service', 'phone', 'piece', 'source' ) as $k => $v ) {
		update_post_meta( $id, '_sg_' . $k, $v );
	}

	$site  = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	$body  = 'newsletter' === $type
		? "New Join the Journey subscriber:\n\n{$email}\n"
		: "Name: {$name}\nEmail: {$email}\nPhone: {$phone}\nService: {$service}\nPiece: {$piece}\n\n{$message}\n";
	$body .= "\n—\n" . admin_url( 'post.php?post=' . $id . '&action=edit' );
	$reply = sprintf( 'Reply-To: %s <%s>', str_replace( array( "\r", "\n", '<', '>', ',', ';', '"', ':' ), '', $name ? $name : $email ), $email );
	$sent  = wp_mail( sgc_inquiry_recipients(), '[' . $site . '] ' . $title, $body, array( $reply ) );
	/* "accepted" = handed to the mail server; actual delivery cannot be confirmed from here */
	update_post_meta( $id, '_sg_mailed', $sent ? 'accepted' : 'failed' );

	if ( '1' === (string) sgc_setting( 'autoreply_on' ) ) {
		$hi  = $name ? $name : __( 'there', 'sogand-site' );
		$msg = 'newsletter' === $type
			? sprintf( "Hello,\n\nThank you for joining the journey — you will be the first to hear about new collections and private viewing dates.\n\n%s", $site )
			: sprintf( "Hello %s,\n\nThank you for your message — it has arrived and I will reply personally as soon as possible.\n\n%s\n%s", $hi, $site, sgc_setting( 'site_email' ) );
		wp_mail( $email, $site . ' — ' . __( 'Message received', 'sogand-site' ), $msg );
	}

	return array( 'ok' => true, 'mailed' => (bool) $sent );
}

<?php
/**
 * Template library: reads templates/manifest.json, resolves the placeholders inside
 * the bundled Elementor JSON (pictures, page links, template references) and saves
 * templates through Elementor's own document API, so every element is checked
 * against the real Elementor controls on the way in.
 *
 * Placeholders used in the JSON files:
 *   sgasset://img/name.webp       bundled picture → Media Library attachment (id + url)
 *   sgpage://contact?service=x    URL of the page with that role (home, collections, services, about, contact, journal)
 *   sgtpl://collections-slider    id of the imported library template with that manifest id
 *
 * @package SogandCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Parsed manifest (cached per request). */
function sgc_manifest() {
	static $m = null;
	if ( null !== $m ) {
		return $m;
	}
	$file = SGC_DIR . 'templates/manifest.json';
	$m    = array( 'version' => '0', 'groups' => array(), 'templates' => array() );
	if ( is_readable( $file ) ) {
		$j = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( is_array( $j ) && isset( $j['templates'] ) ) {
			$m = $j;
		}
	}
	$by = array();
	foreach ( $m['templates'] as $t ) {
		$by[ $t['id'] ] = $t;
	}
	$m['by_id'] = $by;
	return $m;
}

function sgc_manifest_item( $id ) {
	$m = sgc_manifest();
	return isset( $m['by_id'][ $id ] ) ? $m['by_id'][ $id ] : null;
}

/** Manifest entries of one group (home, about, services, contact, collections, hero, site). */
function sgc_manifest_group( $group ) {
	return array_values( array_filter( sgc_manifest()['templates'], function ( $t ) use ( $group ) {
		return $t['group'] === $group;
	} ) );
}

/** Raw Elementor export of one bundled template, or WP_Error. */
function sgc_template_json( $id ) {
	$t = sgc_manifest_item( $id );
	if ( ! $t ) {
		return new WP_Error( 'sgc_tpl', sprintf( 'Unknown template %s', $id ) );
	}
	$file = realpath( SGC_DIR . 'templates/' . $t['file'] );
	$base = realpath( SGC_DIR . 'templates' );
	if ( ! $file || ! $base || 0 !== strpos( $file, $base ) || ! is_readable( $file ) ) {
		return new WP_Error( 'sgc_tpl', sprintf( 'Missing file for template %s', $id ) );
	}
	$j = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	if ( ! is_array( $j ) || ! isset( $j['content'] ) || ! is_array( $j['content'] ) ) {
		return new WP_Error( 'sgc_tpl', sprintf( 'Invalid JSON in template %s', $id ) );
	}
	return $j;
}

/* -------------------------------------------------------------------------
 * Bundled pictures → Media Library (once; found again by meta _sgc_asset)
 * ---------------------------------------------------------------------- */
function sgc_asset_attachment( $rel ) {
	$rel = ltrim( str_replace( array( '..', '\\' ), '', (string) $rel ), '/' );
	static $cache = array();
	if ( isset( $cache[ $rel ] ) ) {
		return $cache[ $rel ];
	}
	$found = get_posts( array(
		'post_type'   => 'attachment',
		'post_status' => 'inherit',
		'numberposts' => 1,
		'fields'      => 'ids',
		'meta_key'    => '_sgc_asset', // phpcs:ignore WordPress.DB.SlowDBQuery
		'meta_value'  => $rel, // phpcs:ignore WordPress.DB.SlowDBQuery
	) );
	if ( $found && wp_get_attachment_url( $found[0] ) ) {
		return $cache[ $rel ] = (int) $found[0];
	}
	$src = SGC_DIR . 'assets/' . $rel;
	if ( ! is_readable( $src ) ) {
		return $cache[ $rel ] = 0;
	}
	require_once ABSPATH . 'wp-admin/includes/image.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	$bits = wp_upload_bits( 'sogand-' . basename( $src ), null, file_get_contents( $src ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	if ( ! empty( $bits['error'] ) ) {
		return $cache[ $rel ] = 0;
	}
	$type  = wp_check_filetype( $bits['file'] );
	$title = ucwords( trim( preg_replace( '/[-_]+/', ' ', pathinfo( $rel, PATHINFO_FILENAME ) ) ) );
	$id    = wp_insert_attachment( array(
		'post_mime_type' => $type['type'],
		'post_title'     => $title,
		'post_status'    => 'inherit',
	), $bits['file'] );
	if ( is_wp_error( $id ) || ! $id ) {
		return $cache[ $rel ] = 0;
	}
	$meta = wp_generate_attachment_metadata( $id, $bits['file'] );
	if ( $meta ) {
		wp_update_attachment_metadata( $id, $meta );
	}
	$alts = sgc_asset_alts();
	update_post_meta( $id, '_wp_attachment_image_alt', isset( $alts[ $rel ] ) ? $alts[ $rel ] : '' );
	update_post_meta( $id, '_sgc_asset', $rel );
	return $cache[ $rel ] = (int) $id;
}

/** Alternative text of the bundled pictures (decorative pictures stay empty). */
function sgc_asset_alts() {
	return array(
		'img/hero-firefly.webp'     => 'Model wearing ruby and jade jewelry — necklace, earrings, rings and bracelets',
		'img/sogand-portrait.webp'  => 'Sogand logo',
		'img/mark-gold.webp'        => 'Sogand logo',
		'img/signature.webp'        => 'Sogand Andalibazar signature',
	);
}

/* -------------------------------------------------------------------------
 * Placeholder resolution
 * ---------------------------------------------------------------------- */
function sgc_role_url( $spec ) {
	$parts = wp_parse_url( 'x://' . $spec );
	$role  = isset( $parts['host'] ) ? $parts['host'] : '';
	if ( 'journal' === $role ) {
		$pid  = (int) get_option( 'page_for_posts' );
		$base = $pid ? get_permalink( $pid ) : home_url( '/' );
	} elseif ( 'home' === $role ) {
		$base = home_url( '/' );
	} else {
		$base = sgc_page_url( $role );
	}
	if ( ! empty( $parts['query'] ) ) {
		$base .= ( false === strpos( $base, '?' ) ? '?' : '&' ) . $parts['query'];
	}
	if ( ! empty( $parts['fragment'] ) ) {
		$base .= '#' . $parts['fragment'];
	}
	return $base;
}

/**
 * Walk a decoded Elementor tree and replace every placeholder.
 *
 * @param mixed $node   Value.
 * @param array $tplmap Manifest id => library post id.
 */
function sgc_resolve_tokens( $node, $tplmap = array() ) {
	if ( is_array( $node ) ) {
		/* media value: { url: sgasset://…, id: … } */
		if ( isset( $node['url'] ) && is_string( $node['url'] ) && 0 === strpos( $node['url'], 'sgasset://' ) ) {
			$rel = substr( $node['url'], 10 );
			$id  = sgc_asset_attachment( $rel );
			$url = $id ? wp_get_attachment_url( $id ) : sgc_asset( $rel );
			$node['url'] = $url;
			$node['id']  = $id ? $id : '';
			if ( $id ) {
				$node['alt']    = (string) get_post_meta( $id, '_wp_attachment_image_alt', true );
				$node['source'] = 'library';
			}
			unset( $node['__sg'] );
		}
		foreach ( $node as $k => $v ) {
			$node[ $k ] = sgc_resolve_tokens( $v, $tplmap );
		}
		return $node;
	}
	if ( ! is_string( $node ) || false === strpos( $node, 'sg' ) ) {
		return $node;
	}
	if ( 0 === strpos( $node, 'sgtpl://' ) ) {
		$k = substr( $node, 8 );
		return isset( $tplmap[ $k ] ) ? (string) $tplmap[ $k ] : '';
	}
	$node = preg_replace_callback( '#sgasset://([A-Za-z0-9/_.-]+)#', function ( $m ) {
		$id = sgc_asset_attachment( $m[1] );
		return $id ? wp_get_attachment_url( $id ) : sgc_asset( $m[1] );
	}, $node );
	$node = preg_replace_callback( '#sgpage://([a-z]+(?:\?[A-Za-z0-9=&%_.+-]*)?(?:\#[A-Za-z0-9_-]*)?)#', function ( $m ) {
		return sgc_role_url( $m[1] );
	}, $node );
	return $node;
}

/** Fresh element ids for one document (keeps ids unique when the same block is used twice). */
function sgc_new_ids( $els ) {
	foreach ( $els as $i => $el ) {
		if ( ! is_array( $el ) ) {
			continue;
		}
		$el['id'] = substr( bin2hex( random_bytes( 4 ) ), 0, 7 );
		if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
			$el['elements'] = sgc_new_ids( $el['elements'] );
		}
		$els[ $i ] = $el;
	}
	return $els;
}

/** Ids of the library templates imported so far (manifest id => post id), only live ones. */
function sgc_tpl_map() {
	$map = get_option( 'sgc_tpl_map', array() );
	$map = is_array( $map ) ? $map : array();
	foreach ( $map as $k => $pid ) {
		if ( 'elementor_library' !== get_post_type( $pid ) || 'trash' === get_post_status( $pid ) ) {
			unset( $map[ $k ] );
		}
	}
	return $map;
}

/** Elementor content of a bundled template, ready to save (placeholders resolved, ids fresh). */
function sgc_prepared_content( $id, $text_map = array() ) {
	$j = sgc_template_json( $id );
	if ( is_wp_error( $j ) ) {
		return $j;
	}
	$content = sgc_resolve_tokens( $j['content'], sgc_tpl_map() );
	if ( $text_map ) {
		$content = sgc_apply_text_map( $content, $text_map );
	}
	return array(
		'content'  => sgc_new_ids( $content ),
		'settings' => isset( $j['page_settings'] ) && is_array( $j['page_settings'] ) ? sgc_resolve_tokens( $j['page_settings'], sgc_tpl_map() ) : array(),
		'type'     => isset( $j['type'] ) ? $j['type'] : 'page',
	);
}

/** Replace default wording with migrated wording (exact matches inside text settings only). */
function sgc_apply_text_map( $node, $map ) {
	if ( is_array( $node ) ) {
		foreach ( $node as $k => $v ) {
			if ( in_array( $k, array( 'id', 'elType', 'widgetType' ), true ) ) {
				continue;
			}
			$node[ $k ] = sgc_apply_text_map( $v, $map );
		}
		return $node;
	}
	if ( is_string( $node ) && '' !== $node ) {
		$plain = trim( $node );
		if ( isset( $map[ $plain ] ) ) {
			return str_replace( $plain, $map[ $plain ], $node );
		}
		/* text editor values are wrapped in <p> */
		if ( preg_match( '#^<p>(.*)</p>$#s', $plain, $mm ) && isset( $map[ trim( $mm[1] ) ] ) ) {
			return '<p>' . nl2br( esc_html( $map[ trim( $mm[1] ) ] ) ) . '</p>';
		}
	}
	return $node;
}

/** Template name / description in the admin language (Persian names come from the manifest). */
function sgc_tpl_title( $t ) {
	return ( function_exists( 'sgc_admin_persian' ) && sgc_admin_persian() && ! empty( $t['title_fa'] ) ) ? $t['title_fa'] : ( isset( $t['title'] ) ? $t['title'] : '' );
}

function sgc_tpl_desc( $t ) {
	return ( function_exists( 'sgc_admin_persian' ) && sgc_admin_persian() && isset( $t['desc_fa'] ) && '' !== $t['desc_fa'] ) ? $t['desc_fa'] : ( isset( $t['desc'] ) ? $t['desc'] : '' );
}

/**
 * Import (or re-use) one bundled template as an Elementor library template.
 *
 * @param string $id      Manifest id.
 * @param bool   $replace Replace an existing copy (the previous one is kept as a draft).
 * @return int|WP_Error   Library post id.
 */
function sgc_import_library_template( $id, $replace = false ) {
	if ( ! class_exists( '\Elementor\Plugin' ) ) {
		return new WP_Error( 'sgc_el', __( 'Elementor is not active.', 'sogand-core' ) );
	}
	$t = sgc_manifest_item( $id );
	if ( ! $t ) {
		return new WP_Error( 'sgc_tpl', sprintf( 'Unknown template %s', $id ) );
	}
	$map = sgc_tpl_map();
	if ( isset( $map[ $id ] ) && ! $replace ) {
		return (int) $map[ $id ];
	}
	$data = sgc_prepared_content( $id );
	if ( is_wp_error( $data ) ) {
		return $data;
	}
	$type = in_array( $data['type'], array( 'page', 'section', 'container' ), true ) ? $data['type'] : 'page';
	if ( 'container' === $type && ! \Elementor\Plugin::$instance->documents->get_document_type( 'container', false ) ) {
		$type = 'section';
	}
	$doc = \Elementor\Plugin::$instance->documents->create(
		$type,
		array( 'post_title' => sgc_tpl_title( $t ), 'post_status' => 'publish' ),
		array( '_sgc_tpl' => $id, '_sgc_tpl_ver' => sgc_manifest()['version'] )
	);
	if ( is_wp_error( $doc ) || ! $doc ) {
		return is_wp_error( $doc ) ? $doc : new WP_Error( 'sgc_doc', 'Could not create the template.' );
	}
	$ok = $doc->save( array( 'elements' => $data['content'], 'settings' => $data['settings'] ) );
	if ( ! $ok ) {
		wp_delete_post( $doc->get_main_id(), true );
		return new WP_Error( 'sgc_save', __( 'Elementor refused to save the template (missing permission).', 'sogand-core' ) );
	}
	$new = (int) $doc->get_main_id();
	if ( isset( $map[ $id ] ) && $replace ) {
		/* keep the previous copy, out of the way */
		$old = (int) $map[ $id ];
		/* only the latest previous copy is kept; older ones go to the bin (still recoverable) */
		$older = get_posts( array(
			'post_type'   => 'elementor_library',
			'post_status' => 'draft',
			'numberposts' => -1,
			'fields'      => 'ids',
			'exclude'     => array( $old, $new ),
			'meta_query'  => array( // phpcs:ignore WordPress.DB.SlowDBQuery
				array( 'key' => '_sgc_tpl', 'value' => $id ),
				array( 'key' => '_sgc_prev', 'value' => '1' ),
			),
		) );
		foreach ( $older as $o ) {
			wp_trash_post( $o );
		}
		update_post_meta( $old, '_sgc_prev', '1' );
		wp_update_post( array( 'ID' => $old, 'post_status' => 'draft', 'post_title' => get_the_title( $old ) . ' — ' . __( 'previous', 'sogand-core' ) ) );
		sgc_repoint_template_refs( $old, $new );
	}
	$map[ $id ] = $new;
	update_option( 'sgc_tpl_map', $map, false );
	return $new;
}

/** After a template was replaced, point the kit slots at the new copy. */
function sgc_repoint_template_refs( $old, $new ) {
	if ( ! class_exists( '\Elementor\Plugin' ) ) {
		return;
	}
	$kit = \Elementor\Plugin::$instance->kits_manager->get_active_kit();
	if ( ! $kit || ! $kit->get_id() ) {
		return;
	}
	$changes = array();
	foreach ( array( 'header', 'footer', 'work', '404', 'archive' ) as $slot ) {
		if ( (int) $kit->get_settings( 'sg_tpl_' . $slot ) === (int) $old ) {
			$changes[ 'sg_tpl_' . $slot ] = (string) $new;
		}
	}
	if ( $changes ) {
		$kit->update_settings( $changes );
	}
}

/**
 * Put a bundled page preset into an existing page (previous content kept for restore).
 *
 * @return true|WP_Error
 */
function sgc_apply_page_preset( $page_id, $preset_id, $text_map = array() ) {
	$page_id = absint( $page_id );
	if ( ! $page_id || 'page' !== get_post_type( $page_id ) ) {
		return new WP_Error( 'sgc_page', 'Not a page.' );
	}
	$data = sgc_prepared_content( $preset_id, $text_map );
	if ( is_wp_error( $data ) ) {
		return $data;
	}
	sgc_backup_page( $page_id );
	update_post_meta( $page_id, '_elementor_edit_mode', 'builder' );
	update_post_meta( $page_id, '_elementor_template_type', 'wp-page' );
	update_post_meta( $page_id, '_wp_page_template', 'elementor_header_footer' );
	$doc = \Elementor\Plugin::$instance->documents->get( $page_id, false );
	if ( ! $doc ) {
		return new WP_Error( 'sgc_doc', 'Elementor could not open the page.' );
	}
	$settings = array_merge( array( 'template' => 'elementor_header_footer' ), $data['settings'] );
	if ( ! $doc->save( array( 'elements' => $data['content'], 'settings' => $settings ) ) ) {
		return new WP_Error( 'sgc_save', __( 'Elementor refused to save the page (missing permission).', 'sogand-core' ) );
	}
	update_post_meta( $page_id, '_sgc_preset', $preset_id );
	return true;
}

/** Snapshot of the page's current content (latest three kept, oldest first dropped). */
function sgc_backup_page( $page_id ) {
	$p = get_post( $page_id );
	if ( ! $p ) {
		return;
	}
	$snap = array(
		'time'      => time(),
		'content'   => $p->post_content,
		'template'  => (string) get_post_meta( $page_id, '_wp_page_template', true ),
		'edit_mode' => (string) get_post_meta( $page_id, '_elementor_edit_mode', true ),
		'type'      => (string) get_post_meta( $page_id, '_elementor_template_type', true ),
		'data'      => (string) get_post_meta( $page_id, '_elementor_data', true ),
		'settings'  => get_post_meta( $page_id, '_elementor_page_settings', true ),
		'preset'    => (string) get_post_meta( $page_id, '_sgc_preset', true ),
	);
	$list = get_post_meta( $page_id, '_sgc_backups', true );
	$list = is_array( $list ) ? $list : array();
	/* the very first snapshot (the site before Sogand 8) is always kept */
	if ( count( $list ) >= 4 ) {
		array_splice( $list, 1, 1 );
	}
	$list[] = $snap;
	update_post_meta( $page_id, '_sgc_backups', wp_slash( $list ) );
}

/** Restore a page to its first snapshot (the state before Sogand 8 touched it). */
function sgc_restore_page( $page_id, $which = 'first' ) {
	$list = get_post_meta( $page_id, '_sgc_backups', true );
	if ( ! is_array( $list ) || ! $list ) {
		return false;
	}
	$snap = 'first' === $which ? $list[0] : end( $list );
	wp_update_post( wp_slash( array( 'ID' => $page_id, 'post_content' => $snap['content'] ) ) );
	foreach ( array(
		'_wp_page_template'         => $snap['template'],
		'_elementor_edit_mode'      => $snap['edit_mode'],
		'_elementor_template_type'  => $snap['type'],
		'_elementor_data'           => $snap['data'],
		'_sgc_preset'               => $snap['preset'],
	) as $k => $v ) {
		if ( '' === (string) $v ) {
			delete_post_meta( $page_id, $k );
		} else {
			update_post_meta( $page_id, $k, wp_slash( $v ) );
		}
	}
	if ( ! empty( $snap['settings'] ) ) {
		update_post_meta( $page_id, '_elementor_page_settings', $snap['settings'] );
	} else {
		delete_post_meta( $page_id, '_elementor_page_settings' );
	}
	delete_post_meta( $page_id, '_elementor_css' );
	if ( class_exists( '\Elementor\Plugin' ) ) {
		\Elementor\Plugin::$instance->files_manager->clear_cache();
	delete_post_meta_by_key( '_elementor_element_cache' ); /* rendered widget HTML cached by Elementor */
	}
	return true;
}

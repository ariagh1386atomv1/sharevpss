<?php
/**
 * Mega-menu options inside the standard Appearance → Menus screen.
 * The WordPress menu stays the only source of navigation items; these fields only
 * choose how a top-level item's panel looks.
 *
 * @package SogandCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function sgc_mega_types() {
	return array(
		''            => __( 'Normal (sub-items as a dropdown)', 'sogand-core' ),
		'collections' => __( 'Collections panel (categories + latest works)', 'sogand-core' ),
		'services'    => __( 'Services panel (sub-items with icon and description)', 'sogand-core' ),
	);
}

function sgc_menu_icons() {
	return array(
		''          => __( 'None', 'sogand-core' ),
		'sketch'    => __( 'Sketch / ideation', 'sogand-core' ),
		'gem'       => __( 'Gem / bespoke', 'sogand-core' ),
		'brush'     => __( 'Brush / rendering', 'sogand-core' ),
		'cube'      => __( '3D cube / modeling', 'sogand-core' ),
		'pen'       => __( 'Pen / brushes', 'sogand-core' ),
		'sparkle'   => __( 'Sparkle', 'sogand-core' ),
	);
}

add_action( 'wp_nav_menu_item_custom_fields', function ( $item_id, $item, $depth ) {
	$mega = (string) get_post_meta( $item_id, '_sgc_mega', true );
	$icon = (string) get_post_meta( $item_id, '_sgc_icon', true );
	wp_nonce_field( 'sgc_menu_item', 'sgc_menu_nonce', false );
	echo '<div class="sgc-menu-fields" style="clear:both;padding:6px 0">';
	if ( 0 === (int) $depth ) {
		echo '<p class="description description-wide"><label for="sgc-mega-' . esc_attr( $item_id ) . '">' . esc_html__( 'Sogand panel', 'sogand-core' ) . '<br><select id="sgc-mega-' . esc_attr( $item_id ) . '" name="sgc_mega[' . esc_attr( $item_id ) . ']" class="widefat">';
		foreach ( sgc_mega_types() as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '" ' . selected( $mega, $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select></label></p>';
	}
	echo '<p class="description description-wide"><label for="sgc-icon-' . esc_attr( $item_id ) . '">' . esc_html__( 'Icon in the Services panel', 'sogand-core' ) . '<br><select id="sgc-icon-' . esc_attr( $item_id ) . '" name="sgc_icon[' . esc_attr( $item_id ) . ']" class="widefat">';
	foreach ( sgc_menu_icons() as $k => $l ) {
		echo '<option value="' . esc_attr( $k ) . '" ' . selected( $icon, $k, false ) . '>' . esc_html( $l ) . '</option>';
	}
	echo '</select></label></p>';
	echo '</div>';
}, 10, 3 );

add_action( 'wp_update_nav_menu_item', function ( $menu_id, $item_id ) {
	if ( ! isset( $_POST['sgc_menu_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['sgc_menu_nonce'] ) ), 'sgc_menu_item' ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}
	if ( isset( $_POST['sgc_mega'][ $item_id ] ) ) {
		$v = sanitize_key( wp_unslash( $_POST['sgc_mega'][ $item_id ] ) );
		update_post_meta( $item_id, '_sgc_mega', array_key_exists( $v, sgc_mega_types() ) ? $v : '' );
	}
	if ( isset( $_POST['sgc_icon'][ $item_id ] ) ) {
		$v = sanitize_key( wp_unslash( $_POST['sgc_icon'][ $item_id ] ) );
		update_post_meta( $item_id, '_sgc_icon', array_key_exists( $v, sgc_menu_icons() ) ? $v : '' );
	}
}, 10, 2 );

/* Description field visible by default (used as the second line in the Services panel) */
add_action( 'admin_head-nav-menus.php', function () {
	$hidden = get_user_option( 'managenav-menuscolumnshidden' );
	if ( is_array( $hidden ) && in_array( 'description', $hidden, true ) ) {
		update_user_option( get_current_user_id(), 'managenav-menuscolumnshidden', array_values( array_diff( $hidden, array( 'description' ) ) ) );
	}
} );

/** Tree of menu items for a location (or a menu id). */
function sgc_menu_tree( $location_or_id ) {
	$menu_id = 0;
	if ( is_numeric( $location_or_id ) ) {
		$menu_id = (int) $location_or_id;
	} else {
		$locations = get_nav_menu_locations();
		$menu_id   = isset( $locations[ $location_or_id ] ) ? (int) $locations[ $location_or_id ] : 0;
	}
	if ( ! $menu_id ) {
		return array();
	}
	$items = wp_get_nav_menu_items( $menu_id, array( 'update_post_term_cache' => false ) );
	if ( ! $items ) {
		return array();
	}
	_wp_menu_item_classes_by_context( $items );
	$by_parent = array();
	foreach ( $items as $it ) {
		$by_parent[ (int) $it->menu_item_parent ][] = $it;
	}
	$build = function ( $parent ) use ( &$build, $by_parent ) {
		$out = array();
		foreach ( isset( $by_parent[ $parent ] ) ? $by_parent[ $parent ] : array() as $it ) {
			$classes = array_filter( (array) $it->classes );
			$out[]   = array(
				'id'       => (int) $it->ID,
				'title'    => $it->title,
				'url'      => $it->url,
				'target'   => $it->target,
				'rel'      => $it->xfn,
				'attr'     => $it->attr_title,
				'desc'     => $it->description,
				'classes'  => $classes,
				'current'  => in_array( 'current-menu-item', $classes, true ) || in_array( 'current_page_item', $classes, true ),
				'ancestor' => in_array( 'current-menu-ancestor', $classes, true ) || in_array( 'current-menu-parent', $classes, true ),
				'mega'     => (string) get_post_meta( $it->ID, '_sgc_mega', true ),
				'icon'     => (string) get_post_meta( $it->ID, '_sgc_icon', true ),
				'children' => $build( (int) $it->ID ),
			);
		}
		return $out;
	};
	return $build( 0 );
}

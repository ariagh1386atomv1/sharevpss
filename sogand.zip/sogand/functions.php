<?php
/**
 * Sogand 8 — classic theme for Elementor.
 *
 * @package Sogand
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SOGAND_VERSION', '8.0.1' );

/**
 * Languages: the website is English and left-to-right; the theme's admin texts are Persian.
 * The Sogand Core plugin switches the website to English (Settings → Sogand Settings);
 * without the plugin the theme at least keeps the site left-to-right.
 */
function sogand_admin_persian() {
	if ( function_exists( 'sgc_admin_persian' ) ) {
		return sgc_admin_persian();
	}
	return is_admin() && 0 === strpos( (string) get_user_locale(), 'fa' );
}

add_action( 'after_setup_theme', function () {
	if ( sogand_admin_persian() ) {
		load_textdomain( 'sogand', get_template_directory() . '/languages/fa_IR.mo' );
	}
	if ( ! function_exists( 'sgc_site_locale' ) && ! is_admin() && isset( $GLOBALS['wp_locale'] ) ) {
		$GLOBALS['wp_locale']->text_direction = 'ltr';
		add_filter( 'language_attributes', function () {
			return 'lang="en-US"';
		} );
	}
}, 0 );

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
	add_theme_support( 'custom-logo', array( 'height' => 120, 'width' => 160, 'flex-height' => true, 'flex-width' => true ) );
	register_nav_menus( array(
		'primary' => __( 'Primary', 'sogand' ),
		'footer'  => __( 'Footer', 'sogand' ),
	) );
	$GLOBALS['content_width'] = 1240;
} );

/* Elementor Pro Theme Builder: header, footer, single, archive locations */
add_action( 'elementor/theme/register_locations', function ( $manager ) {
	$manager->register_all_core_location();
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'sogand-theme', get_template_directory_uri() . '/assets/css/theme.css', array(), SOGAND_VERSION );
	wp_style_add_data( 'sogand-theme', 'rtl', 'replace' );
	wp_enqueue_script( 'sogand-theme', get_template_directory_uri() . '/assets/js/theme.js', array(), SOGAND_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
} );

/**
 * Print a site part. The Sogand Core plugin answers through the `sogand_theme_location`
 * filter (Elementor Pro location, or the template chosen in Site Settings → Sogand
 * Templates); when nothing answers, the theme's own fallback is used.
 */
function sogand_location( $location ) {
	if ( function_exists( 'elementor_theme_do_location' ) && ! has_filter( 'sogand_theme_location' ) && elementor_theme_do_location( $location ) ) {
		return true;
	}
	return (bool) apply_filters( 'sogand_theme_location', false, $location );
}

/* Admin: Sogand Core and Elementor are recommended, never installed automatically */
add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'install_plugins' ) ) {
		return;
	}
	$missing = array();
	if ( ! did_action( 'elementor/loaded' ) ) {
		$missing[] = 'Elementor';
	}
	if ( ! defined( 'SGC_VERSION' ) ) {
		$missing[] = 'Sogand Core';
	}
	if ( ! $missing ) {
		return;
	}
	echo '<div class="notice notice-warning"><p>' . esc_html( sprintf(
		/* translators: %s: plugin names */
		__( 'The Sogand theme is designed for: %s. Install and activate them (Plugins → Add New → Upload for Sogand Core). Until then the theme shows its simple fallback layout.', 'sogand' ),
		implode( ', ', $missing )
	) ) . '</p></div>';
} );

/* Body classes used by the fallback styles */
add_filter( 'body_class', function ( $c ) {
	$c[] = 'sogand-theme';
	if ( ! defined( 'SGC_VERSION' ) ) {
		$c[] = 'sogand-no-core';
	}
	return $c;
} );

/* Skip link target exists on every template */
function sogand_skip_link() {
	echo '<a class="skip-link screen-reader-text" href="#content">' . esc_html__( 'Skip to content', 'sogand' ) . '</a>';
}

/* Theme header (Themes screen) — listed here so the translation tools pick it up. */
if ( false ) {
	__( 'Sogand', 'sogand' );
	__( 'Classic theme for the Sogand Andalibazar jewelry designer website, built for Elementor and the Sogand Core plugin.', 'sogand' );
}

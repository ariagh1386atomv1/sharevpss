<?php
/**
 * A portfolio work: the Elementor work template (Site Settings → Sogand Templates or a
 * Pro single template), the work's own Elementor content, or the fallback below.
 *
 * @package Sogand
 */
get_header();
echo '<main id="main" class="sg-main is-builder">';
$own = class_exists( '\Elementor\Plugin' ) && \Elementor\Plugin::$instance->documents->get( get_the_ID() ) && \Elementor\Plugin::$instance->documents->get( get_the_ID() )->is_built_with_elementor();
if ( $own ) {
	while ( have_posts() ) {
		the_post();
		the_content();
	}
} elseif ( ! sogand_location( 'work' ) ) {
	while ( have_posts() ) {
		the_post();
		?>
		<article <?php post_class( 'sg-fb-wrap sg-prose sg-fb-work' ); ?>>
			<?php if ( has_post_thumbnail() ) : ?>
				<figure class="sg-entry-media"><?php the_post_thumbnail( 'large' ); ?></figure>
			<?php endif; ?>
			<?php the_title( '<h1 class="sg-entry-title">', '</h1>' ); ?>
			<?php if ( has_excerpt() ) : ?>
				<p class="sg-lead"><?php echo esc_html( get_the_excerpt() ); ?></p>
			<?php endif; ?>
			<div class="sg-entry-content"><?php the_content(); ?></div>
			<?php if ( function_exists( 'sgc_work_specs_rows' ) && sgc_work_specs_rows( get_the_ID() ) ) : ?>
				<dl class="sg-specs">
					<?php foreach ( sgc_work_specs_rows( get_the_ID() ) as $row ) : ?>
						<div><dt><?php echo esc_html( $row[0] ); ?></dt><dd><?php echo esc_html( $row[1] ); ?></dd></div>
					<?php endforeach; ?>
				</dl>
			<?php endif; ?>
		</article>
		<?php
	}
}
echo '</main>';
get_footer();

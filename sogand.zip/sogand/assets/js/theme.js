/* Fallback header menu toggle (only used when no Elementor header is assigned). */
(function () {
	'use strict';
	var b = document.querySelector('.sg-fb-toggle');
	var nav = document.getElementById('sg-fb-menu');
	if (!b || !nav) { return; }
	b.addEventListener('click', function () {
		var open = b.getAttribute('aria-expanded') !== 'true';
		b.setAttribute('aria-expanded', open ? 'true' : 'false');
		nav.classList.toggle('is-open', open);
	});
	document.addEventListener('keydown', function (e) {
		if (e.key === 'Escape' && nav.classList.contains('is-open')) { b.click(); b.focus(); }
	});
}());

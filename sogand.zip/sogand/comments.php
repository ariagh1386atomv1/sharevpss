<?php
/**
 * Comments.
 *
 * @package Sogand
 */
if ( post_password_required() ) {
	return;
}
?>
<section id="comments" class="sg-comments">
	<?php if ( have_comments() ) : ?>
		<h2 class="sg-comments-title"><?php echo esc_html( sprintf( /* translators: %d: count */ _n( '%d comment', '%d comments', get_comments_number(), 'sogand' ), get_comments_number() ) ); ?></h2>
		<ol class="sg-comment-list"><?php wp_list_comments( array( 'style' => 'ol', 'short_ping' => true, 'avatar_size' => 48 ) ); ?></ol>
		<?php the_comments_navigation(); ?>
	<?php endif; ?>
	<?php comment_form(); ?>
</section>

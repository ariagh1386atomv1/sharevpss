<?php
/**
 * Default template: pages (Elementor content or the editor content), posts, archives, search.
 *
 * @package Sogand
 */
get_header();
$builder = is_singular() && class_exists( '\Elementor\Plugin' ) && \Elementor\Plugin::$instance->documents->get( get_the_ID() ) && \Elementor\Plugin::$instance->documents->get( get_the_ID() )->is_built_with_elementor();
?>
<main id="main" class="sg-main<?php echo $builder ? ' is-builder' : ''; ?>">
	<?php if ( $builder ) : ?>
		<?php
		while ( have_posts() ) {
			the_post();
			the_content();
		}
		?>
	<?php elseif ( is_singular() ) : ?>
		<?php while ( have_posts() ) : the_post(); ?>
			<article id="post-<?php the_ID(); ?>" <?php post_class( 'sg-fb-wrap sg-prose' ); ?>>
				<header class="sg-entry-head">
					<?php if ( 'post' === get_post_type() ) : ?>
						<p class="sg-entry-meta"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time></p>
					<?php endif; ?>
					<?php the_title( '<h1 class="sg-entry-title">', '</h1>' ); ?>
				</header>
				<?php if ( has_post_thumbnail() && 'post' === get_post_type() ) : ?>
					<figure class="sg-entry-media"><?php the_post_thumbnail( 'large' ); ?></figure>
				<?php endif; ?>
				<div class="sg-entry-content"><?php the_content(); ?></div>
				<?php wp_link_pages(); ?>
				<?php
				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}
				?>
			</article>
		<?php endwhile; ?>
	<?php else : ?>
		<div class="sg-fb-wrap">
			<header class="sg-entry-head">
				<h1 class="sg-entry-title">
					<?php
					if ( is_search() ) {
						/* translators: %s: search terms */
						printf( esc_html__( 'Search: %s', 'sogand' ), esc_html( get_search_query() ) );
					} elseif ( is_home() ) {
						echo esc_html( get_the_title( (int) get_option( 'page_for_posts' ) ) ? get_the_title( (int) get_option( 'page_for_posts' ) ) : __( 'Journal', 'sogand' ) );
					} else {
						the_archive_title();
					}
					?>
				</h1>
			</header>
			<?php if ( have_posts() ) : ?>
				<div class="sg-post-grid">
					<?php while ( have_posts() ) : the_post(); ?>
						<article id="post-<?php the_ID(); ?>" <?php post_class( 'sg-post-card' ); ?>>
							<a href="<?php the_permalink(); ?>">
								<?php if ( has_post_thumbnail() ) : ?>
									<span class="sg-post-media"><?php the_post_thumbnail( 'medium_large', array( 'loading' => 'lazy' ) ); ?></span>
								<?php endif; ?>
								<span class="sg-post-date"><?php echo esc_html( get_the_date() ); ?></span>
								<span class="sg-post-title"><?php the_title(); ?></span>
								<span class="sg-post-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 24 ) ); ?></span>
							</a>
						</article>
					<?php endwhile; ?>
				</div>
				<?php the_posts_pagination( array( 'mid_size' => 1 ) ); ?>
			<?php else : ?>
				<p><?php esc_html_e( 'Nothing found.', 'sogand' ); ?></p>
				<?php get_search_form(); ?>
			<?php endif; ?>
		</div>
	<?php endif; ?>
</main>
<?php
get_footer();

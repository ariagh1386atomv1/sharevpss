<?php
/**
 * One collection (e.g. /collection/earrings/).
 *
 * @package Sogand
 */
get_header();
echo '<main id="main" class="sg-main is-builder">';
if ( ! sogand_location( 'archive' ) ) {
	?>
	<div class="sg-fb-wrap">
		<header class="sg-entry-head"><h1 class="sg-entry-title"><?php single_term_title(); ?></h1><?php the_archive_description( '<div class="sg-lead">', '</div>' ); ?></header>
		<div class="sg-post-grid">
			<?php while ( have_posts() ) : the_post(); ?>
				<article <?php post_class( 'sg-post-card' ); ?>>
					<a href="<?php the_permalink(); ?>">
						<span class="sg-post-media"><?php the_post_thumbnail( 'medium_large', array( 'loading' => 'lazy' ) ); ?></span>
						<span class="sg-post-title"><?php the_title(); ?></span>
					</a>
				</article>
			<?php endwhile; ?>
		</div>
		<?php the_posts_pagination(); ?>
	</div>
	<?php
}
echo '</main>';
get_footer();

<?php
/**
 * Footer: the Elementor footer — or the theme fallback.
 *
 * @package Sogand
 */
if ( ! sogand_location( 'footer' ) ) {
	get_template_part( 'template-parts/footer', 'fallback' );
}
wp_footer();
?>
</body>
</html>

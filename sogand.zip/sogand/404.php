<?php
/**
 * 404.
 *
 * @package Sogand
 */
get_header();
echo '<main id="main" class="sg-main is-builder">';
if ( ! sogand_location( '404' ) ) {
	?>
	<div class="sg-fb-wrap sg-prose sg-fb-404">
		<p class="sg-entry-meta">404</p>
		<h1 class="sg-entry-title"><?php esc_html_e( 'This piece has slipped away', 'sogand' ); ?></h1>
		<p><?php esc_html_e( 'The page you are looking for isn’t here.', 'sogand' ); ?></p>
		<p><a class="sg-fb-btn" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Return home', 'sogand' ); ?></a></p>
	</div>
	<?php
}
echo '</main>';
get_footer();

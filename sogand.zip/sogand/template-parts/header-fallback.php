<?php
/**
 * Simple accessible header used when no Elementor header is assigned.
 *
 * @package Sogand
 */
?>
<header class="sg-fb-header" id="sg-header">
	<div class="sg-fb-wrap sg-fb-header-row">
		<div class="sg-fb-brand">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
			<?php endif; ?>
		</div>
		<?php if ( has_nav_menu( 'primary' ) ) : ?>
			<button class="sg-fb-toggle" type="button" aria-expanded="false" aria-controls="sg-fb-menu"><span class="screen-reader-text"><?php esc_html_e( 'Menu', 'sogand' ); ?></span><span aria-hidden="true"></span></button>
			<nav class="sg-fb-nav" id="sg-fb-menu" aria-label="<?php esc_attr_e( 'Primary', 'sogand' ); ?>">
				<?php
				wp_nav_menu( array(
					'theme_location' => 'primary',
					'container'      => false,
					'depth'          => 2,
					'fallback_cb'    => false,
				) );
				?>
			</nav>
		<?php endif; ?>
	</div>
</header>

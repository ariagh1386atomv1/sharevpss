<?php
/**
 * Simple footer used when no Elementor footer is assigned.
 *
 * @package Sogand
 */
?>
<footer class="sg-fb-footer" id="sg-footer">
	<div class="sg-fb-wrap">
		<?php if ( has_nav_menu( 'footer' ) ) : ?>
			<nav aria-label="<?php esc_attr_e( 'Footer', 'sogand' ); ?>">
				<?php wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'depth' => 1, 'fallback_cb' => false ) ); ?>
			</nav>
		<?php endif; ?>
		<p class="sg-fb-copy">&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?></p>
	</div>
</footer>

<?php
/**
 * Header: the Elementor header (Site Settings → Sogand Templates, or a Pro Theme
 * Builder header) — or the theme fallback.
 *
 * @package Sogand
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php
wp_body_open();
sogand_skip_link();
if ( ! sogand_location( 'header' ) ) {
	get_template_part( 'template-parts/header', 'fallback' );
}
echo '<div id="content" class="sg-content-start" tabindex="-1"></div>';

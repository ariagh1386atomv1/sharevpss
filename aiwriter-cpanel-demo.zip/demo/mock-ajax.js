/* ARIAGH.AIWRITER Static Browser Demo — Local AJAX & Worker Interceptor
 * Loaded BEFORE unmodified plugin/assets/js/admin.js.
 * Zero external network calls; all data is safe sample data for demo-coffee.ir.
 */
(function ($, win) {
  'use strict';

  const STORAGE_KEY = 'aaw_static_demo_state_v1';
  const NOW = Math.floor(Date.now() / 1000);

  function defaultState() {
    return {
      topics: [
        { id: 101, title: 'بهترین دمای آب برای دم‌آوری قهوه فرانسه و فرنچ پرس', keywords: 'دمای آب قهوه فرانسه, فرنچ پرس', focus_keyword: 'دمای آب قهوه فرانسه', category_id: 1, category_name: 'آموزش دم‌آوری قهوه', status: 'pending', priority: 10, word_count: 1800, tone: '', notes: 'جدول نسبت آب به قهوه اضافه شود', post_id: 0, edit_url: '', post_status: '', generated_h: '', error: '' },
        { id: 102, title: 'مقایسه موکاپات استیل و آلومینیومی؛ کدام‌یک برای مصرف روزانه بهتر است؟', keywords: 'موکاپات استیل یا آلومینیومی', focus_keyword: 'موکاپات استیل یا آلومینیومی', category_id: 2, category_name: 'تجهیزات و اسپرسوساز', status: 'pending', priority: 9, word_count: 2000, tone: '', notes: '', post_id: 0, edit_url: '', post_status: '', generated_h: '', error: '' },
        { id: 103, title: 'آموزش رسوب‌زدایی دستگاه اسپرسوساز خانگی بدون آسیب به بویلر', keywords: 'رسوب‌زدایی اسپرسوساز خانگی', focus_keyword: 'رسوب‌زدایی اسپرسوساز خانگی', category_id: 4, category_name: 'نگهداری و عیب‌یابی', status: 'pending', priority: 8, word_count: 1600, tone: '', notes: '', post_id: 0, edit_url: '', post_status: '', generated_h: '', error: '' },
        { id: 104, title: 'کافئین قهوه ترک بیشتر است یا اسپرسو؟ بررسی علمی و دقیق', keywords: 'کافئین قهوه ترک یا اسپرسو', focus_keyword: 'کافئین قهوه ترک یا اسپرسو', category_id: 3, category_name: 'راهنمای خرید دانه قهوه', status: 'pending', priority: 7, word_count: 1500, tone: '', notes: '', post_id: 0, edit_url: '', post_status: '', generated_h: '', error: '' },
        { id: 105, title: 'راهنمای خرید ترازو دیجیتال باریستا با تایمر دقیق', keywords: 'خرید ترازو قهوه باریستا', focus_keyword: 'خرید ترازو قهوه باریستا', category_id: 2, category_name: 'تجهیزات و اسپرسوساز', status: 'pending', priority: 6, word_count: 1900, tone: '', notes: '', post_id: 0, edit_url: '', post_status: '', generated_h: '', error: '' },
        { id: 106, title: 'راهنمای کامل انتخاب بهترین قهوه اسپرسو برای دستگاه خانگی', keywords: 'بهترین قهوه اسپرسو خانگی', focus_keyword: 'بهترین قهوه اسپرسو خانگی', category_id: 3, category_name: 'راهنمای خرید دانه قهوه', status: 'done', priority: 5, word_count: 2140, tone: '', notes: '', post_id: 401, edit_url: '#demo-edit-401', post_status: 'draft', generated_h: '۱۴۰۵/۰۹/۰۱ ۱۸:۲۰', error: '' },
        { id: 107, title: 'تفاوت آسیاب قهوه تیغه‌ای و مخروطی؛ کدام عصاره‌گیری دقیق‌تری دارد؟', keywords: 'آسیاب قهوه تیغه‌ای و مخروطی', focus_keyword: 'آسیاب قهوه تیغه‌ای و مخروطی', category_id: 2, category_name: 'تجهیزات و اسپرسوساز', status: 'done', priority: 4, word_count: 1860, tone: '', notes: '', post_id: 402, edit_url: '#demo-edit-402', post_status: 'draft', generated_h: '۱۴۰۵/۰۹/۰۱ ۱۶:۰۰', error: '' }
      ],
      reviews: [
        {
          id: 401, status: 'draft',
          title: 'راهنمای کامل انتخاب بهترین قهوه اسپرسو برای دستگاه خانگی',
          date: '۱۴۰۵/۰۹/۰۱ ۱۸:۲۰', words: 2140, keyword: 'بهترین قهوه اسپرسو خانگی',
          model: 'claude-sonnet-4-5', provider: 'claude_pro',
          meta_desc: 'مقایسه کامل نسبت عربیکا و روبوستا، درجه برشته‌کاری و آسیاب استاندارد برای اسپرسوساز خانگی.',
          excerpt: 'انتخاب دانه قهوه مناسب برای دستگاه اسپرسوساز خانگی، تفاوت میان یک شات تلخ و یک اسپرسوی کرمادار حرفه‌ای را رقم می‌زند. در این راهنمای تخصصی، نسبت عربیکا و روبوستا، درجه رست و تازگی دانه را بررسی می‌کنیم…',
          thumb: '../assets/img/ic_fountain_pen.webp', edit_url: '#demo-edit-401', preview: '#demo-preview-401',
          cats: 'راهنمای خرید دانه قهوه', topic_id: 106, ai_state: {}, rev_pending: false, revisions: 1,
          img_prompt: 'فنجان اسپرسو با کرمای طلایی کنار دانه قهوه تازه روی میز چوبی مینیمال'
        },
        {
          id: 402, status: 'draft',
          title: 'تفاوت آسیاب قهوه تیغه‌ای و مخروطی؛ کدام مدل عصاره‌گیری دقیق‌تری دارد؟',
          date: '۱۴۰۵/۰۹/۰۱ ۱۶:۰۰', words: 1860, keyword: 'تفاوت آسیاب تیغه‌ای و مخروطی',
          model: 'gpt-4o', provider: 'openai',
          meta_desc: 'بررسی جدولی عملکرد آسیاب‌های Burr مخروطی و Blade تیغه‌ای از نظر یکدستی ذرات، دما و هزینه.',
          excerpt: 'یکنواختی ذرات قهوه مهم‌ترین عامل در طعم نهایی است. در این مقاله به‌صورت جدولی عملکرد آسیاب‌های Burr مخروطی و Blade تیغه‌ای را برای اسپرسو و قهوه دمی مقایسه کرده‌ایم…',
          thumb: '../assets/img/ic_image_frame.webp', edit_url: '#demo-edit-402', preview: '#demo-preview-402',
          cats: 'تجهیزات و اسپرسوساز', topic_id: 107, ai_state: {}, rev_pending: false, revisions: 0,
          img_prompt: 'آسیاب قهوه مخروطی استیل مدرن در فضای آشپزخانه روشن'
        },
        {
          id: 403, status: 'draft',
          title: 'چرا قهوه اسپرسو ترش می‌شود؟ ۷ علت اصلی و راه‌حل سریع باریستاها',
          date: '۱۴۰۵/۰۹/۰۱ ۱۲:۱۰', words: 1620, keyword: 'علت ترش شدن قهوه اسپرسو',
          model: 'anthropic.claude-sonnet-4-5', provider: 'avalai',
          meta_desc: 'چک‌لیست ۲ دقیقه‌ای رفع ترشی اسپرسو: تنظیم دمای آب، زمان عصاره‌گیری و درجه آسیاب.',
          excerpt: 'ترشی بیش از حد در فنجان اسپرسو معمولاً نشانه عصاره‌گیری ناقص (Under-extraction) است. دمای آب، زمان عصاره‌گیری و درجه آسیاب را با چک‌لیست زیر تنظیم کنید…',
          thumb: '../assets/img/ic_seo_chart.webp', edit_url: '#demo-edit-403', preview: '#demo-preview-403',
          cats: 'نگهداری و عیب‌یابی', topic_id: 0, ai_state: {}, rev_pending: false, revisions: 0,
          img_prompt: 'عصاره‌گیری اسپرسو با پرتافیلتر نیکد و جریان طلایی'
        },
        {
          id: 404, status: 'draft',
          title: 'آموزش دم‌آوری قهوه با کمکس (Chemex) با نسبت طلایی و زمان‌بندی دقیق',
          date: '۱۴۰۵/۰۸/۳۰ ۲۱:۱۵', words: 1930, keyword: 'آموزش دم‌آوری قهوه کمکس',
          model: 'gemini-2.5-pro', provider: 'gemini',
          meta_desc: 'آموزش گام‌به‌گام دم‌آوری قهوه کمکس با نسبت ۱ به ۱۶، تکنیک شکوفایی (Blooming) و فیلتر کاغذی.',
          excerpt: 'کمکس با فیلتر کاغذی ضخیم خود یکی از شفاف‌ترین و معطرترین فنجان‌های قهوه دمی را ارائه می‌دهد. در این آموزش نسبت ۱ به ۱۶ و زمان‌بندی ریختن آب را یاد می‌گیرید…',
          thumb: '../assets/img/ic_review_magnifier.webp', edit_url: '#demo-edit-404', preview: '#demo-preview-404',
          cats: 'آموزش دم‌آوری قهوه', topic_id: 0, ai_state: {}, rev_pending: false, revisions: 0,
          img_prompt: 'دم‌آوری قهوه با ظرف شیشه‌ای کمکس و نور صبحگاهی'
        }
      ],
      logs: [
        { id: 905, created_at: '2026-11-22 14:20:11', time_h: '۱۴۰۵/۰۹/۰۱ ۱۷:۵۰:۱۱', level: 'success', event: 'draft', message: 'مقاله «راهنمای کامل انتخاب بهترین قهوه اسپرسو خانگی» با امتیاز سئو ۹۶ در صف بازبینی ذخیره شد.', provider: 'claude_pro', model: 'claude-sonnet-4-5', tokens_in: 4120, tokens_out: 3480, duration_ms: 32400, post_id: 401, edit: '#demo-edit-401' },
        { id: 904, created_at: '2026-11-22 14:20:30', time_h: '۱۴۰۵/۰۹/۰۱ ۱۷:۵۰:۳۰', level: 'success', event: 'image', message: 'تصویر شاخص WebP (۴۶ KB) + تگ Alt فارسی ساخته و روی نوشته #401 ثبت شد.', provider: 'workers_ai', model: 'flux-1-schnell', tokens_in: 0, tokens_out: 0, duration_ms: 6800, post_id: 401, edit: '#demo-edit-401' },
        { id: 903, created_at: '2026-11-22 12:00:05', time_h: '۱۴۰۵/۰۹/۰۱ ۱۵:۳۰:۰۵', level: 'success', event: 'draft', message: 'مقاله «تفاوت آسیاب قهوه تیغه‌ای و مخروطی» با ۶ لینک داخلی ذخیره شد.', provider: 'openai', model: 'gpt-4o', tokens_in: 3890, tokens_out: 3120, duration_ms: 28900, post_id: 402, edit: '#demo-edit-402' },
        { id: 902, created_at: '2026-11-22 09:30:00', time_h: '۱۴۰۵/۰۹/۰۱ ۱۳:۰۰:۰۰', level: 'info', event: 'sync', message: 'بکاپ خودکار تنظیمات و صف موضوعات در فضای KV کلادفلر همگام‌سازی شد.', provider: 'cloudflare', model: 'kv', tokens_in: 0, tokens_out: 0, duration_ms: 410, post_id: 0, edit: '' },
        { id: 901, created_at: '2026-11-22 06:00:12', time_h: '۱۴۰۵/۰۹/۰۱ ۰۹:۳۰:۱۲', level: 'success', event: 'test', message: 'تست اتصال AvalAI (درگاه ایران) موفق بود (۲۱۰ میلی‌ثانیه).', provider: 'avalai', model: 'anthropic.claude-sonnet-4-5', tokens_in: 32, tokens_out: 18, duration_ms: 210, post_id: 0, edit: '' }
      ],
      merges: [
        {
          a: { id: 310, title: 'راهنمای کامل خرید قهوه اسپرسو خانگی', url: 'https://demo-coffee.ir/espresso-buying-guide/', words: 2140, date: '۱۴۰۵/۰۸/۱۲', clicks: 1420, impr: 18400, pos: 4.8 },
          b: { id: 325, title: 'چطور قهوه اسپرسو بخریم؟ (نکات سریع)', url: 'https://demo-coffee.ir/how-to-buy-espresso/', words: 740, date: '۱۴۰۴/۱۱/۰۴', clicks: 84, impr: 4100, pos: 18.6 },
          keep: 'a', score: 0.86,
          why: ['gsc', 'sim'],
          queries: ['خرید قهوه اسپرسو', 'بهترین قهوه اسپرسو خانگی']
        },
        {
          a: { id: 312, title: 'طرز تهیه قهوه فرانسه با فرنچ پرس', url: 'https://demo-coffee.ir/french-press-guide/', words: 1920, date: '۱۴۰۵/۰۷/۲۲', clicks: 2380, impr: 24900, pos: 3.1 },
          b: { id: 341, title: 'نکات دم کردن قهوه در فرنچ پرس', url: 'https://demo-coffee.ir/french-press-tips/', words: 610, date: '۱۴۰۴/۱۰/۱۹', clicks: 45, impr: 3200, pos: 23.4 },
          keep: 'a', score: 0.79,
          why: ['gsc'],
          queries: ['دم کردن قهوه فرانسه', 'نسبت قهوه فرنچ پرس']
        }
      ],
      mergeHistory: [],
      redirects: [
        { from: '/old-espresso-beans/', to: 'https://demo-coffee.ir/espresso-buying-guide/', title: 'راهنمای کامل خرید قهوه اسپرسو خانگی' }
      ],
      ops: [
        { id: 'op1', kind: 'generate', title: 'تولید مقاله: راهنمای انتخاب قهوه اسپرسو خانگی', status: 'done', detail: 'Claude Sonnet · ۲٬۱۴۰ کلمه · ذخیره در پیش‌نویس', step: 'تکمیل شد', started: NOW - 1140, ended: NOW - 1106 },
        { id: 'op2', kind: 'image', title: 'ساخت تصویر شاخص WebP + تگ Alt فارسی', status: 'done', detail: 'Workers AI · حجم ۴۶ KB', step: 'ثبت شد', started: NOW - 1105, ended: NOW - 1094 },
        { id: 'op3', kind: 'sync', title: 'بکاپ خودکار کلادفلر KV', status: 'done', detail: 'تنظیمات و صف موضوعات همگام‌سازی شد', step: 'تکمیل شد', started: NOW - 3600, ended: NOW - 3598 }
      ]
    };
  }

  let STATE;
  try {
    STATE = JSON.parse(sessionStorage.getItem(STORAGE_KEY) || 'null') || defaultState();
  } catch (e) {
    STATE = defaultState();
  }
  function saveState() {
    try { sessionStorage.setItem(STORAGE_KEY, JSON.stringify(STATE)); } catch (e) {}
  }
  win.AAW_DEMO_RESET = function () {
    sessionStorage.removeItem(STORAGE_KEY);
    location.reload();
  };

  function topicCounts() {
    const c = { total: STATE.topics.length, pending: 0, processing: 0, done: 82, failed: 1 };
    STATE.topics.forEach(t => {
      if (t.status === 'pending') c.pending++;
      else if (t.status === 'processing') c.processing++;
      else if (t.status === 'done') c.done++;
      else if (t.status === 'failed') c.failed++;
    });
    return c;
  }

  function nowStatus() {
    const pending = STATE.topics.filter(t => t.status === 'pending');
    const nextTs = Math.floor(Date.now() / 1000) + 7840;
    return {
      state: 'idle',
      text: 'آماده؛ زمان‌بندی کلادفلر فعال و منتظر نوبت بعدی (حالت دموی آزمایشی).',
      engine: 'Claude Pro (اشتراک شخصی) + ۴ پشتیبان',
      mode: 'direct',
      next_run: { ts: nextTs, label: '۲ ساعت و ۱۰ دقیقه دیگر' },
      next: {
        ts: nextTs,
        items: pending.slice(0, 2).map(t => ({ title: t.title, idea: false, id: t.id }))
      },
      last: STATE.logs[0] ? { message: STATE.logs[0].message } : null,
      running: 0
    };
  }

  function buildArticle(topicTitle, kw) {
    const t = topicTitle || 'بهترین روش دم‌آوری قهوه دمی V60 در خانه';
    const k = kw || t;
    return {
      title: t,
      slug: 'demo-ai-article',
      focus_keyword: k,
      meta_description: `راهنمای کامل و تخصصی درباره ${t} با جدول مقایسه، نکات عملی و سوالات متداول (تولیدشده در دموی مرورگری).`,
      excerpt: `در این راهنمای کامل، تمام نکات کلیدی پیرامون «${t}» را به‌صورت گام‌به‌گام، بهینه برای سئو و با نگارش استاندارد فارسی بررسی کرده‌ایم.`,
      content: `<h2>مقدمه: چرا ${t} اهمیت دارد؟</h2><p>این متن یک خروجی نمونه در <strong>دموی مرورگری AI WRITER (اِی‌آی رایتر)</strong> است تا ساختار واقعی خروجی (هدینگ‌های H2/H3، نیم‌فاصله استاندارد، جدول مقایسه، لینک داخلی و سوالات متداول) را مشاهده کنید.</p><h2>جدول مقایسه و تنظیمات استاندارد</h2><table><thead><tr><th>پارامتر</th><th>مقدار پیشنهادی</th><th>تأثیر روی نتیجه</th></tr></thead><tbody><tr><td>دمای آب</td><td>۹۲ تا ۹۴ درجه</td><td>تعادل عطر و اسیدیته</td></tr><tr><td>نسبت قهوه به آب</td><td>۱ به ۱۶</td><td>شفافیت و غلظت متعادل</td></tr></tbody></table><h2>سوالات متداول</h2><h3>آیا این مقاله روی سایت واقعی منتشر می‌شود؟</h3><p>خیر؛ در دموی مرورگری تمام خروجی‌ها صرفاً در حافظه مرورگر شما شبیه‌سازی می‌شوند و هیچ تغییری روی سایت واقعی اعمال نمی‌گردد.</p>`,
      word_count: 1940,
      tags: [k, 'آموزش قهوه', 'راهنمای جامع'],
      faq: [
        { q: `مهم‌ترین نکته در ${t} چیست؟`, a: 'تنظیم دقیق نسبت، دما و تازگی مواد اولیه.' }
      ],
      image_prompt: `تصویر شاخص حرفه‌ای برای ${t}`
    };
  }

  // Handle every aaw_* AJAX action matching class-aaw-ajax.php contracts
  function handleAjax(action, d) {
    d = d || {};
    switch (action) {
      case 'now':
        return { ok: true, data: nowStatus() };

      case 'dashboard':
        return {
          ok: true,
          data: {
            counts: topicCounts(),
            review: STATE.reviews.filter(r => r.status === 'draft' || r.status === 'pending').length,
            next_run: '۲ ساعت و ۱۰ دقیقه دیگر',
            stats: { ok: 56, fail: 1, rate: 98, tokens_in: 428600, tokens_out: 186400, avg_ms: 34000 }
          }
        };

      case 'review_list': {
        const st = d.status || 'draft';
        const items = STATE.reviews.filter(r => (st === 'draft' ? (r.status === 'draft' || r.status === 'pending') : r.status === st));
        return { ok: true, data: { items } };
      }

      case 'review_action': {
        const id = Number(d.id || 0);
        const op = d.op || '';
        const item = STATE.reviews.find(r => r.id === id);
        if (!item) return { ok: false, message: 'نوشته در لیست نمونه پیدا نشد.' };
        if (op === 'publish') {
          item.status = 'publish';
          saveState();
          return { ok: true, data: { message: 'در دمو شبیه‌سازی شد: مقاله به تب «منتشرشده» منتقل گردید (روی سایت واقعی منتشر نشده).' } };
        }
        if (op === 'trash' || op === 'delete') {
          STATE.reviews = STATE.reviews.filter(r => r.id !== id);
          saveState();
          return { ok: true, data: { message: 'از فهرست نمایشی صف بازبینی حذف شد.' } };
        }
        return { ok: true, data: { message: 'عملیات در دموی آزمایشی ثبت شد (بدون تغییر روی سایت واقعی).' } };
      }

      case 'topics_list': {
        const st = d.status || '';
        const q = (d.search || '').trim();
        let items = STATE.topics.slice();
        if (st) items = items.filter(t => t.status === st);
        if (q) items = items.filter(t => t.title.includes(q) || (t.keywords || '').includes(q));
        return { ok: true, data: { items, total: items.length, counts: topicCounts() } };
      }

      case 'topic_add': {
        const title = (d.title || '').trim();
        if (!title) return { ok: false, message: 'عنوان موضوع را وارد کنید.' };
        const nt = {
          id: Date.now(), title, keywords: d.keywords || title, focus_keyword: d.keywords || title,
          category_id: Number(d.category_id || 1), category_name: 'آموزش دم‌آوری قهوه',
          status: 'pending', priority: 10, word_count: Number(d.word_count || 1800), tone: d.tone || '',
          notes: d.notes || '', post_id: 0, edit_url: '', post_status: '', generated_h: '', error: ''
        };
        STATE.topics.unshift(nt);
        saveState();
        return { ok: true, data: { message: 'موضوع به صف نمایشی اضافه شد (فقط در مرورگر شما).', id: nt.id } };
      }

      case 'topics_bulk': {
        const lines = String(d.text || '').split(/\r?\n/).map(s => s.trim()).filter(Boolean);
        lines.forEach((line, idx) => {
          STATE.topics.unshift({
            id: Date.now() + idx, title: line, keywords: line, focus_keyword: line,
            category_id: 1, category_name: 'آموزش دم‌آوری قهوه', status: 'pending', priority: 8,
            word_count: 1800, tone: '', notes: '', post_id: 0, edit_url: '', post_status: '', generated_h: '', error: ''
          });
        });
        saveState();
        return { ok: true, data: { message: `${lines.length} موضوع به صف نمایشی اضافه شد.`, added: lines.length, skipped: 0 } };
      }

      case 'topics_delete': {
        const ids = (d.ids || []).map(Number);
        STATE.topics = STATE.topics.filter(t => !ids.includes(t.id));
        saveState();
        return { ok: true, data: { message: 'از صف نمایشی حذف شد.' } };
      }

      case 'topics_status': {
        const ids = (d.ids || []).map(Number);
        const st = d.status || 'pending';
        STATE.topics.forEach(t => { if (ids.includes(t.id)) t.status = st; });
        saveState();
        return { ok: true, data: { message: 'وضعیت موضوعات در دمو به‌روز شد.' } };
      }

      case 'topic_duplicate': {
        const src = STATE.topics.find(t => t.id === Number(d.id));
        if (src) {
          const copy = Object.assign({}, src, { id: Date.now(), title: src.title + ' (کپی)', status: 'pending' });
          STATE.topics.unshift(copy);
          saveState();
        }
        return { ok: true, data: { message: 'موضوع در صف نمایشی کپی شد.' } };
      }

      case 'topics_reorder':
      case 'topic_move':
      case 'topic_update':
        saveState();
        return { ok: true, data: { message: 'تغییرات صف در دموی مرورگری ذخیره شد.' } };

      case 'timeline': {
        const pending = STATE.topics.filter(t => t.status === 'pending');
        const runs = [];
        for (let i = 0; i < Math.min(pending.length, 4); i++) {
          runs.push({
            ts: NOW + (i + 1) * 6 * 3600,
            items: [{ title: pending[i].title, idea: false, id: pending[i].id }]
          });
        }
        const past = STATE.reviews.map((r, i) => ({
          ts: NOW - (i + 1) * 5400,
          id: r.id, title: r.title, status: r.status, words: r.words,
          keyword: r.keyword, model: r.model, edit: r.edit_url, thumb: r.thumb
        }));
        return { ok: true, data: { future: { paused: false, empty: runs.length === 0, remaining: Math.max(0, pending.length - runs.length), runs }, past, now: nowStatus() } };
      }

      case 'activity':
        return {
          ok: true,
          data: {
            ops: STATE.ops,
            processing: [],
            logs: STATE.logs.map(l => ({ id: l.id, level: l.level, event: l.event, message: l.message, time: l.time_h.split(' ')[1] || '۱۷:۵۰:۰۰' })),
            running: 0,
            now: nowStatus()
          }
        };

      case 'logs_list': {
        let items = STATE.logs.slice();
        if (d.level) items = items.filter(l => l.level === d.level);
        if (d.event) items = items.filter(l => l.event === d.event);
        if (d.search) items = items.filter(l => l.message.includes(d.search));
        return { ok: true, data: { items, total: items.length, pages: 1, page: 1 } };
      }

      case 'cf_status':
        return {
          ok: true,
          data: {
            configured: true, deployed: true, outdated: false,
            secrets: ['ANTHROPIC_API_KEY', 'OPENAI_API_KEY', 'AVALAI_API_KEY', 'GEMINI_API_KEY', 'HMAC_SECRET'],
            schedules: ['0 */6 * * *'],
            worker: { ok: true, ms: 112, kv: true, ai: true, cron: true },
            caps: { bg: true, kv: true, ai: true, stream: true }
          }
        };

      case 'gsc_report':
        return {
          ok: true,
          data: {
            report: {
              site: 'https://demo-coffee.ir/', days: 28, at: NOW - 1800,
              totals: { c: 14820, i: 196400 },
              striking: [
                { q: 'بهترین قهوه اسپرسو خانگی', c: 410, i: 6200, ctr: 6.6, p: 6.2, post: { id: 401, title: 'راهنمای کامل انتخاب بهترین قهوه اسپرسو خانگی' } },
                { q: 'تنظیم درجه آسیاب قهوه اسپرسو', c: 285, i: 5100, ctr: 5.6, p: 8.8, post: null },
                { q: 'نسبت آب به قهوه در فرنچ پرس', c: 190, i: 4300, ctr: 4.4, p: 11.4, post: null },
                { q: 'علت کرما نداشتن اسپرسو خانگی', c: 164, i: 3900, ctr: 4.2, p: 12.1, post: null }
              ],
              low_ctr: [
                { q: 'قیمت دستگاه اسپرسوساز نیمه‌صنعتی', c: 42, i: 4800, ctr: 0.9, p: 5.4, page: 'https://demo-coffee.ir/espresso-machines/' }
              ],
              top: [
                { q: 'طرز تهیه قهوه فرانسه', c: 2380, i: 24900, ctr: 9.6, p: 3.1 },
                { q: 'آموزش دم‌آوری V60', c: 1640, i: 19200, ctr: 8.5, p: 4.0 }
              ],
              cannibal: STATE.merges.length
            }
          }
        };

      case 'merge_list':
        return { ok: true, data: { pairs: STATE.merges, history: STATE.mergeHistory, redirects: STATE.redirects, gsc: true } };

      case 'merge_start': {
        const pair = STATE.merges.find(m => m.a.id === Number(d.keep) || m.b.id === Number(d.drop) || m.a.id === Number(d.drop)) || STATE.merges[0];
        if (pair) {
          const keepObj = pair.a.id === Number(d.keep) ? pair.a : pair.b;
          const dropObj = pair.a.id === Number(d.keep) ? pair.b : pair.a;
          STATE.merges = STATE.merges.filter(m => m !== pair);
          STATE.mergeHistory.unshift({ id: 'mh_' + Date.now(), keep: keepObj.id, drop: dropObj.id, keep_title: keepObj.title, drop_title: dropObj.title, from: new URL(dropObj.url).pathname, links: 4, when: 'همین الان (شبیه‌سازی دمو)' });
          STATE.redirects.unshift({ from: new URL(dropObj.url).pathname, to: keepObj.url, title: keepObj.title });
          saveState();
        }
        return { ok: true, data: { message: 'ادغام هوشمند + ریدایرکت ۳۰۱ در دموی مرورگری شبیه‌سازی شد (بدون تغییر روی سایت واقعی).' } };
      }

      case 'knowledge':
        return {
          ok: true,
          data: {
            seo: {
              updated: NOW - 86400,
              rules: [
                'استفاده از نیم‌فاصله استاندارد فارسی در تمام افعال و جمع‌ها (می‌شود، قهوه‌ها)',
                'درج جدول مقایسه و بخش سوالات متداول (FAQ) در مقالات بالای ۱۵۰۰ کلمه',
                'لینک‌سازی طبیعی به ۲ تا ۶ مقاله یا محصول مرتبط داخل فروشگاه نمونه کافه آریا',
                'پرهیز از تکرار مصنوعی کلمه کلیدی و نگارش راهنمای کاربردی با تجربه واقعی باریستا'
              ]
            },
            theme: {
              palette: 'آبی و کرم گرم، نور طبیعی، سبک عکاسی مینیمال کافه',
              style: 'نورپردازی طبیعی، عمق میدان ملایم، بدون متن داخل تصویر'
            }
          }
        };

      case 'site_status':
        return { ok: true, data: { crawling: false, posts: 84, products: 38, categories: 4, updated: NOW - 7200, updated_h: '۲ ساعت پیش' } };

      case 'local_doctor': {
        const tsNow = Math.floor(Date.now() / 1000);
        return {
          ok: true,
          data: {
            can_exec: true,
            engines: {
              codex: {
                engine: 'codex',
                name: 'OpenAI Codex CLI (اکانت ChatGPT Plus)',
                package: '@openai/codex',
                status: 'ready',
                route: 'github',
                version: '0.38.0',
                login: true,
                model: 'پیش‌فرض پلن ChatGPT',
                path: '/usr/local/bin/codex',
                node: '/usr/bin/node (v22.14)',
                ssh: 'npm i -g @openai/codex',
                state: { last_ok: tsNow - 3400, test: { ok: true, text: 'اتصال آماده (حالت نمایشی)', sec: 1.6 } },
                install: {}
              },
              claude: {
                engine: 'claude',
                name: 'Claude Code CLI (اکانت Claude Pro/Max)',
                package: '@anthropic-ai/claude-code',
                status: 'ready',
                route: 'github',
                version: '1.0.24',
                login: true,
                model: 'claude-sonnet-4-5',
                path: '/usr/local/bin/claude',
                node: '/usr/bin/node (v22.14)',
                ssh: 'npm i -g @anthropic-ai/claude-code',
                state: { last_ok: tsNow - 1800, test: { ok: true, text: 'پاسخ آزمایشی تایید شد (نمایشی)', sec: 1.3 } },
                install: {}
              }
            },
            env: [
              { ok: true, label: 'اجرای CLI محلی یا ابری GitHub Actions', detail: 'مسیر ابری GitHub Actions فعال (وضعیت نمایشی)' },
              { ok: true, label: 'Node.js نسخه ۲۰ به بالا', detail: 'v22.14.0 در محیط سرور نمونه شناسایی شد' },
              { ok: true, label: 'فضای امن ذخیره نشست (Session)', detail: 'آماده و رمزنگاری‌شده (دمو)' }
            ],
            nodes: [
              { path: '/usr/bin/node', version: 'v22.14.0', npm: true }
            ],
            jobs: [
              { id: 'job-1', engine: 'claude', status: 'done', label: 'نگارش راهنمای انتخاب دانه قهوه اسپرسو', step: 'در صف بازبینی ذخیره شد (۲,۳۸۰ کلمه)', created: tsNow - 4200 },
              { id: 'job-2', engine: 'codex', status: 'done', label: 'تولید تصویر شاخص WebP آسیاب قهوه', step: 'فشرده‌سازی WebP انجام شد (۹۴ کیلوبایت)', created: tsNow - 9100 }
            ]
          }
        };
      }

      case 'local_jobs':
        return { ok: true, data: { jobs: [] } };

      case 'gh_runs':
        return {
          ok: true,
          data: {
            outdated: false,
            secrets: ['CLAUDE_CODE_OAUTH_TOKEN', 'AAW_CALLBACK_SECRET'],
            runs: [
              { id: 1, name: 'AI WRITER Runner', status: 'completed', conclusion: 'success', created_at: '۱۴۰۵/۰۹/۰۱ ۱۷:۴۹', url: '#demo-gh-run' },
              { id: 2, name: 'AI WRITER Runner', status: 'completed', conclusion: 'success', created_at: '۱۴۰۵/۰۹/۰۱ ۱۵:۲۹', url: '#demo-gh-run' }
            ]
          }
        };

      case 'analysis_status':
        return { ok: true, data: { pending: false, step: '', started: 0, done: true } };

      case 'prompt_preview': {
        const topic = d.topic || 'بهترین روش دم‌آوری قهوه دمی V60';
        const sys = 'شما نویسنده ارشد و متخصص سئوی «کافه آریا (سایت نمونه)» هستید. مقاله فارسی دقیق با نیم‌فاصله استاندارد، هدینگ‌های منطقی H2/H3، جدول مقایسه و سوالات متداول (FAQ) بنویسید.';
        const usr = `موضوع مقاله: ${topic}\nکلمات کلیدی: ${d.keywords || topic}\nحداقل کلمات: ۲۰۰۰ کلمه\nلینک داخلی: از فهرست واقعی مطالب و محصولات سایت استفاده کن.`;
        return { ok: true, data: { system: sys, user: usr, outline: '۱. مقدمه و شناخت موضوع\n۲. تجهیزات و نسبت استاندارد\n۳. آموزش گام‌به‌گام\n۴. جدول مقایسه و خطاهای رایج\n۵. سوالات متداول (FAQ)', chars: sys.length + usr.length } };
      }

      case 'provider_test': {
        const p = (win.AAW && win.AAW.providers && win.AAW.providers[d.provider]) || { name: d.provider || 'AI' };
        return { ok: true, data: { message: `تست نمایشی ${p.name} موفق بود (۳۴۰ میلی‌ثانیه · شبیه‌سازی در دمو بدون ارسال به سرور واقعی).`, ms: 340 } };
      }

      case 'provider_models': {
        const p = (win.AAW && win.AAW.providers && win.AAW.providers[d.provider]) || { models: ['claude-sonnet-4-5', 'gpt-4o'] };
        return { ok: true, data: { models: p.models || [] } };
      }

      case 'run_ticket':
      case 'generate_ticket':
      case 'suggest_ticket':
        return {
          ok: true,
          data: {
            url: 'https://demo-worker.aaw.invalid/' + action,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action, topic: d.topic || (STATE.topics[0] && STATE.topics[0].title) || 'نمونه مقاله سئوشده', keywords: d.keywords || '' })
          }
        };

      case 'save_generated': {
        const art = d.article || buildArticle('مقاله آزمایشی جدید', 'سئو وردپرس');
        const newRev = {
          id: Date.now(), status: 'draft', title: art.title || 'مقاله آزمایشی جدید',
          date: 'همین الان (دمو)', words: art.word_count || 1940, keyword: art.focus_keyword || 'آموزش قهوه',
          model: (d.meta && d.meta.model) || 'claude-sonnet-4-5', provider: (d.meta && d.meta.provider) || 'claude_pro',
          meta_desc: art.meta_description || '', excerpt: art.excerpt || '',
          thumb: '../assets/img/ic_fountain_pen.webp', edit_url: '#demo-edit-new', preview: '#demo-preview-new',
          cats: 'آموزش دم‌آوری قهوه', topic_id: 0, ai_state: {}, rev_pending: false, revisions: 0, img_prompt: art.image_prompt || ''
        };
        STATE.reviews.unshift(newRev);
        saveState();
        return { ok: true, data: { message: 'پیش‌نویس در صف بازبینیِ دموی مرورگری ذخیره شد (تغییری روی سایت واقعی اعمال نشد).', edit_url: '#demo-edit-new' } };
      }

      case 'save_settings':
      case 'priority_save':
      case 'key_save':
      case 'image_key_save':
      case 'sub_role':
        return { ok: true, data: { message: 'تنظیمات در دموی آزمایشی ذخیره شد (هیچ تغییری روی سایت یا سرور واقعی اعمال نمی‌شود).' } };

      case 'test_notify':
        return { ok: true, data: { message: 'پیام آزمایشی اعلان در دمو شبیه‌سازی شد (ارسال واقعی در دمو غیرفعال است).' } };

      case 'diagnose':
        return { ok: true, data: { ok: true, checks: [{ label: 'وضعیت محیط دمو', ok: true, detail: 'رابط واقعی افزونه در مرورگر با داده‌های نمونه اجرا می‌شود.' }, { label: 'شبیه‌ساز ورکر کلادفلر', ok: true, detail: 'پاسخ محلی آماده (بدون ارسال به سرور خارجی)' }] } };

      case 'settings_export':
        return { ok: true, data: { json: JSON.stringify({ demo: true, site: 'demo-coffee.ir', note: 'خروجی نمونه دموی مرورگری' }, null, 2), filename: 'aaw-demo-settings.json' } };

      case 'topics_export':
        return { ok: true, data: { csv: 'title,keywords,status\n' + STATE.topics.map(t => `"${t.title}","${t.keywords}","${t.status}"`).join('\n'), filename: 'aaw-demo-topics.csv' } };

      case 'explain':
        return { ok: true, data: { message: d.error || '' } };

      case 'cf_delete':
      case 'cf_rotate':
      case 'settings_reset':
      case 'settings_import':
      case 'license_deactivate':
      case 'gh_disconnect':
      case 'reveal_secret':
      case 'local_install':
      case 'local_login_start':
      case 'codex_login_start':
      case 'gsc_auth_url':
        return { ok: false, message: 'این عملیاتِ امنیتی یا متصل به سرور، در دموی مرورگری غیرفعال است و تنها پس از نصب افزونه روی وردپرس شما فعال می‌شود.' };

      default:
        return { ok: true, data: { message: 'در دموی آزمایشی شبیه‌سازی شد (تغییرات فقط نمایشی هستند و روی سایت واقعی ذخیره نمی‌شوند).' } };
    }
  }

  // 1) Intercept jQuery.post BEFORE admin.js loads
  const origPost = $.post;
  $.post = function (url, payload) {
    if (url === '__aaw_demo_ajax__' && payload && typeof payload.action === 'string' && payload.action.indexOf('aaw_') === 0) {
      const dfd = $.Deferred();
      const act = payload.action.slice(4);
      let parsed = {};
      try { parsed = JSON.parse(payload.data || '{}'); } catch (e) {}
      setTimeout(() => {
        const res = handleAjax(act, parsed);
        if (res.ok) dfd.resolve({ success: true, data: res.data || {} });
        else dfd.resolve({ success: false, data: { message: res.message || 'در دمو غیرفعال است.' } });
      }, 140);
      return dfd.promise();
    }
    return origPost.apply(this, arguments);
  };

  // 2) Intercept window.fetch for workerFetch() tickets (demo-worker.aaw.invalid)
  const origFetch = win.fetch ? win.fetch.bind(win) : null;
  win.fetch = function (input, init) {
    const u = typeof input === 'string' ? input : (input && input.url) || '';
    if (u.indexOf('demo-worker.aaw.invalid') !== -1) {
      let body = {};
      try { body = JSON.parse((init && init.body) || '{}'); } catch (e) {}
      const art = buildArticle(body.topic, body.keywords);
      let payload;
      if (u.indexOf('suggest_ticket') !== -1) {
        payload = { ok: true, topics: [
          { title: 'بهترین قهوه برای دستگاه موکاپات و نسبت دقیق آب', keywords: 'بهترین قهوه موکاپات' },
          { title: 'آموزش تنظیم فشار بار در اسپرسوساز خانگی', keywords: 'تنظیم فشار اسپرسوساز' },
          { title: 'تفاوت قهوه عربیکا اتیوپی و کلمبیا در دم‌آوری دمی', keywords: 'تفاوت قهوه اتیوپی و کلمبیا' }
        ] };
      } else if (u.indexOf('run_ticket') !== -1) {
        const newRev = {
          id: Date.now(), status: 'draft', title: art.title, date: 'همین الان (دمو)',
          words: art.word_count, keyword: art.focus_keyword, model: 'claude-sonnet-4-5', provider: 'claude_pro',
          meta_desc: art.meta_description, excerpt: art.excerpt, thumb: '../assets/img/ic_fountain_pen.webp',
          edit_url: '#demo-edit-run', preview: '#demo-preview-run', cats: 'آموزش دم‌آوری قهوه',
          topic_id: 0, ai_state: {}, rev_pending: false, revisions: 0, img_prompt: art.image_prompt
        };
        STATE.reviews.unshift(newRev);
        saveState();
        payload = { ok: true, post_id: newRev.id, title: art.title, message: 'مقاله نمونه ساخته و به صف بازبینی دمو اضافه شد.' };
      } else {
        payload = { ok: true, article: art, meta: { provider: 'claude_pro', model: 'claude-sonnet-4-5', tokens_in: 3820, tokens_out: 3190, duration_ms: 1400 } };
      }
      return new Promise(resolve => {
        setTimeout(() => {
          resolve(new Response(JSON.stringify(payload), { status: 200, headers: { 'Content-Type': 'application/json' } }));
        }, 420);
      });
    }
    if (origFetch) return origFetch(input, init);
    return Promise.reject(new Error('Network blocked in static demo'));
  };
})(window.jQuery, window);
